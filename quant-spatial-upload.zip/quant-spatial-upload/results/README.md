# Results

Each phase keeps its own JSON, writeup, and figures. Do not dump charts into a shared `figures/` folder.

Start here: **[e0/E0-what-we-found.md](e0/E0-what-we-found.md)**

```
results/e0/           E0 JSON, writeup
results/e0/figures/   E0 charts
results/e1/           E1 JSON, later writeup
results/e1/figures/   E1 charts
results/e2/           later
```

On this Mac, `Results/` and `results/` are the same folder.
