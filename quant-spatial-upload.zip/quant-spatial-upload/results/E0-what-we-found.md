# Moved

This writeup now lives with the rest of E0:

**[e0/E0-what-we-found.md](e0/E0-what-we-found.md)**

Figures for each phase stay in that phase’s folder:

- `e0/figures/`
- `e1/figures/`
