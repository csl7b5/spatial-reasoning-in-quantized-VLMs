# E1 analysis pre-registration

**Written:** 2026-08-15T06:24:00Z
**Status:** written before any E1 scoring run
**Commit:** not committed yet (commit this file before the first scoring run)

This file locks the analysis. Do not change it after scoring starts.

## Question

When a vision-language model is quantized, does spatial reasoning degrade faster than other capabilities, and is that extra damage about space or only about numbers?

## Runtime (locked)

- llama-cpp-python on Metal only
- Reference = F16 GGUF, not BF16 safetensors
- Vision tower = official F16 mmproj, held constant
- Models = C (2B) and A (8B). B and Glimmer are out.

## Model

Fit separately for Model C and Model A:

```
logprob ~ quant_level * spatial * numeric + (1 | item)
```

- `logprob` is the summed log-probability of the correct option
- `quant_level` is an ordered factor: F16, Q8_0, Q6_K, Q5_K_M, Q4_K_M, Q3_K_M, Q2_K
- Plots use measured bits-per-weight, not the level name
- `spatial` and `numeric` are binary item labels
- Random intercept per item

## Primary hypothesis

The `quant_level × spatial` interaction is significant after `quant_level × numeric` is already in the model.

Plainly: spatial fragility is not fully explained by numeric fragility.

A null result is valid. Record it.

## Secondary hypotheses

1. Degradation is larger for C (2B) than for A (8B).
2. Degradation grows as measured bits-per-weight falls.
3. The SEM cell degrades least.

## Metrics

- Primary: Δ logprob vs F16 on the correct option. No length norm.
- Secondary: accuracy from highest length-normalized option logprob.
- Secondary: normalized headroom (observed − chance) / (F16 − chance).

## Uncertainty

Bootstrap over items, 10,000 resamples. Report effect sizes and confidence intervals, not only p-values.

## Cells

| Cell | spatial | numeric |
|---|---|---|
| SR | 1 | 0 |
| SN | 1 | 1 |
| NN | 0 | 1 |
| SEM | 0 | 0 |

Text-solvable items (correct at F16 with the image removed) are a separate stratum. Do not pool them with the main model.

## What this file does not allow

- Changing the model after seeing results
- Dropping a cell after seeing results unless a stop rule already fired
- Tuning prompts to raise accuracy
- Using transformers in E1
