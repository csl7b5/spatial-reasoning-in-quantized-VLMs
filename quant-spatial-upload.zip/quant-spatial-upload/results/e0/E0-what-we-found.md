# What we found so far

This is a plain-language writeup of **E0**, the first stage of the **quant-spatial** project.

The short version: we were not trying to prove a scientific claim yet. We were asking a simpler question:

> Can this laptop actually run the models we want to study, and can we read the numbers we will need later?

**Yes, for the two vision models we tried.** Both passed. A third model is still on hold.

---

## What this project is about

We want to know how **shrinking a model** (quantization) changes its ability to reason about **space in pictures** — things like left vs right, or where an object is.

Think of it like this: a full-quality model is a high-resolution photo. A quantized model is a more compressed photo. It takes less space. The question is whether it still “sees” left and right correctly.

E0 did **not** answer that question. E0 only checked that the tools work on this computer.

Later stages (E1 through E4) are not written yet.

---

## The computer we used

This is a MacBook Pro with an Apple M4 Max chip. It has **36 GiB** of shared memory. It can run models with Apple’s Metal graphics system. It cannot use NVIDIA CUDA.

| What we measured | Number |
|---|---|
| Machine | MacBook Pro, Mac16,6 |
| Chip | Apple M4 Max |
| Total memory | 36 GiB, shared |
| Graphics system | Metal / MPS |
| NVIDIA CUDA | No |
| Safe working room (Metal’s own advice) | 28.08 GiB |
| Biggest single chunk Metal will hold | 21.06 GiB |
| Realistic room with normal apps open | about 18 to 22 GiB |
| Disk free space | 752 GB (pass; we wanted at least 500 GB) |

Those hardware numbers were measured earlier. We did not re-argue them.

**One important detail:** on this Mac, the “memory a Python process reports” can look tiny, while the graphics system is actually holding the model. For the big model, Python said it was using about 0.25 GiB, but Metal was holding **16.33 GiB**. The 16.33 number is the real one.

![How much memory each model used, compared with the 18, 22, and 28 GiB limits](figures/memory-used.png)

---

## The models

We planned three models. We only downloaded and tested two.

| Name we use | What it is | Size we saved on disk | Did we run it? | Result |
|---|---|---|---|---|
| **C** (smoke test) | Qwen3-VL-2B, a small picture-and-text model | 6.92 GB | Yes | Passed every check |
| **A** (main model) | Qwen3-VL-8B, a larger picture-and-text model | 27.41 GB | Yes, after C passed | Passed every check |
| **B** (on hold) | Nemotron Nano 9B, a text-only hybrid model | not downloaded | No | Still waiting |
| Glimmer (not used) | Muse Glimmer 30B, already on this Mac in Ollama | 21 GB already present | No | Not part of this study |

Glimmer is already on the machine as a chat model. It is **not** model A. We did not download it again. The full-quality Glimmer file is about 58–60 GB and will not fit.

Model B cannot look at pictures. That is why it is a weaker fit for a “space in pictures” study. We left it alone on purpose.

![What we downloaded for the small model and the main model](figures/disk-downloads.png)

### What each downloaded copy is

For C and A we saved three files each:

1. **Full-quality copy (BF16)** — the reference. This is the “uncompressed” version we compare against later.
2. **Compressed copy (Q8_0 GGUF)** — a smaller official copy, about 8-bit.
3. **Vision helper (mmproj F16)** — the extra file the compressed copy needs to look at pictures.

| Model | Full-quality | Compressed Q8_0 | Vision helper | Total |
|---|---|---|---|---|
| C (2B) | 4.27 GB | 1.83 GB | 0.82 GB | **6.92 GB** |
| A (8B) | 17.55 GB | 8.71 GB | 1.16 GB | **27.41 GB** |

We asked before downloading more than 30 GB. A was 27.41 GB, so we did not need to stop and ask. We did **not** download A and B together.

Official compressed versions available later, but not downloaded yet: **Q4_K_M** (more compressed) and **F16** (barely compressed). We did not download community/unofficial extra-small copies.

---

## The picture we used for tests

We did not use a real-world photo dataset yet. We made one simple test picture: a red circle on the left and a blue square on the right.

![The test picture: red circle on the left, blue square on the right](figures/test-picture.png)

We asked the models things like “name the two colors” and “which shape is on the left?” We did **not** rewrite the questions to make the models look smarter. The point was “does the pipeline work,” not “did we get a high score.”

---

## The five checks

We ran the same five checks on the small model first, then on the main model. If a required check failed, we would have stopped.

![The five checks in order](figures/five-checks.png)

| Check | Plain-English question | Small model C | Main model A |
|---|---|---|---|
| **A. Load** | Can we start the model and get it to say something? | Pass | Pass |
| **B. Confidence** | Can we read how sure it is about the next word? | Pass | Pass |
| **C. Reading answers** | Can our code pull a JSON answer, a letter, a box, or “left/right” out of text? | Pass | Pass |
| **D. Internals** | Can we see the hidden numbers inside the model? | Pass (full-quality only) | Pass (full-quality only) |
| **E. Memory** | Does it fit in the 22 GiB practical budget? | Pass | Pass |

Both models passed all five. We did not skip a failure or switch to a backup plan.

---

## Check A — can it load and talk?

We asked each model, with no extra coaching:

- Text: “Reply with the word ready and nothing else.”
- Picture: “Name the two colors in this image.”

We used two programs:

- **transformers** on Metal, full-quality (BF16)
- **llama-cpp-python** on Metal, compressed (Q8_0) plus the vision helper

| Model | Program | Load time | What it said (text) | What it said (picture) | Memory after load |
|---|---|---|---|---|---|
| C | transformers | 3.0 s | `ready` (2 words/tokens) | Started describing a red circle (20 tokens) | 3.96 GiB |
| C | compressed | 0.8 s | `ready` (1 token) | Started describing red (20 tokens) | 2.39 GiB RSS |
| A | transformers | 14.3 s | `ready` (2 tokens) | Started “the two colors are… Red (the circle…” (20 tokens) | **16.33 GiB** |
| A | compressed | 3.3 s | `ready` (1 token) | “The two colors in this image are red and blue.” (11 tokens) | 8.73 GiB RSS |

So: both models start, both can read the test picture, and both can answer in the compressed form too.

After the load check finished writing its notes, the compressed program sometimes crashed while shutting down (a Metal cleanup bug). The answers were already saved. We did not treat that crash as a failed test.

---

## Check B — can we see its confidence?

Later we will compare “how sure” the full-quality model is versus a compressed one. That only works if we can read those confidence numbers (log-probabilities).

We can.

We used a fixed sentence: “The capital of France is.” We did not change it to get a prettier answer.

| Model | Program | Could we read confidence numbers? | First word it wanted | Notes |
|---|---|---|---|---|
| C | transformers | Yes | “The” (confidence basically 100%) | It continued the whole sentence: “The capital of France is Paris.” |
| C | compressed | Yes | “ Paris” (confidence about 39%) | This path did not use the chat wrapper, so the numbers are not directly comparable |
| A | transformers | Yes | “The” (confidence basically 100%) | It wrote “The capital of France is **Paris**” |
| A | compressed | Yes | numeric list saved | Same “raw text” style as C’s compressed path |

**Takeaway for later work:** the two programs are not scoring the same way yet. One wraps the question like a chat. The other does not. Before we compare full-quality vs compressed, we must pick one method and stick to it.

---

## Check C — can we read the answers?

We need a dumb, reliable reader for later scoring. It looks for:

- a JSON object like `{"shape": "circle", "side": "left"}`
- a multiple-choice letter A/B/C/D
- a box of four numbers `[x1, y1, x2, y2]`
- a side word such as left, right, above, below

We first fed it four clean example strings. It got **4 out of 4** right.

Then we asked each model the spatial question, with the test picture, and **did not rewrite the question**.

| Model | What it wrote | Did our reader understand it? |
|---|---|---|
| C | `{"shape": "circle", "side": "left"}` inside a code fence | Yes |
| A | `{ "shape": "circle", "side": "left" }` | Yes |

That is luck / the models being cooperative. It is **not** a benchmark score. We did not tune the question to make this happen.

---

## Check D — can we see the insides?

For later work we may want to watch how the model’s internal numbers change when we compress it.

We can do that on the full-quality copies. We **cannot** do it on the compressed copies with the current official Python library. We recorded that limit and did not switch to an unofficial library to get around it.

![How many layers and how wide each model is](figures/model-insides.png)

| Model | Layers | Width of each layer | Vision width | Text internals shape | Picture internals shape |
|---|---|---|---|---|---|
| C | 28 | 2048 | 1024 | 1 × 13 × 2048 | 1 × 82 × 2048 |
| A | 36 | 4096 | 1152 | 1 × 13 × 4096 | 1 × 82 × 4096 |

The picture path is longer (82 vs 13) because the image is turned into extra tokens. Same test picture, same 82 image-related slots on both models.

---

## Check E — does it fit in memory?

| Model | Program | Real peak we should care about | Under 22 GiB? | Room left to 22 GiB |
|---|---|---|---|---|
| C | transformers | 3.96 GiB (Metal) | Yes | lots (if you count Metal, about 18 GiB) |
| C | compressed | 2.48 GiB (process) | Yes | 19.52 GiB |
| A | transformers | **16.33 GiB (Metal)** | Yes | **5.67 GiB** |
| A | compressed | 8.75 GiB (process) | Yes | 13.25 GiB |

The main model in full quality is the tight one. It fits. It does **not** have a huge cushion. If lots of other apps are open, or if later tests use bigger pictures or longer answers, we could get close to the limit.

While the main model was looking at the picture, the Mac’s overall memory use went as high as about 25 GiB of 36 GiB (about 84%). That is the whole computer, not just the model.

---

## The software we installed

All of this ran in a local Python 3.13.14 environment in `.venv`.

| Package | Version | What it is for |
|---|---|---|
| torch | 2.13.0 | Runs the full-quality model on Metal |
| transformers | 5.15.0 | Loads Qwen3-VL |
| llama-cpp-python | 0.3.34, built with Metal | Runs the compressed copies |
| torchvision | 0.28.0 | Image helpers |
| qwen-vl-utils | 0.0.14 | Qwen picture utilities |
| huggingface_hub | 1.27.0 | Downloads |
| datasets | 5.0.1 | Not used for a real benchmark yet |
| pillow | 12.3.0 | The test picture |
| psutil | 7.2.2 | Memory notes |
| python-dotenv | 1.2.2 | Reads `.env` without putting secrets in code |
| accelerate | 1.14.0 | Model loading helper |
| numpy | 2.5.2 | Number arrays |
| cmake | 4.4.2 | Only used to compile the Metal compressed-model library |

Hugging Face sometimes asked for a login token. We did not need one for these Qwen models. The token field in `.env` is still empty. We never put a token into the code.

---

## Problems we noticed (and did not paper over)

1. **The compressed program can crash while quitting.** The answers are already written. The crash is a Metal cleanup bug, not a “model failed to talk” bug.
2. **Python’s memory number can lie on this Mac.** Trust Metal’s number for the full-quality models.
3. **Confidence numbers from the two programs are not lined up yet.** Chat wrapper vs raw text.
4. **We cannot read internals from the compressed copies** with the official library we installed.
5. **Downloads without a Hugging Face token are slower.** Fine for public Qwen files. Model B will probably need a token.
6. **The main model is a tight fit** at 16.33 GiB of 22 GiB practical room.
7. Official extra-compressed files for these Qwen models go down to **Q4_K_M**. Anything smaller would be unofficial.

---

## What we did *not* do

- We did not run a real spatial-reasoning benchmark.
- We did not compare full-quality vs compressed on purpose, except to prove both start.
- We did not download Q4 or other extra-small copies.
- We did not download model B.
- We did not use Glimmer.
- We did not change questions to raise the score.
- We did not write E1, E2, E3, or E4 yet.

---

## Where the files live

Project folder: `.`

Ignore the old copy on the Desktop / OneDrive. This local folder is the real one.

Each later stage gets its own folder. Charts stay inside that folder, not in a shared pile.

```
results/e0/   this stage: numbers, writeup, and figures
results/e1/   later
results/e2/   later
```

### This writeup

| File | What it is |
|---|---|
| `results/e0/E0-what-we-found.md` | This document |
| `results/e0/figures/memory-used.png` | Memory chart |
| `results/e0/figures/disk-downloads.png` | Download-size chart |
| `results/e0/figures/five-checks.png` | The five checks |
| `results/e0/figures/model-insides.png` | Layers and width |
| `results/e0/figures/test-picture.png` | The red circle / blue square picture |
| `e0/make_figures.py` | Script that drew the charts (`python e0/make_figures.py`) |

### The programs that ran the checks

| File | What it does |
|---|---|
| `e0/common.py` | Shared paths, memory helpers, the test picture |
| `e0/download_c.py` | Download the small model |
| `e0/download_a.py` | Download the main model |
| `e0/gate_a_load.py` | Check A |
| `e0/gate_b_logprob.py` | Check B |
| `e0/gate_c_parser.py` | Check C |
| `e0/gate_d_hidden.py` | Check D |
| `e0/gate_e_memory.py` | Check E |
| `e0/report.py` | Rolls the JSON notes into one summary |
| `e0/make_figures.py` | Draws the charts into `results/e0/figures/` |

Run a check on the main model like: `python e0/gate_a_load.py --model A`

### The raw number files (the official record)

| File | What is in it |
|---|---|
| `results/e0/disk_audit.json` | Disk space |
| `results/e0/versions.json` | Software versions |
| `results/e0/models.json` | Which models we chose |
| `results/e0/download_c.json` | Small-model download sizes |
| `results/e0/download_a.json` | Main-model download sizes |
| `results/e0/gate_a.json` through `gate_e.json` | Small-model check results |
| `results/e0/a/gate_a.json` through `gate_e.json` | Main-model check results |
| `results/e0/report.json` | Combined machine summary |

If a number in this writeup disagrees with those JSON files, **believe the JSON**.

### The model files (large, not in git)

| Path | What it is |
|---|---|
| `models/c/transformers/` | Small model, full quality |
| `models/c/gguf/Qwen3VL-2B-Instruct-Q8_0.gguf` | Small model, compressed |
| `models/c/gguf/mmproj-Qwen3VL-2B-Instruct-F16.gguf` | Small model vision helper |
| `models/a/transformers/` | Main model, full quality |
| `models/a/gguf/Qwen3VL-8B-Instruct-Q8_0.gguf` | Main model, compressed |
| `models/a/gguf/mmproj-Qwen3VL-8B-Instruct-F16.gguf` | Main model vision helper |
| `data/e0/spatial_shapes.png` | Original test picture |

---

## If someone is planning the next stage

E0 is done for the two picture models. The next stage should be a real experiment plan (likely E1), not another “can it turn on” test, unless you still want model B.

Rules that still apply:

- Try the small model first, then the main model.
- Ask before downloading more than 30 GB.
- Do not put a Hugging Face token in the code.
- Do not hide a failed check.
- Do not treat Glimmer as the main model.
- Do not rewrite questions just to raise the score.
- Internals work is full-quality-only for now.
- The main model already uses 16.33 of the 22 GiB practical budget. Do not load two big copies at once.
