"""Download GQA-Spatial parquets (images + answers included)."""

from __future__ import annotations

from huggingface_hub import list_repo_files

from common import DATA, RESULTS, now_iso, write_json
from download_label_samples import fetch_file
from inventory import main as write_inventory

REPO = "mm-eval/GQA-Spatial"
DEST = DATA / "gqa_spatial"


def main() -> None:
    names = list_repo_files(REPO, repo_type="dataset")
    wanted = sorted(n for n in names if n.endswith(".parquet"))
    if not wanted:
        raise SystemExit(f"no parquet files on {REPO}")
    rows = []
    for name in wanted:
        path = fetch_file(REPO, name, DEST)
        rows.append({"filename": name, "path": str(path), "bytes": path.stat().st_size})
        print(f"{name} -> {path} ({path.stat().st_size} bytes)")
    write_json(
        RESULTS / "gqa_spatial_download.json",
        {
            "recorded_at": now_iso(),
            "repo": REPO,
            "license": "not stated on Hub card; GQA source is CC-BY-4.0 / Visual Genome images",
            "files": rows,
            "total_bytes": sum(r["bytes"] for r in rows),
            "note": "testdev parquets only. Used to hunt SN (count + location).",
        },
    )
    write_inventory()


if __name__ == "__main__":
    main()
