"""Write the E1 cell taxonomy from finished hand labels. Rebuilds proposals."""

from __future__ import annotations

from collections import Counter, defaultdict

from common import RESULTS, now_iso, read_json, write_json

QUEUE = RESULTS / "label_queue.json"
LABELS = RESULTS / "hand_labels.json"
OUT = RESULTS / "benchmark_taxonomy.json"
TARGET = 50


def cell_of(spatial: bool, numeric: bool) -> str:
    if spatial and not numeric:
        return "SR"
    if spatial and numeric:
        return "SN"
    if (not spatial) and numeric:
        return "NN"
    return "SEM"


def main() -> None:
    queue = read_json(QUEUE)
    labels = read_json(LABELS)["labels"]
    items = queue["items"]
    if len(labels) < len(items):
        missing = [row["item_id"] for row in items if row["item_id"] not in labels]
        raise SystemExit(f"unlabeled items remain: {len(missing)}")

    old_agree = 0
    excluded = 0
    your_cells: Counter[str] = Counter()
    by_source: dict[str, dict] = defaultdict(lambda: {"n": 0, "old_agree": 0, "your": Counter()})
    rows = []
    for item in items:
        lab = labels[item["item_id"]]
        old = item.get("proposed_cell")
        if lab.get("exclude"):
            excluded += 1
            cell = None
        else:
            cell = lab["cell"]
            your_cells[cell] += 1
            if cell == old:
                old_agree += 1
                by_source[item["source"]]["old_agree"] += 1
        by_source[item["source"]]["n"] += 1
        by_source[item["source"]]["your"][cell] += 1
        rows.append(
            {
                "item_id": item["item_id"],
                "source": item["source"],
                "question": item.get("question"),
                "old_proposed_cell": old,
                "spatial": None if lab.get("exclude") else lab.get("spatial"),
                "numeric": None if lab.get("exclude") else lab.get("numeric"),
                "cell": cell,
                "exclude": bool(lab.get("exclude")),
            }
        )
        if not lab.get("exclude"):
            item["proposed_spatial"] = bool(lab.get("spatial"))
            item["proposed_numeric"] = bool(lab.get("numeric"))
            item["proposed_cell"] = cell
            item["cell"] = cell
            item["spatial"] = bool(lab.get("spatial"))
            item["numeric"] = bool(lab.get("numeric"))
            item["label_note"] = (
                "Proposed cell rebuilt from hand label. "
                + (item.get("label_note") or "")
            )

    n = len(items) - excluded
    kept = {cell: your_cells.get(cell, 0) for cell in ("SR", "SN", "NN", "SEM")}
    short = {cell: max(0, TARGET - kept[cell]) for cell in kept}

    payload = {
        "recorded_at": now_iso(),
        "status": "rebuilt_from_hand_labels",
        "n_labeled": len(items),
        "n_excluded": excluded,
        "n_kept": n,
        "old_proposal_agreement": round(old_agree / n, 4) if n else None,
        "old_proposal_agree_n": old_agree,
        "rebuilt_agreement": 1.0,
        "target_per_cell": TARGET,
        "kept_by_cell": kept,
        "short_of_target": short,
        "ready_for_scoring": all(v == 0 for v in short.values()) and n >= TARGET * 4,
        "rules": [
            "Spatial = the answer depends on where things are (left/right/front/behind/above/below/closer), not what they are.",
            "Numeric = the answer depends on a number, count, or size comparison. Size as a class word (a large truck) is not numeric.",
            "Closer/farther with no measured distance is SR, not SN.",
            "Count with no location relation is NN. Count plus a location relation is SN.",
            "Analog clock reading is SN (hand position + time).",
            "Which is larger is NN. Is the smaller one above the larger one is SN.",
            "Presence and object-state (cut in half, half eaten, half full) are SEM. Half as a word is not numeric.",
            "World-knowledge trivia that barely uses the image is SEM or exclude.",
        ],
        "rebuild_note": (
            "The first auto tags treated BLINK depth/count as SN and all MathVista testmini "
            "survivors as NN. Hand labels rejected that (old agreement 66%). Proposed cells "
            "on the queue are now the hand labels. Human labels were not changed."
        ),
        "by_source": {
            src: {
                "n": row["n"],
                "old_agree": row["old_agree"],
                "your_cells": dict(row["your"]),
            }
            for src, row in by_source.items()
        },
        "next_action": (
            "SN is under 50. Download more SN labeling samples (count + location, analog clocks, "
            "smaller-above-larger) and label until SN kept >= 50. Do not start ladder scoring."
            if short["SN"]
            else "All four cells have 50 hand labels. Next is the full 300–500 pool, still blocked if a cell cannot reach 300."
        ),
        "items": rows,
    }

    queue["recorded_at"] = now_iso()
    queue["note"] = (
        "Hand-label queue. Proposed cells rebuilt from hand labels. "
        "SN/NN/SEM samples are still not the full scoring pools."
    )
    queue["by_proposed_cell"] = {
        cell: sum(1 for item in items if item.get("proposed_cell") == cell) for cell in ("SR", "SN", "NN", "SEM")
    }
    write_json(QUEUE, queue)
    write_json(OUT, payload)
    print(f"old agreement {payload['old_proposal_agreement']:.1%} -> rebuilt 100%")
    print("kept", dict(kept), "short", dict(short))
    print("ready_for_scoring", payload["ready_for_scoring"])
    print(OUT)


if __name__ == "__main__":
    main()
