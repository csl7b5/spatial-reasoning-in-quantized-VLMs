"""Download CLEVR-Math parquets from LLaVA-OneVision-Data (images included)."""

from __future__ import annotations

from huggingface_hub import list_repo_files

from common import DATA, RESULTS, now_iso, write_json
from download_label_samples import fetch_file
from inventory import main as write_inventory

REPO = "lmms-lab/LLaVA-OneVision-Data"
PREFIX = "CLEVR-Math(MathV360K)/"
DEST = DATA / "clevr_math"


def main() -> None:
    names = list_repo_files(REPO, repo_type="dataset")
    wanted = sorted(n for n in names if n.startswith(PREFIX) and n.endswith(".parquet"))
    if not wanted:
        raise SystemExit(f"no {PREFIX}*.parquet on {REPO}")
    rows = []
    for name in wanted:
        path = fetch_file(REPO, name, DEST)
        rows.append({"filename": name, "path": str(path), "bytes": path.stat().st_size})
        print(f"{name} -> {path} ({path.stat().st_size} bytes)")
    write_json(
        RESULTS / "clevr_math_download.json",
        {
            "recorded_at": now_iso(),
            "repo": REPO,
            "subset": PREFIX.rstrip("/"),
            "license": "check parent card; CLEVR source is CC-BY-4.0",
            "files": rows,
            "total_bytes": sum(r["bytes"] for r in rows),
        },
    )
    write_inventory()


if __name__ == "__main__":
    main()
