"""Download CV-Bench 2D/3D parquets only. Do not download a separate img/ tree."""

from __future__ import annotations

from common import DATA, RESULTS, now_iso, write_json
from download_label_samples import fetch_file
from inventory import main as write_inventory

REPO = "nyu-visionx/CV-Bench"
DEST = DATA / "cvbench"
FILES = ("test_2d.parquet", "test_3d.parquet")


def main() -> None:
    rows = []
    for name in FILES:
        path = fetch_file(REPO, name, DEST)
        rows.append({"filename": name, "path": str(path), "bytes": path.stat().st_size})
        print(f"{name} -> {path} ({path.stat().st_size} bytes)")
    write_json(
        RESULTS / "cvbench_download.json",
        {
            "recorded_at": now_iso(),
            "repo": REPO,
            "license": "apache-2.0",
            "files": rows,
            "total_bytes": sum(r["bytes"] for r in rows),
            "n_items_card": 2638,
            "tasks": "2D spatial relations + counting; 3D depth order + relative distance",
            "note": "Parquets include images and answers. Separate img/ was not downloaded.",
        },
    )
    write_inventory()


if __name__ == "__main__":
    main()
