"""Measure image token counts for P3. Isolated process."""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "e1"))

from common import MODEL_SPECS, exception_record, gguf_path, now_iso, read_json, write_json  # noqa: E402
from vision_score import N_CTX, PROMPT, eval_vision_prompt, make_handler, resolution_pin  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="C")
    parser.add_argument("--level", default="Q4_K_M")
    parser.add_argument("--items", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    spec = MODEL_SPECS[args.model]
    gguf = gguf_path(args.model, args.level)
    items = read_json(Path(args.items))["items"]
    record: dict = {
        "status": "FAIL",
        "model": args.model,
        "level": args.level,
        "gguf": str(gguf),
        "pin": resolution_pin(),
        "started_at": now_iso(),
        "items": [],
    }
    llm = None
    handler = None
    try:
        from llama_cpp import Llama

        handler = make_handler(spec["mmproj"])
        llm = Llama(
            model_path=str(gguf),
            chat_handler=handler,
            n_ctx=N_CTX,
            n_gpu_layers=-1,
            logits_all=True,
            verbose=False,
        )
        for item in items:
            t0 = time.perf_counter()
            prompt_n, image_n = eval_vision_prompt(llm, handler, Path(item["image"]), PROMPT)
            record["items"].append(
                {
                    "item_id": item["item_id"],
                    "image": item["image"],
                    "prompt_n_tokens": prompt_n,
                    "image_n_tokens": image_n,
                    "elapsed_s": round(time.perf_counter() - t0, 4),
                }
            )
        record["status"] = "PASS"
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        if llm is not None:
            del llm
        if handler is not None:
            del handler
        record["finished_at"] = now_iso()
        write_json(Path(args.out), record)
    return 0 if record["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
