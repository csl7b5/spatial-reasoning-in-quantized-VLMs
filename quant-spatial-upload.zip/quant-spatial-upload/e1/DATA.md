# Data and models (not in git)

`data/` and `models/` are gitignored. Clone the repo, then rebuild local files with the scripts below. Do not copy those folders to GitHub.

Ask before any download over 30 GB. Never download MathVista `images.zip` (~27 GB) or the official CLEVR v1.0 zip (~18 GB). We use smaller splits instead.

Muse Glimmer (`muse-glimmer:30b-mlx` in Ollama) is already on this machine. It is not part of E0/E1. Do not re-download or delete it.

## Models

E1 scores GGUF files with llama.cpp on Metal. The vision tower (`mmproj`) stays F16.

| Letter | Model | Scripts |
|---|---|---|
| C | Qwen3-VL-2B-Instruct | `python e1/download_f16.py` then `python e1/build_ladder.py` |
| A | Qwen3-VL-8B-Instruct | same, after C |

E0 also saved BF16 safetensors under `models/*/transformers/` for E3. E1 does not score those.

Refresh the local file list: `python e1/inventory.py`  
That writes `results/DOWNLOAD_INVENTORY.json` and `results/HOW_TO_DELETE.md` (also gitignored).

## Benchmarks used in the frozen scoring pool

Rebuild the 2,000-item exam after the files below are on disk:

```bash
python e1/build_scoring_pool.py
```

That writes `results/e1/scoring_pool.json` and extracts only the sampled images into `data/e1/pool/`.

| Cell | Dataset | License | What we downloaded | Script |
|---|---|---|---|---|
| SR | What'sUp controlled photos | MIT | `examples.jsonl` + controlled images from `images.zip` (COCO/VG stay unused in the zip) | `python e1/download_whatsup.py` |
| SN | CLEVR v1.0 **validation only** | CC-BY-4.0 | Hub parquets from `dpdl-benchmark/clevr` (`data/validation-*.parquet`, ~2 GB). Not the 18 GB official zip. | `python e1/download_clevr_val.py` |
| NN | CV-Bench Count | Apache-2.0 | `test_2d.parquet` + `test_3d.parquet` (~400 MB). Not a separate `img/` tree. | `python e1/download_cvbench.py` |
| SEM | POPE `Full/random` | Hub card has no license; COCO-derived images | `Full/random` parquet only | `python e1/download_label_samples.py` (POPE part) |

Hand-label samples (not the full scoring pool) also used MathVista **testmini**, BLINK Relative_Depth/Counting val, and extra MathVista SN top-ups. Those scripts stay in `e1/`.

## Downloads we tried and should not treat as scoring sources

| Dataset | Why not | Keep on disk? |
|---|---|---|
| MathVista **test** parquets | Answers are blank (leaderboard-hidden) | Optional; ~744 MB. Safe to delete. Never download `images.zip`. |
| GQA-Spatial | Almost all SR presence/location, not count+location | Optional; not in the scoring pool |
| CLEVR-Math | “left” means remaining, not spatial left | Optional; not in the scoring pool |
| Official CLEVR v1.0 zip | 18 GB train+val+test. Val parquets are enough | Do not download |
| EmbSpatial-Bench | Images not in the Hub JSON; scene licenses unchecked | Do not download yet |
| Model B / Glimmer | Out of E1 | Do not download |

## What *is* in git

Code under `e0/` and `e1/`, this file, `e1/PROTOCOL.md`, and notes under `results/` such as `results/e1/analysis_prereg.md` and hand-label JSON. Those are text. They are not the pictures or the weights.
