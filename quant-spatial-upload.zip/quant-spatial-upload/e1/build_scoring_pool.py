"""Freeze the E1 scoring pools: 500 closed-set items per cell. Does not score."""

from __future__ import annotations

import random
import re
from collections import Counter
from pathlib import Path

from common import DATA, RESULTS, now_iso, write_json
from count_disk_pools import classify_question
from datasets import load_dataset

from download_label_samples import as_pil, load_parquet, save_pil
from download_whatsup import CONTROLLED_SOURCES, load_controlled
from inventory import main as write_inventory

SEED = 20260817
N_TARGET = 500
N_MIN = 300
POOL = DATA / "pool"

YES_NO = ["yes", "no"]
COUNT_OPTS = [str(i) for i in range(10)]


def unbytes(value) -> str:
    text = str(value or "").strip()
    if len(text) >= 3 and text[0] == "b" and text[1] in {"'", '"' } and text[-1] == text[1]:
        return text[2:-1]
    return text


def item_row(
    item_id: str,
    image: Path,
    source: str,
    question: str,
    options: list[str],
    correct_index: int,
    spatial: bool,
    numeric: bool,
) -> dict:
    cell = "SR" if spatial and not numeric else "SN" if spatial and numeric else "NN" if numeric else "SEM"
    return {
        "item_id": item_id,
        "image": str(image),
        "source": source,
        "question": question,
        "options": options,
        "correct_index": correct_index,
        "correct_option": options[correct_index],
        "spatial": spatial,
        "numeric": numeric,
        "cell": cell,
    }


def pick(rows: list, n: int, rng: random.Random) -> list:
    if len(rows) < N_MIN:
        raise RuntimeError(f"only {len(rows)} candidates, need {N_MIN}")
    chosen = list(rows)
    rng.shuffle(chosen)
    return chosen[: min(n, len(chosen))]


def sample_sr(rng: random.Random) -> list[dict]:
    pool = load_controlled()
    by_src = {name: [] for name in CONTROLLED_SOURCES}
    for item in pool:
        by_src[item["source"]].append(item)
    half = N_TARGET // 2
    chosen = []
    for name in CONTROLLED_SOURCES:
        rows = list(by_src[name])
        rng.shuffle(rows)
        chosen.extend(rows[:half])
    if len(chosen) < N_TARGET:
        rest = [item for item in pool if item not in chosen]
        rng.shuffle(rest)
        chosen.extend(rest[: N_TARGET - len(chosen)])
    out = []
    for item in chosen[:N_TARGET]:
        out.append(
            item_row(
                item_id=f"sr_{item['item_id']}",
                image=Path(item["image"]),
                source=f"whatsup:{item['source']}",
                question="Which caption matches the image?",
                options=list(item["options"]),
                correct_index=0,
                spatial=True,
                numeric=False,
            )
        )
    return out


def letter_index(answer: str, n: int) -> int | None:
    raw = unbytes(answer).strip()
    m = re.match(r"^\(?([A-Za-z])\)?$", raw)
    if m:
        idx = ord(m.group(1).upper()) - ord("A")
        if 0 <= idx < n:
            return idx
    return None


def sample_nn(rng: random.Random) -> list[dict]:
    files = sorted((DATA / "cvbench").glob("test_2d.parquet"))
    if not files:
        files = sorted((DATA / "cvbench").rglob("test_2d.parquet"))
    ds = load_parquet(files[0])
    cand = []
    for i in range(len(ds)):
        row = ds[i]
        if str(row.get("task") or "").lower() != "count":
            continue
        q = str(row.get("question") or "").strip()
        cell, _ = classify_question(q)
        if cell != "NN":
            continue
        choices = [str(c) for c in list(row.get("choices") or [])]
        if len(choices) < 2:
            continue
        ans = str(row.get("answer") or "").strip()
        idx = letter_index(ans, len(choices))
        if idx is None and ans in choices:
            idx = choices.index(ans)
        if idx is None:
            continue
        cand.append((i, q, choices, idx))
    picked = pick(cand, N_TARGET, rng)
    images = POOL / "nn"
    out = []
    for i, q, choices, idx in picked:
        img = as_pil(ds[i]["image"])
        if img is None:
            continue
        dest = save_pil(img, images / f"cvbench_count_{i}")
        out.append(
            item_row(
                item_id=f"nn_cvbench_{i}",
                image=dest,
                source="nyu-visionx/CV-Bench:Count",
                question=q,
                options=choices,
                correct_index=idx,
                spatial=False,
                numeric=True,
            )
        )
    if len(out) < N_MIN:
        raise RuntimeError(f"NN extracted {len(out)}")
    return out


def sample_sem(rng: random.Random) -> list[dict]:
    files = sorted((DATA / "pope").rglob("random-*.parquet"))
    ds = load_parquet(files[0])
    by_ans = {"yes": [], "no": []}
    for i in range(len(ds)):
        row = ds[i]
        q = str(row.get("question") or "").strip()
        cell, _ = classify_question(q)
        if cell != "SEM":
            continue
        ans = str(row.get("answer") or "").strip().lower()
        if ans not in by_ans:
            continue
        by_ans[ans].append((i, q, ans))
    half = N_TARGET // 2
    picked = []
    for ans in ("yes", "no"):
        rows = list(by_ans[ans])
        rng.shuffle(rows)
        picked.extend(rows[:half])
    images = POOL / "sem"
    out = []
    for i, q, ans in picked:
        img = as_pil(ds[i]["image"])
        if img is None:
            continue
        qid = str(ds[i].get("question_id") or ds[i].get("id") or i)
        dest = save_pil(img, images / f"pope_{qid}")
        out.append(
            item_row(
                item_id=f"sem_pope_{qid}",
                image=dest,
                source="lmms-lab/POPE:Full/random",
                question=q,
                options=YES_NO,
                correct_index=YES_NO.index(ans),
                spatial=False,
                numeric=False,
            )
        )
    if len(out) < N_MIN:
        raise RuntimeError(f"SEM extracted {len(out)}")
    return out


def sample_sn(rng: random.Random) -> list[dict]:
    files = sorted((DATA / "clevr_val").rglob("validation-*.parquet"))
    ds = load_dataset("parquet", data_files=[str(p) for p in files], split="train")
    yesno = []
    counts = []
    used_images: set[int] = set()
    for i in range(len(ds)):
        qa = ds[i]["question_answer"]
        questions = [unbytes(q) for q in qa["question"]]
        answers = [unbytes(a).lower() for a in qa["answer"]]
        for qi, (q, a) in enumerate(zip(questions, answers)):
            cell, _ = classify_question(q)
            if cell != "SN":
                continue
            if a in {"yes", "no"}:
                yesno.append((i, qi, q, a, "yesno"))
            elif a in COUNT_OPTS:
                counts.append((i, qi, q, a, "count"))
    rng.shuffle(yesno)
    rng.shuffle(counts)
    half = N_TARGET // 2
    picked = []
    for bucket in (yesno, counts):
        n = 0
        for row in bucket:
            if n >= half:
                break
            if row[0] in used_images:
                continue
            used_images.add(row[0])
            picked.append(row)
            n += 1
    if len(picked) < N_TARGET:
        rest = [row for row in yesno + counts if row[0] not in used_images]
        rng.shuffle(rest)
        for row in rest:
            if len(picked) >= N_TARGET:
                break
            used_images.add(row[0])
            picked.append(row)
    images = POOL / "sn"
    out = []
    for i, qi, q, a, kind in picked[:N_TARGET]:
        img = as_pil(ds[i]["image"])
        if img is None:
            continue
        dest = save_pil(img, images / f"clevr_val_{i}")
        if kind == "yesno":
            options = YES_NO
            idx = YES_NO.index(a)
        else:
            options = COUNT_OPTS
            idx = COUNT_OPTS.index(a)
        out.append(
            item_row(
                item_id=f"sn_clevr_{i}_{qi}",
                image=dest,
                source="CLEVR_v1.0:val",
                question=q,
                options=options,
                correct_index=idx,
                spatial=True,
                numeric=True,
            )
        )
    if len(out) < N_MIN:
        raise RuntimeError(f"SN extracted {len(out)}")
    return out


def main() -> None:
    rng = random.Random(SEED)
    POOL.mkdir(parents=True, exist_ok=True)
    cells = {
        "SR": sample_sr(rng),
        "SN": sample_sn(rng),
        "NN": sample_nn(rng),
        "SEM": sample_sem(rng),
    }
    items = []
    for cell in ("SR", "SN", "NN", "SEM"):
        items.extend(cells[cell])
    missing = [row["item_id"] for row in items if not Path(row["image"]).is_file()]
    if missing:
        raise RuntimeError(f"missing images: {missing[:5]}")
    by_cell = {cell: len(cells[cell]) for cell in cells}
    payload = {
        "recorded_at": now_iso(),
        "status": "frozen",
        "seed": SEED,
        "target_per_cell": N_TARGET,
        "minimum_per_cell": N_MIN,
        "n_items": len(items),
        "by_cell": by_cell,
        "ready_for_scoring": all(n >= N_MIN for n in by_cell.values()),
        "note": (
            "Frozen E1 scoring pool. Do not retune prompts or drop items after seeing scores. "
            "CLEVR count options are 0-9. CLEVR yes/no and POPE are yes/no. "
            "Vision tower stays F16. analysis_prereg.md must be committed before the first scoring run."
        ),
        "sources": {
            "SR": "What'sUp controlled, 250 CLEVR-style + 250 household when available",
            "SN": "CLEVR val, at most one question per image, half yes/no and half 0-9",
            "NN": "CV-Bench Count, word-rule NN only",
            "SEM": "POPE Full/random, 250 yes + 250 no",
        },
        "items": items,
    }
    path = RESULTS / "scoring_pool.json"
    write_json(path, payload)
    write_inventory()
    print("by_cell", by_cell)
    print("kinds", dict(Counter((row["cell"], len(row["options"])) for row in items)))
    print(path)


if __name__ == "__main__":
    main()
