"""Shared paths and helpers for E1. Scoring is llama.cpp / Metal only."""

from __future__ import annotations

import json
import os
import subprocess
import traceback
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
E1 = ROOT / "e1"
MODELS = ROOT / "models"
DATA = ROOT / "data" / "e1"
RESULTS = ROOT / "results" / "e1"
FIGURES = RESULTS / "figures"
LOGS = ROOT / "logs"

load_dotenv(ROOT / ".env")

HARDWARE = {
    "machine": "Mac16,6",
    "chip": "Apple M4 Max",
    "unified_memory_gib": 36,
    "backend": "Metal/MPS",
    "cuda": False,
    "metal_recommended_max_working_set_gib": 28.08,
    "metal_max_buffer_length_gib": 21.06,
    "practical_budget_gib": {"low": 18, "high": 22},
}

LADDER_LEVELS = ["F16", "Q8_0", "Q6_K", "Q5_K_M", "Q4_K_M", "Q3_K_M", "Q2_K"]
GENERATE_LEVELS = ["Q6_K", "Q5_K_M", "Q4_K_M", "Q3_K_M", "Q2_K"]

MODEL_SPECS = {
    "C": {
        "letter": "C",
        "gguf_repo": "Qwen/Qwen3-VL-2B-Instruct-GGUF",
        "f16_name": "Qwen3VL-2B-Instruct-F16.gguf",
        "q8_name": "Qwen3VL-2B-Instruct-Q8_0.gguf",
        "mmproj_name": "mmproj-Qwen3VL-2B-Instruct-F16.gguf",
        "dir": MODELS / "c" / "gguf",
        "q8_on_disk": MODELS / "c" / "gguf" / "Qwen3VL-2B-Instruct-Q8_0.gguf",
        "mmproj": MODELS / "c" / "gguf" / "mmproj-Qwen3VL-2B-Instruct-F16.gguf",
        "f16_expected_bytes": 3_447_350_304,
    },
    "A": {
        "letter": "A",
        "gguf_repo": "Qwen/Qwen3-VL-8B-Instruct-GGUF",
        "f16_name": "Qwen3VL-8B-Instruct-F16.gguf",
        "q8_name": "Qwen3VL-8B-Instruct-Q8_0.gguf",
        "mmproj_name": "mmproj-Qwen3VL-8B-Instruct-F16.gguf",
        "dir": MODELS / "a" / "gguf",
        "q8_on_disk": MODELS / "a" / "gguf" / "Qwen3VL-8B-Instruct-Q8_0.gguf",
        "mmproj": MODELS / "a" / "gguf" / "mmproj-Qwen3VL-8B-Instruct-F16.gguf",
        "f16_expected_bytes": 16_388_044_896,
    },
}


def hf_token() -> str | None:
    token = os.environ.get("HF_TOKEN", "").strip()
    return token or None


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=str) + "\n")


def figure_path(name: str) -> Path:
    FIGURES.mkdir(parents=True, exist_ok=True)
    return FIGURES / name


def read_json(path: Path) -> dict:
    return json.loads(path.read_text())


def exception_record(exc: BaseException) -> dict:
    return {
        "type": type(exc).__name__,
        "message": str(exc),
        "traceback": traceback.format_exc(),
    }


def llama_runtime_record() -> dict:
    record = {
        "llama_cpp_python": None,
        "llama_cpp_build": None,
        "llama_quantize_path": None,
    }
    try:
        import llama_cpp

        record["llama_cpp_python"] = getattr(llama_cpp, "__version__", "unknown")
        fn = getattr(llama_cpp, "llama_print_system_info", None)
        if callable(fn):
            info = fn()
            if isinstance(info, bytes):
                info = info.decode("utf-8", errors="replace")
            record["llama_cpp_build"] = info
    except Exception as exc:
        record["llama_cpp_python"] = f"error: {exc}"
    record["llama_quantize_path"] = str(llama_quantize_bin()) if llama_quantize_bin() else None
    return record


def llama_quantize_bin() -> Path | None:
    local = E1 / "bin" / "llama-quantize"
    if local.is_file() and os.access(local, os.X_OK):
        return local
    which = subprocess.run(["which", "llama-quantize"], capture_output=True, text=True)
    found = (which.stdout or "").strip()
    return Path(found) if found else None


def gguf_path(letter: str, level: str) -> Path:
    spec = MODEL_SPECS[letter]
    if level == "F16":
        return spec["dir"] / spec["f16_name"]
    if level == "Q8_0":
        return spec["q8_on_disk"]
    return spec["dir"] / spec["f16_name"].replace("-F16.gguf", f"-{level}.gguf")
