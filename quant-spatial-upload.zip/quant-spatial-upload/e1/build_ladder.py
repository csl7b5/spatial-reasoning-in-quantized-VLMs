"""Build the E1 k-quant ladder from official F16 with llama-quantize. C first, then A."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from common import (
    E1,
    GENERATE_LEVELS,
    LADDER_LEVELS,
    MODEL_SPECS,
    RESULTS,
    gguf_path,
    llama_quantize_bin,
    llama_runtime_record,
    now_iso,
    write_json,
)
from gguf_meta import gguf_tensor_params
from inventory import main as write_inventory

PYTHON = Path(sys.executable)
CHECK = E1 / "check_gguf_load.py"


def isolate_load(gguf: Path) -> dict:
    out = RESULTS / "tmp" / f"load_{gguf.stem}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    proc = subprocess.run(
        [str(PYTHON), str(CHECK), "--gguf", str(gguf), "--out", str(out)],
        capture_output=True,
        text=True,
    )
    record = {
        "returncode": proc.returncode,
        "metal_atexit_abort": proc.returncode == -6 or proc.returncode == 134,
        "stdout_tail": (proc.stdout or "")[-2000:],
        "stderr_tail": (proc.stderr or "")[-2000:],
    }
    if out.exists():
        from common import read_json

        payload = read_json(out)
        record.update(payload)
        # E0: process often SIGABRT after a successful generate.
        if payload.get("status") == "PASS":
            record["status"] = "PASS"
    elif proc.returncode == 0:
        record["status"] = "FAIL"
        record["error"] = "load script wrote no JSON"
    else:
        record["status"] = "FAIL"
    return record


def quantize_one(src: Path, dest: Path, level: str) -> dict:
    bin_path = llama_quantize_bin()
    if bin_path is None:
        raise FileNotFoundError("llama-quantize not found")
    dest.parent.mkdir(parents=True, exist_ok=True)
    started = now_iso()
    proc = subprocess.run(
        [str(bin_path), str(src), str(dest), level],
        capture_output=True,
        text=True,
    )
    return {
        "started_at": started,
        "finished_at": now_iso(),
        "returncode": proc.returncode,
        "cmd": [str(bin_path), str(src), str(dest), level],
        "stdout_tail": (proc.stdout or "")[-4000:],
        "stderr_tail": (proc.stderr or "")[-4000:],
        "ok": proc.returncode == 0 and dest.is_file(),
    }


def describe_file(path: Path, f16_bytes: int | None) -> dict:
    meta = gguf_tensor_params(path)
    row = {
        "path": str(path),
        "exists": True,
        **meta,
        "gb": round(meta["bytes"] / 1e9, 4),
    }
    if f16_bytes:
        row["size_vs_f16"] = round(meta["bytes"] / f16_bytes, 4)
        row["implied_bpw_from_f16"] = round(16.0 * meta["bytes"] / f16_bytes, 4)
    return row


def build_model(letter: str, skip_load: bool) -> dict:
    spec = MODEL_SPECS[letter]
    f16 = gguf_path(letter, "F16")
    payload: dict = {
        "model": letter,
        "started_at": now_iso(),
        "status": "FAIL",
        "f16": str(f16),
        "levels": {},
    }
    if not f16.is_file():
        payload["error"] = f"missing F16 {f16}"
        payload["finished_at"] = now_iso()
        return payload
    if f16.stat().st_size != spec["f16_expected_bytes"]:
        payload["error"] = {
            "message": "F16 byte count does not match Hub listing",
            "bytes": f16.stat().st_size,
            "expected": spec["f16_expected_bytes"],
        }
        payload["finished_at"] = now_iso()
        return payload

    f16_bytes = f16.stat().st_size
    for level in LADDER_LEVELS:
        path = gguf_path(letter, level)
        row: dict = {"level": level, "path": str(path), "source": None}
        if level in GENERATE_LEVELS and not path.is_file():
            row["source"] = "llama-quantize from F16"
            row["quantize"] = quantize_one(f16, path, level)
            if not row["quantize"]["ok"]:
                payload["levels"][level] = row
                payload["error"] = f"quantize failed for {letter} {level}"
                payload["finished_at"] = now_iso()
                return payload
        elif level == "Q8_0":
            row["source"] = "already on disk from E0 (official Hub Q8_0, not requantized)"
        elif level == "F16":
            row["source"] = "official Hub F16"
        else:
            row["source"] = "already on disk"
        if not path.is_file():
            row["exists"] = False
            payload["levels"][level] = row
            payload["error"] = f"missing {path}"
            payload["finished_at"] = now_iso()
            return payload
        row.update(describe_file(path, f16_bytes))
        if skip_load:
            row["load_check"] = {"status": "SKIPPED", "note": "use --load to run"}
        else:
            row["load_check"] = isolate_load(path)
        payload["levels"][level] = row

    failed = [
        level
        for level, row in payload["levels"].items()
        if row.get("load_check", {}).get("status") not in {"PASS", "SKIPPED"}
    ]
    payload["status"] = "FAIL" if failed else "PASS"
    payload["failed_load_checks"] = failed
    payload["finished_at"] = now_iso()
    return payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=["C", "A", "both"], default="C")
    parser.add_argument(
        "--load",
        action="store_true",
        help="Run a 20-token Metal load check after each file (isolated subprocess).",
    )
    args = parser.parse_args()
    letters = ["C", "A"] if args.model == "both" else [args.model]
    runtime = llama_runtime_record()
    results = []
    for letter in letters:
        print(f"Building ladder for model {letter}...")
        row = build_model(letter, skip_load=not args.load)
        write_json(RESULTS / f"p2_ladder_{letter}.json", row)
        results.append(row)
        print(row["status"], letter, list(row.get("levels", {}).keys()))
        if row["status"] != "PASS":
            break
    payload = {
        "recorded_at": now_iso(),
        "runtime": runtime,
        "models": results,
        "status": "PASS" if results and all(r["status"] == "PASS" for r in results) else "FAIL",
    }
    write_json(RESULTS / "p2_ladder.json", payload)
    write_inventory()
    print(payload["status"])


if __name__ == "__main__":
    main()
