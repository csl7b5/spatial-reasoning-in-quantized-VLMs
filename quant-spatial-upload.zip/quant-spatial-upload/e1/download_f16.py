"""Download official F16 GGUF for Model C, then Model A. Does not download B."""

from __future__ import annotations

from huggingface_hub import hf_hub_download

from common import MODEL_SPECS, RESULTS, hf_token, now_iso, write_json
from inventory import main as write_inventory


def download_one(letter: str) -> dict:
    spec = MODEL_SPECS[letter]
    dest_dir = spec["dir"]
    dest_dir.mkdir(parents=True, exist_ok=True)
    started = now_iso()
    path = hf_hub_download(
        repo_id=spec["gguf_repo"],
        filename=spec["f16_name"],
        local_dir=dest_dir,
        token=hf_token(),
    )
    from pathlib import Path

    p = Path(path)
    size = p.stat().st_size
    return {
        "model": letter,
        "repo": spec["gguf_repo"],
        "filename": spec["f16_name"],
        "path": str(p),
        "started_at": started,
        "finished_at": now_iso(),
        "bytes": size,
        "gb": round(size / 1e9, 4),
        "expected_bytes": spec["f16_expected_bytes"],
        "match": size == spec["f16_expected_bytes"],
    }


def main() -> None:
    token = hf_token()
    records = []
    for letter in ("C", "A"):
        print(f"Downloading F16 for model {letter}...")
        records.append(download_one(letter))
        print(records[-1])
    payload = {
        "recorded_at": now_iso(),
        "token_source": "HF_TOKEN env" if token else "none (public repo)",
        "token_written_to_source": False,
        "human_approved": True,
        "approved_note": "User said continue after the 19.84 GB F16 ask.",
        "model_b_downloaded": False,
        "downloads": records,
        "total_gb": round(sum(row["bytes"] for row in records) / 1e9, 4),
    }
    write_json(RESULTS / "p2_f16_download.json", payload)
    write_inventory()
    print(f"F16 download total {payload['total_gb']} GB")


if __name__ == "__main__":
    main()
