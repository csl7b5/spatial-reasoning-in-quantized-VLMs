"""Eval a vision chat prompt once, then score option strings from the same KV."""

from __future__ import annotations

import base64
import ctypes
from pathlib import Path

from llama_cpp import Llama
from llama_cpp.llama_chat_format import MTMDChatHandler
import llama_cpp.llama_cpp as llama_cpp

PROMPT = "Which caption matches the image?"
GENERATE_PROMPT = 'Which caption matches the image? Reply as JSON: {"caption": "..."}'

# P3 pin. What'sUp controlled photos are already this size. Later datasets get resized.
PIN_WIDTH = 1280
PIN_HEIGHT = 960
PIN_MIN_PIXELS = PIN_WIDTH * PIN_HEIGHT
PIN_MAX_PIXELS = PIN_WIDTH * PIN_HEIGHT
PIN_IMAGE_TOKENS = 1200
N_CTX = 8192


def sync_n_tokens(llm: Llama) -> int:
    """mtmd_helper_eval_chunk_single can return a stale n_past on Qwen3-VL."""
    mem = llama_cpp.llama_get_memory(llm._ctx.ctx)
    if mem is None:
        raise RuntimeError("llama_get_memory returned None")
    pos_max = llama_cpp.llama_memory_seq_pos_max(mem, 0)
    if pos_max < 0:
        raise RuntimeError("empty KV after vision eval")
    llm.n_tokens = int(pos_max) + 1
    return llm.n_tokens


def resolution_pin() -> dict:
    return {
        "method": "fixed_resize_plus_mtmd_token_budget",
        "width": PIN_WIDTH,
        "height": PIN_HEIGHT,
        "min_pixels": PIN_MIN_PIXELS,
        "max_pixels": PIN_MAX_PIXELS,
        "image_min_tokens": PIN_IMAGE_TOKENS,
        "image_max_tokens": PIN_IMAGE_TOKENS,
        "expected_image_tokens": PIN_IMAGE_TOKENS,
    }


def make_handler(mmproj: str | Path) -> MTMDChatHandler:
    handler = MTMDChatHandler(clip_model_path=str(mmproj), verbose=False)

    def _init_mtmd_context(llama_model: Llama) -> None:
        from llama_cpp._utils import suppress_stdout_stderr

        handler.verbose = llama_model.verbose
        if handler.mtmd_ctx is not None:
            return
        with suppress_stdout_stderr(disable=handler.verbose):
            ctx_params = handler._mtmd_cpp.mtmd_context_params_default()
            ctx_params.use_gpu = handler.use_gpu
            ctx_params.print_timings = handler.verbose
            ctx_params.n_threads = llama_model.n_threads
            ctx_params.flash_attn_type = (
                llama_cpp.LLAMA_FLASH_ATTN_TYPE_ENABLED
                if (
                    llama_model.context_params.flash_attn_type
                    == llama_cpp.LLAMA_FLASH_ATTN_TYPE_ENABLED
                )
                else llama_cpp.LLAMA_FLASH_ATTN_TYPE_DISABLED
            )
            ctx_params.image_min_tokens = PIN_IMAGE_TOKENS
            ctx_params.image_max_tokens = PIN_IMAGE_TOKENS
            handler.mtmd_ctx = handler._mtmd_cpp.mtmd_init_from_file(
                handler.clip_model_path.encode(), llama_model.model, ctx_params
            )
            if handler.mtmd_ctx is None:
                raise ValueError(f"Failed to load mtmd context from: {handler.clip_model_path}")
            if not handler._mtmd_cpp.mtmd_support_vision(handler.mtmd_ctx):
                raise ValueError("Vision is not supported by this model")

            def mtmd_free() -> None:
                with suppress_stdout_stderr(disable=handler.verbose):
                    if handler.mtmd_ctx is not None:
                        handler._mtmd_cpp.mtmd_free(handler.mtmd_ctx)
                        handler.mtmd_ctx = None

            handler._exit_stack.callback(mtmd_free)

    handler._init_mtmd_context = _init_mtmd_context
    return handler


def _image_data_url(path: Path) -> str:
    from PIL import Image
    import io

    image = Image.open(path).convert("RGB")
    if image.size != (PIN_WIDTH, PIN_HEIGHT):
        image = image.resize((PIN_WIDTH, PIN_HEIGHT), Image.Resampling.LANCZOS)
    buf = io.BytesIO()
    image.save(buf, format="JPEG", quality=95)
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return f"data:image/jpeg;base64,{b64}"


def eval_vision_prompt(llm: Llama, handler: MTMDChatHandler, image_path: Path, text: str) -> tuple[int, int]:
    """Mirror MTMDChatHandler prompt eval. Leaves KV filled. Returns n_tokens."""
    handler._init_mtmd_context(llm)
    assert handler.mtmd_ctx is not None
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": _image_data_url(image_path)}},
                {"type": "text", "text": text},
            ],
        }
    ]
    image_urls = handler.get_image_urls(messages)
    media_marker = handler._mtmd_cpp.mtmd_default_marker().decode("utf-8")
    from jinja2.sandbox import ImmutableSandboxedEnvironment
    import jinja2
    from llama_cpp.llama_chat_format import Jinja2ChatFormatter

    template_env = ImmutableSandboxedEnvironment(
        trim_blocks=True,
        lstrip_blocks=True,
        extensions=[Jinja2ChatFormatter.IgnoreGenerationTags, jinja2.ext.loopcontrols],
    )
    template_env.filters["tojson"] = Jinja2ChatFormatter.tojson
    template = template_env.from_string(handler._get_chat_template(llm))
    rendered = template.render(
        messages=handler._get_template_messages(messages, media_marker),
        add_generation_prompt=True,
        eos_token=handler._decode_token_piece(llm.detokenize([llm.token_eos()])),
        bos_token=handler._decode_token_piece(llm.detokenize([llm.token_bos()])),
        raise_exception=lambda message: (_ for _ in ()).throw(ValueError(message)),
    )
    rendered = handler._postprocess_template_text(rendered, image_urls, media_marker)

    bitmaps = []
    try:
        for image_url in image_urls:
            image_bytes = handler.load_image(image_url)
            bitmaps.append(handler._create_bitmap_from_bytes(image_bytes))

        input_text = handler._mtmd_cpp.mtmd_input_text()
        input_text.text = rendered.encode("utf-8")
        input_text.add_special = True
        input_text.parse_special = True
        chunks = handler._mtmd_cpp.mtmd_input_chunks_init()
        if chunks is None:
            raise ValueError("Failed to create input chunks")
        try:
            bitmap_array = (handler._mtmd_cpp.mtmd_bitmap_p_ctypes * len(bitmaps))(*bitmaps)
            result = handler._mtmd_cpp.mtmd_tokenize(
                handler.mtmd_ctx,
                chunks,
                ctypes.byref(input_text),
                bitmap_array,
                len(bitmaps),
            )
            if result != 0:
                raise ValueError(f"mtmd_tokenize failed: {result}")
            llm.reset()
            llm._ctx.kv_cache_clear()
            image_tokens = 0
            n_chunks = handler._mtmd_cpp.mtmd_input_chunks_size(chunks)
            for i in range(n_chunks):
                chunk = handler._mtmd_cpp.mtmd_input_chunks_get(chunks, i)
                if chunk is None:
                    continue
                chunk_type = handler._mtmd_cpp.mtmd_input_chunk_get_type(chunk)
                if chunk_type == handler._mtmd_cpp.MTMD_INPUT_CHUNK_TYPE_TEXT:
                    n_tokens_out = ctypes.c_size_t()
                    tokens_ptr = handler._mtmd_cpp.mtmd_input_chunk_get_tokens_text(
                        chunk, ctypes.byref(n_tokens_out)
                    )
                    if tokens_ptr and n_tokens_out.value > 0:
                        tokens = [tokens_ptr[j] for j in range(n_tokens_out.value)]
                        if llm.n_tokens + len(tokens) > llm.n_ctx():
                            raise ValueError("prompt exceeds n_ctx")
                        llm.eval(tokens)
                elif chunk_type in {
                    handler._mtmd_cpp.MTMD_INPUT_CHUNK_TYPE_IMAGE,
                    handler._mtmd_cpp.MTMD_INPUT_CHUNK_TYPE_AUDIO,
                }:
                    chunk_n_tokens = handler._mtmd_cpp.mtmd_input_chunk_get_n_tokens(chunk)
                    if llm.n_tokens + chunk_n_tokens > llm.n_ctx():
                        raise ValueError("prompt exceeds n_ctx")
                    new_n_past = llama_cpp.llama_pos(0)
                    result = handler._mtmd_cpp.mtmd_helper_eval_chunk_single(
                        handler.mtmd_ctx,
                        llm._ctx.ctx,
                        chunk,
                        llama_cpp.llama_pos(llm.n_tokens),
                        llama_cpp.llama_seq_id(0),
                        llm.n_batch,
                        False,
                        ctypes.byref(new_n_past),
                    )
                    if result != 0:
                        raise ValueError(f"mtmd_helper_eval_chunk_single failed: {result}")
                    # new_n_past and memory_seq_pos_max under-count Qwen3-VL image tokens.
                    llm.n_tokens = int(llm.n_tokens) + int(chunk_n_tokens)
                    image_tokens += int(chunk_n_tokens)
        finally:
            handler._mtmd_cpp.mtmd_input_chunks_free(chunks)
    finally:
        for bitmap in bitmaps:
            handler._mtmd_cpp.mtmd_bitmap_free(bitmap)
    sync_n_tokens(llm)
    if llm.n_tokens < 1:
        raise RuntimeError("vision prompt produced no tokens")
    if llm.n_tokens < 200:
        raise RuntimeError(
            f"vision prompt only produced {llm.n_tokens} tokens; image likely missing from KV"
        )
    return int(llm.n_tokens), int(image_tokens)


def rewind_to(llm: Llama, n_tokens: int) -> None:
    llm._ctx.kv_cache_seq_rm(-1, n_tokens, -1)
    llm.n_tokens = n_tokens


def score_text(llm: Llama, text: str, prompt_n: int) -> dict:
    tokens = llm.tokenize(text.encode("utf-8"), add_bos=False, special=False)
    if not tokens:
        raise ValueError(f"option produced no tokens: {text!r}")
    token_logprobs = []
    for tok in tokens:
        logits = llm.scores[llm.n_tokens - 1]
        logprobs = Llama.logits_to_logprobs(logits)
        token_logprobs.append(float(logprobs[int(tok)]))
        llm.eval([tok])
    rewind_to(llm, prompt_n)
    pieces = [llm.detokenize([tok]).decode("utf-8", errors="replace") for tok in tokens]
    return {
        "n_tokens": len(tokens),
        "token_ids": [int(t) for t in tokens],
        "token_pieces": pieces,
        "token_logprobs": token_logprobs,
        "sum_logprob": float(sum(token_logprobs)),
    }


def greedy_continue(llm: Llama, max_tokens: int = 64) -> dict:
    eos = llm.token_eos()
    tokens = []
    for _ in range(max_tokens):
        logits = llm.scores[llm.n_tokens - 1]
        tok = int(logits.argmax())
        if tok == eos:
            break
        tokens.append(tok)
        llm.eval([tok])
    text = llm.detokenize(tokens).decode("utf-8", errors="replace") if tokens else ""
    return {"n_tokens": len(tokens), "token_ids": tokens, "text": text}


def score_item(llm: Llama, handler: MTMDChatHandler, item: dict, prompt: str = PROMPT) -> dict:
    image = Path(item["image"])
    prompt_n, image_tokens = eval_vision_prompt(llm, handler, image, prompt)
    options = []
    for text in item["options"]:
        options.append({"text": text, **score_text(llm, text, prompt_n)})
    correct_index = int(item["correct_index"])
    return {
        "item_id": item["item_id"],
        "image": str(image),
        "prompt_n_tokens": prompt_n,
        "image_n_tokens": image_tokens,
        "options": options,
        "correct_index": correct_index,
        "correct_sum_logprob": options[correct_index]["sum_logprob"],
    }
