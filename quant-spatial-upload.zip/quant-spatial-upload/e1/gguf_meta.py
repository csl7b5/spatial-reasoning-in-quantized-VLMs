"""Read GGUF tensor shapes so we can report measured bits-per-weight."""

from __future__ import annotations

import struct
from pathlib import Path

_GGUF_VALUE = {
    0: 1,   # UINT8
    1: 1,   # INT8
    2: 2,   # UINT16
    3: 2,   # INT16
    4: 4,   # UINT32
    5: 4,   # INT32
    6: 4,   # FLOAT32
    7: 1,   # BOOL
    10: 8,  # UINT64
    11: 8,  # INT64
    12: 8,  # FLOAT64
}


def _read_string(fh) -> str:
    (n,) = struct.unpack("<Q", fh.read(8))
    return fh.read(n).decode("utf-8", errors="replace")


def _skip_value(fh, vtype: int) -> None:
    if vtype == 8:  # STRING
        _read_string(fh)
        return
    if vtype == 9:  # ARRAY
        (inner,) = struct.unpack("<I", fh.read(4))
        (count,) = struct.unpack("<Q", fh.read(8))
        for _ in range(count):
            _skip_value(fh, inner)
        return
    size = _GGUF_VALUE.get(vtype)
    if size is None:
        raise ValueError(f"unknown GGUF value type {vtype}")
    fh.read(size)


def gguf_tensor_params(path: Path) -> dict:
    with path.open("rb") as fh:
        magic = fh.read(4)
        if magic != b"GGUF":
            raise ValueError(f"{path} is not GGUF")
        (version,) = struct.unpack("<I", fh.read(4))
        n_tensors, n_kv = struct.unpack("<QQ", fh.read(16))
        for _ in range(n_kv):
            _read_string(fh)
            (vtype,) = struct.unpack("<I", fh.read(4))
            _skip_value(fh, vtype)
        n_params = 0
        names = []
        for _ in range(n_tensors):
            name = _read_string(fh)
            (n_dims,) = struct.unpack("<I", fh.read(4))
            dims = struct.unpack("<" + "Q" * n_dims, fh.read(8 * n_dims))
            fh.read(4)  # ggml type
            fh.read(8)  # offset
            elems = 1
            for d in dims:
                elems *= d
            n_params += elems
            names.append(name)
    size = path.stat().st_size
    return {
        "gguf_version": version,
        "n_tensors": n_tensors,
        "n_params": n_params,
        "bytes": size,
        "bits_per_weight": round((size * 8) / n_params, 4) if n_params else None,
    }
