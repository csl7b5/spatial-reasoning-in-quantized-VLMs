"""Scan downloaded experiment files and write a living inventory plus delete notes."""

from __future__ import annotations

from pathlib import Path

from common import MODELS, ROOT, now_iso, write_json

INVENTORY = ROOT / "results" / "DOWNLOAD_INVENTORY.json"
DELETE_NOTES = ROOT / "results" / "HOW_TO_DELETE.md"

KEEP_UNTIL = {
    "e0_transformers_bf16": "E3 (hidden states). E1 does not use these.",
    "e0_q8_0": "E1 scoring ladder (already the Q8_0 point).",
    "e0_mmproj_f16": "E1 through E4. Vision tower stays F16.",
    "e1_f16_gguf": "E1 reference and the source file for llama-quantize.",
    "e1_generated_kquants": "E1 scoring. E2 may reuse them with --imatrix.",
    "e1_benchmark_images": "E1 through the last phase that scores those items.",
}


def _files_under(path: Path) -> list[dict]:
    rows = []
    if not path.exists():
        return rows
    for child in sorted(path.rglob("*")):
        if not child.is_file():
            continue
        if ".cache" in child.parts or child.name in {".DS_Store"}:
            continue
        rows.append(
            {
                "path": str(child),
                "bytes": child.stat().st_size,
                "gb": round(child.stat().st_size / 1e9, 4),
            }
        )
    return rows


def classify(path: str) -> dict:
    p = path.lower()
    if "/transformers/" in p and p.endswith(".safetensors"):
        return {
            "kind": "e0_transformers_bf16",
            "used_in": "E0, E3",
            "delete_after": KEEP_UNTIL["e0_transformers_bf16"],
        }
    if "mmproj" in p and p.endswith(".gguf"):
        return {
            "kind": "e0_mmproj_f16",
            "used_in": "E0, E1, E2, E4",
            "delete_after": KEEP_UNTIL["e0_mmproj_f16"],
        }
    if p.endswith("-f16.gguf"):
        return {
            "kind": "e1_f16_gguf",
            "used_in": "E1 reference + quantize source",
            "delete_after": KEEP_UNTIL["e1_f16_gguf"],
        }
    if p.endswith("-q8_0.gguf"):
        return {
            "kind": "e0_q8_0",
            "used_in": "E0, E1 ladder",
            "delete_after": KEEP_UNTIL["e0_q8_0"],
        }
    if p.endswith(".gguf"):
        return {
            "kind": "e1_generated_kquants",
            "used_in": "E1, maybe E2",
            "delete_after": KEEP_UNTIL["e1_generated_kquants"],
        }
    if "/data/" in p:
        return {
            "kind": "e1_benchmark_images",
            "used_in": "E1+",
            "delete_after": KEEP_UNTIL["e1_benchmark_images"],
        }
    return {"kind": "other", "used_in": "support files", "delete_after": "safe with its folder"}


def main() -> None:
    model_files = _files_under(MODELS)
    data_files = _files_under(ROOT / "data")
    rows = []
    total = 0
    for row in model_files + data_files:
        meta = classify(row["path"])
        rows.append({**row, **meta})
        total += row["bytes"]

    by_kind: dict[str, dict] = {}
    for row in rows:
        bucket = by_kind.setdefault(row["kind"], {"n_files": 0, "bytes": 0})
        bucket["n_files"] += 1
        bucket["bytes"] += row["bytes"]
    for bucket in by_kind.values():
        bucket["gb"] = round(bucket["bytes"] / 1e9, 4)

    payload = {
        "recorded_at": now_iso(),
        "root": str(ROOT),
        "n_files": len(rows),
        "total_bytes": total,
        "total_gb": round(total / 1e9, 4),
        "by_kind": by_kind,
        "not_in_this_repo": [
            {
                "name": "Muse Glimmer",
                "where": "Ollama muse-glimmer:30b-mlx",
                "size_gb": 21,
                "delete": "Do not delete as part of this project. It was already on the machine.",
            }
        ],
        "files": rows,
        "delete_when_all_phases_done": [
            "rm -rf models/",
            "rm -rf data/e1/",
            "Optional HF cache inside models/*/.cache",
        ],
    }
    write_json(INVENTORY, payload)

    lines = [
        "# How to get rid of the downloads",
        "",
        f"Last scan: {payload['recorded_at']}",
        f"Tracked files in this repo: **{payload['total_gb']} GB** across {payload['n_files']} files.",
        "",
        "By kind:",
        "",
        "| GB | Kind | Files |",
        "|---|---|---|",
    ]
    for kind, bucket in sorted(payload["by_kind"].items(), key=lambda kv: -kv[1]["bytes"]):
        if bucket["gb"] < 0.01:
            continue
        lines.append(f"| {bucket['gb']:.2f} | {kind} | {bucket['n_files']} |")
    lines.extend(
        [
        "",
        "All of this lives under the repo root.",
        "Git already ignores `models/`, `data/`, and `results/`. Deleting those folders does not change git history.",
        "",
        "## Do not delete",
        "",
        "- `muse-glimmer:30b-mlx` in Ollama. That was already on this Mac. It is not part of E0/E1.",
        "- `.venv/` unless you also want to reinstall Python packages.",
        "- `e0/` and `e1/` code, and the JSON notes you want to keep.",
        "",
        "## After E1 only (keep if E2–E4 will run)",
        "",
        "Do **not** delete the F16 GGUF files or the F16 mmproj files. E2 and E4 still need them.",
        "Do **not** delete `models/*/transformers/` until E3 is done. E1 does not use those files, but E3 does.",
        "",
        "## After the whole project (E0–E4 finished)",
        "",
        "This frees the model weights and any downloaded benchmark images:",
        "",
        "```bash",
        "cd <repo-root>",
        "rm -rf models/",
        "rm -rf data/e1/",
        "```",
        "",
        "If you also want the machine notes and charts gone:",
        "",
        "```bash",
        "rm -rf results/",
        "```",
        "",
        "If Hugging Face left a cache in your home folder:",
        "",
        "```bash",
        "rm -rf ~/.cache/huggingface/hub/models--Qwen--Qwen3-VL-*",
        "```",
        "",
        "Only run that home-folder command if you do not need those models for another project.",
        "",
        "Local tools (not model weights; safe to delete anytime and rebuild):",
        "",
        "```bash",
        "rm -rf e1/bin/          # llama-quantize + dylibs, about 10 MB",
        "rm -rf /tmp/llama.cpp   # source tree used to build that binary",
        "```",
        "",
        "## What is here now",
        "",
        "| GB | Kind | Keep until | Path |",
        "|---|---|---|---|",
        ]
    )
    for row in rows:
        if row["gb"] < 0.01:
            continue
        lines.append(
            f"| {row['gb']:.2f} | {row['kind']} | {row['delete_after']} | `{row['path']}` |"
        )
    lines.append("")
    lines.append(f"Refresh this list: `python e1/inventory.py`")
    lines.append("")
    DELETE_NOTES.write_text("\n".join(lines))
    print(f"{payload['total_gb']} GB in {payload['n_files']} files")
    print(INVENTORY)
    print(DELETE_NOTES)


if __name__ == "__main__":
    main()
