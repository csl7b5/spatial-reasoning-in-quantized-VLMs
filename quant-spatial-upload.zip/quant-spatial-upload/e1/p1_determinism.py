"""P1: 30 items × 3 runs at F16 and Q4_K_M. Stop if max |Δ| > 0.1 nats."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from common import E1, RESULTS, gguf_path, now_iso, read_json, write_json
from inventory import main as write_inventory

PYTHON = Path(sys.executable)
WORKER = E1 / "p1_score_run.py"
ITEMS = RESULTS / "p1_items.json"
THRESHOLD = 0.1
LEVELS = ("F16", "Q4_K_M")


def run_worker(letter: str, level: str) -> dict:
    out = RESULTS / "p1" / f"{letter}_{level}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        [
            str(PYTHON),
            str(WORKER),
            "--model",
            letter,
            "--level",
            level,
            "--items",
            str(ITEMS),
            "--out",
            str(out),
        ],
        capture_output=True,
        text=True,
    )
    payload = {
        "returncode": proc.returncode,
        "metal_atexit_abort": proc.returncode in {-6, 134},
        "stdout_tail": (proc.stdout or "")[-2000:],
        "stderr_tail": (proc.stderr or "")[-2000:],
        "out": str(out),
    }
    if out.exists():
        body = read_json(out)
        payload["status"] = body.get("status", "FAIL")
        payload["load_s"] = body.get("load_s")
        payload["n_items"] = body.get("n_items")
        payload["passes"] = body.get("passes")
        payload["error"] = body.get("error")
        if body.get("status") == "PASS":
            payload["status"] = "PASS"
    else:
        payload["status"] = "FAIL"
        payload["error"] = "worker wrote no JSON"
    return payload


def summarize_level(level_payload: dict) -> dict:
    passes = level_payload.get("passes") or []
    per_item = {}
    for run in passes:
        for item in run.get("items") or []:
            row = per_item.setdefault(
                item["item_id"],
                {
                    "item_id": item["item_id"],
                    "prompt_n_tokens": item.get("prompt_n_tokens"),
                    "correct_sum_logprobs": [],
                },
            )
            row["correct_sum_logprobs"].append(item["correct_sum_logprob"])
    items = []
    max_abs = 0.0
    for row in per_item.values():
        vals = row["correct_sum_logprobs"]
        spread = max(vals) - min(vals) if vals else None
        row["max_abs_delta"] = spread
        if spread is not None:
            max_abs = max(max_abs, spread)
        items.append(row)
    return {
        "n_items": len(items),
        "n_runs": len(passes),
        "max_abs_delta": max_abs,
        "threshold_nats": THRESHOLD,
        "pass": max_abs <= THRESHOLD if items else False,
        "items": items,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=["C", "A", "both"], default="both")
    args = parser.parse_args()
    if not ITEMS.is_file():
        raise SystemExit(f"missing {ITEMS}; run python e1/download_whatsup.py first")
    letters = ["C", "A"] if args.model == "both" else [args.model]
    models = []
    overall = "PASS"
    stop = False
    stop_reason = None
    for letter in letters:
        model_row = {"model": letter, "levels": {}, "status": "PASS"}
        for level in LEVELS:
            path = gguf_path(letter, level)
            print(f"P1 {letter} {level} {path.name}...")
            raw = run_worker(letter, level)
            summary = summarize_level(raw) if raw.get("status") == "PASS" else None
            model_row["levels"][level] = {"raw_status": raw.get("status"), "summary": summary, "error": raw.get("error")}
            if raw.get("status") != "PASS":
                model_row["status"] = "FAIL"
                overall = "FAIL"
                stop = True
                stop_reason = f"{letter} {level} worker failed"
                break
            if summary and not summary["pass"]:
                model_row["status"] = "FAIL"
                overall = "FAIL"
                stop = True
                stop_reason = (
                    f"{letter} {level} max |Δ| = {summary['max_abs_delta']:.4f} nats > {THRESHOLD}"
                )
                break
        models.append(model_row)
        if stop:
            break
    payload = {
        "phase": "P1",
        "recorded_at": now_iso(),
        "status": overall,
        "stop": stop,
        "stop_reason": stop_reason,
        "threshold_nats": THRESHOLD,
        "items_path": str(ITEMS),
        "n_items": read_json(ITEMS)["n_items"],
        "repeats": 3,
        "levels": list(LEVELS),
        "prompt_tuned": False,
        "models": models,
    }
    write_json(RESULTS / "p1.json", payload)
    write_inventory()
    print(f"P1 {overall} stop={stop} {stop_reason or ''}")
    if stop:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
