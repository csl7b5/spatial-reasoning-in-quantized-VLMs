"""Download CLEVR validation parquets only (not train/test, not the 18 GB zip)."""

from __future__ import annotations

from huggingface_hub import list_repo_files

from common import DATA, RESULTS, now_iso, write_json
from download_label_samples import fetch_file
from inventory import main as write_inventory

REPO = "dpdl-benchmark/clevr"
DEST = DATA / "clevr_val"


def main() -> None:
    names = list_repo_files(REPO, repo_type="dataset")
    wanted = sorted(n for n in names if n.startswith("data/validation-") and n.endswith(".parquet"))
    if len(wanted) < 1:
        raise SystemExit(f"no data/validation-*.parquet on {REPO}")
    rows = []
    for name in wanted:
        path = fetch_file(REPO, name, DEST)
        rows.append({"filename": name, "path": str(path), "bytes": path.stat().st_size})
        print(f"{name} -> {path} ({path.stat().st_size} bytes)")
    write_json(
        RESULTS / "clevr_val_download.json",
        {
            "recorded_at": now_iso(),
            "repo": REPO,
            "license": "CLEVR source is CC-BY-4.0",
            "files": rows,
            "total_bytes": sum(r["bytes"] for r in rows),
            "note": "Validation parquets only. Train/test and the official 18 GB zip were not downloaded.",
        },
    )
    write_inventory()


if __name__ == "__main__":
    main()
