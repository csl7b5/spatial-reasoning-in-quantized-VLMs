"""Build the hand-label queue. Keeps existing SR What'sUp items; appends SN/NN/SEM samples."""

from __future__ import annotations

import random

from common import DATA, RESULTS, now_iso, read_json, write_json
from download_whatsup import CONTROLLED_SOURCES, load_controlled

SEED = 20260815
N_PER_CELL = 50
N_PER_WHATSUP_SUBSET = 25

SAMPLE_FILES = {
    "SN": DATA / "blink" / "items.json",
    "NN": DATA / "mathvista" / "items.json",
    "SEM": DATA / "pope" / "items.json",
}


def proposed_cell(spatial: bool, numeric: bool) -> str:
    if spatial and not numeric:
        return "SR"
    if spatial and numeric:
        return "SN"
    if (not spatial) and numeric:
        return "NN"
    return "SEM"


def sample_whatsup_sr() -> list[dict]:
    pool = load_controlled()
    by_src: dict[str, list[dict]] = {name: [] for name in CONTROLLED_SOURCES}
    for item in pool:
        by_src[item["source"]].append(item)
    rng = random.Random(SEED)
    chosen = []
    for name in CONTROLLED_SOURCES:
        rows = list(by_src[name])
        rng.shuffle(rows)
        chosen.extend(rows[:N_PER_WHATSUP_SUBSET])
    chosen.sort(key=lambda row: row["item_id"])
    out = []
    for item in chosen:
        out.append(
            {
                **item,
                "question": "Which caption matches the image?",
                "proposed_spatial": True,
                "proposed_numeric": False,
                "proposed_cell": "SR",
                "label_note": "What'sUp controlled photo. Auto-proposed SR. Confirm or correct.",
            }
        )
    return out


def load_sample(cell: str) -> list[dict]:
    path = SAMPLE_FILES[cell]
    if not path.is_file():
        return []
    return list(read_json(path).get("items") or [])


def main() -> None:
    items = sample_whatsup_sr()
    for cell in ("SN", "NN", "SEM"):
        items.extend(load_sample(cell))
    seen: set[str] = set()
    unique = []
    for item in items:
        if item["item_id"] in seen:
            continue
        seen.add(item["item_id"])
        unique.append(item)
    items = unique
    counts = {"SR": 0, "SN": 0, "NN": 0, "SEM": 0}
    for item in items:
        counts[item.get("proposed_cell", "SEM")] = counts.get(item.get("proposed_cell", "SEM"), 0) + 1
    payload = {
        "recorded_at": now_iso(),
        "seed": SEED,
        "target_per_cell": N_PER_CELL,
        "note": "Hand-label queue. SR from What'sUp. SN/NN/SEM are labeling samples only, not the full scoring pools. Existing hand_labels.json is not modified.",
        "n_items": len(items),
        "by_proposed_cell": counts,
        "items": items,
    }
    path = RESULTS / "label_queue.json"
    write_json(path, payload)
    print(f"{payload['n_items']} items -> {path}")
    print("Proposed cells:", payload["by_proposed_cell"])
    print("Existing labels in results/e1/hand_labels.json are left as-is.")
    print("Refresh http://127.0.0.1:8765 if the labeler is already open.")


if __name__ == "__main__":
    main()
