"""Download What'sUp controlled photos and freeze the P1 30-item list."""

from __future__ import annotations

import json
import random
import zipfile
from pathlib import Path

from huggingface_hub import hf_hub_download

from common import DATA, RESULTS, hf_token, now_iso, write_json
from inventory import main as write_inventory

WHATSUP = DATA / "whatsup"
IMAGES = WHATSUP / "images"
EXAMPLES = WHATSUP / "examples.jsonl"
ZIP_NAME = "images.zip"
REPO = "Mayfull/whats_up_vlms"
SEED = 20260815
N_PER_SUBSET = 15
CONTROLLED_SOURCES = ("controlled_images_dataset", "controlled_clevr_dataset")


def download() -> dict:
    WHATSUP.mkdir(parents=True, exist_ok=True)
    token = hf_token()
    rows = []
    for filename in ("examples.jsonl", ZIP_NAME):
        existing = WHATSUP / filename
        if existing.is_file() and existing.stat().st_size > 0:
            p = existing
        else:
            path = hf_hub_download(
                repo_id=REPO,
                repo_type="dataset",
                filename=filename,
                local_dir=WHATSUP,
                token=token,
            )
            p = Path(path)
        rows.append({"filename": filename, "path": str(p), "bytes": p.stat().st_size})
    IMAGES.mkdir(parents=True, exist_ok=True)
    extracted = 0
    with zipfile.ZipFile(WHATSUP / ZIP_NAME) as zf:
        for name in zf.namelist():
            base = name.split("/")[-1]
            if not base.startswith("controlled_"):
                continue
            dest = IMAGES / base
            if not dest.exists():
                dest.write_bytes(zf.read(name))
            extracted += 1
    return {
        "repo": REPO,
        "license": "MIT",
        "files": rows,
        "extracted_controlled_images": extracted,
        "images_dir": str(IMAGES),
        "note": "Only controlled_* photos were extracted. COCO/VG files stay in images.zip unused.",
    }


def load_controlled() -> list[dict]:
    items = []
    for line in EXAMPLES.read_text().splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        if row.get("original_file_name") not in CONTROLLED_SOURCES:
            continue
        image = IMAGES / row["image_file_name"]
        if not image.is_file():
            continue
        options = list(row["positive_caption"]) + list(row["negative_caption"])
        items.append(
            {
                "item_id": image.stem,
                "image": str(image),
                "source": row["original_file_name"],
                "cell": "SR",
                "spatial": True,
                "numeric": False,
                "options": options,
                "correct_index": 0,
                "correct_option": options[0],
            }
        )
    return items


def freeze_p1_items(pool: list[dict]) -> dict:
    by_src: dict[str, list[dict]] = {name: [] for name in CONTROLLED_SOURCES}
    for item in pool:
        by_src[item["source"]].append(item)
    rng = random.Random(SEED)
    chosen = []
    for name in CONTROLLED_SOURCES:
        rows = list(by_src[name])
        if len(rows) < N_PER_SUBSET:
            raise RuntimeError(f"{name} has {len(rows)} items, need {N_PER_SUBSET}")
        rng.shuffle(rows)
        chosen.extend(rows[:N_PER_SUBSET])
    chosen.sort(key=lambda row: row["item_id"])
    return {
        "recorded_at": now_iso(),
        "dataset": "What'sUp controlled photos (Kamath et al., EMNLP 2023)",
        "repo": REPO,
        "seed": SEED,
        "n_items": len(chosen),
        "n_per_subset": N_PER_SUBSET,
        "prompt": "Which caption matches the image?",
        "prompt_tuned": False,
        "scoring": "summed logprob of each caption as the assistant reply; no length norm",
        "cell": "SR",
        "note": "P1 item freeze only. Not a taxonomy. Not the full E1 pool.",
        "items": chosen,
    }


def main() -> None:
    dl = download()
    pool = load_controlled()
    items = freeze_p1_items(pool)
    write_json(RESULTS / "p1_items.json", items)
    write_json(
        RESULTS / "whatsup_download.json",
        {
            "recorded_at": now_iso(),
            "download": dl,
            "controlled_available": len(pool),
            "p1_items": items["n_items"],
            "p1_items_path": str(RESULTS / "p1_items.json"),
        },
    )
    write_inventory()
    print(f"What'sUp controlled available: {len(pool)}")
    print(f"P1 items: {items['n_items']} -> {RESULTS / 'p1_items.json'}")


if __name__ == "__main__":
    main()
