"""Score P1 items for one model and one quant level. Three passes. Isolated process."""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "e1"))

from common import (  # noqa: E402
    MODEL_SPECS,
    exception_record,
    gguf_path,
    now_iso,
    read_json,
    write_json,
)
from vision_score import N_CTX, PROMPT, make_handler, score_item  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=["C", "A"], required=True)
    parser.add_argument("--level", required=True)
    parser.add_argument("--items", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    spec = MODEL_SPECS[args.model]
    gguf = gguf_path(args.model, args.level)
    items = read_json(Path(args.items))["items"]
    record: dict = {
        "status": "FAIL",
        "model": args.model,
        "level": args.level,
        "gguf": str(gguf),
        "mmproj": str(spec["mmproj"]),
        "prompt": PROMPT,
        "prompt_tuned": False,
        "n_items": len(items),
        "repeats": args.repeats,
        "started_at": now_iso(),
        "passes": [],
    }
    llm = None
    handler = None
    try:
        from llama_cpp import Llama

        if not gguf.is_file():
            raise FileNotFoundError(f"missing {gguf}")
        if not spec["mmproj"].is_file():
            raise FileNotFoundError(f"missing {spec['mmproj']}")
        t0 = time.perf_counter()
        handler = make_handler(spec["mmproj"])
        llm = Llama(
            model_path=str(gguf),
            chat_handler=handler,
            n_ctx=N_CTX,
            n_gpu_layers=-1,
            logits_all=True,
            verbose=False,
        )
        record["load_s"] = round(time.perf_counter() - t0, 4)
        for run_i in range(args.repeats):
            run = {"run": run_i + 1, "started_at": now_iso(), "items": []}
            for item in items:
                t1 = time.perf_counter()
                scored = score_item(llm, handler, item, PROMPT)
                scored["score_s"] = round(time.perf_counter() - t1, 4)
                run["items"].append(scored)
            run["finished_at"] = now_iso()
            record["passes"].append(run)
        record["status"] = "PASS"
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        if llm is not None:
            del llm
        if handler is not None:
            del handler
        record["finished_at"] = now_iso()
        write_json(Path(args.out), record)
    return 0 if record["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
