"""P3: pin vision resolution and verify identical image token counts on 20 images."""

from __future__ import annotations

import random
import subprocess
import sys
from pathlib import Path

from common import DATA, E1, RESULTS, now_iso, read_json, write_json
from download_whatsup import load_controlled
from vision_score import PIN_IMAGE_TOKENS, resolution_pin

PYTHON = Path(sys.executable)
WORKER = E1 / "p3_measure_run.py"
SEED = 20260815
N_IMAGES = 20


def main() -> None:
    pool = load_controlled()
    rng = random.Random(SEED)
    chosen = list(pool)
    rng.shuffle(chosen)
    chosen = chosen[:N_IMAGES]
    chosen.sort(key=lambda row: row["item_id"])
    items_path = RESULTS / "p3_items.json"
    write_json(
        items_path,
        {
            "recorded_at": now_iso(),
            "seed": SEED,
            "n_items": len(chosen),
            "note": "P3 resolution check only. Not a scoring set.",
            "items": chosen,
        },
    )
    out = RESULTS / "p3" / "measure_C_Q4_K_M.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        [
            str(PYTHON),
            str(WORKER),
            "--model",
            "C",
            "--level",
            "Q4_K_M",
            "--items",
            str(items_path),
            "--out",
            str(out),
        ],
        capture_output=True,
        text=True,
    )
    payload = {
        "phase": "P3",
        "recorded_at": now_iso(),
        "status": "FAIL",
        "stop": True,
        "pin": resolution_pin(),
        "n_images": N_IMAGES,
        "worker_returncode": proc.returncode,
        "metal_atexit_abort": proc.returncode in {-6, 134},
        "images_dir": str(DATA / "whatsup" / "images"),
        "native_whatsup_size": [1280, 960],
        "note": "llama.cpp MTMD has no min_pixels/max_pixels. Pin is a 1280x960 resize plus image_min/max_tokens=1200.",
    }
    if not out.exists():
        payload["error"] = "worker wrote no JSON"
        payload["stderr_tail"] = (proc.stderr or "")[-2000:]
        write_json(RESULTS / "p3_resolution.json", payload)
        raise SystemExit(2)
    body = read_json(out)
    counts = [row["image_n_tokens"] for row in body.get("items") or []]
    unique = sorted(set(counts))
    identical = len(unique) == 1
    matches_pin = identical and unique[0] == PIN_IMAGE_TOKENS
    payload.update(
        {
            "status": "PASS" if matches_pin else "FAIL",
            "stop": not matches_pin,
            "stop_reason": None
            if matches_pin
            else f"image token counts were {unique}, expected {PIN_IMAGE_TOKENS}",
            "unique_image_token_counts": unique,
            "identical": identical,
            "items": body.get("items"),
            "worker_error": body.get("error"),
        }
    )
    write_json(RESULTS / "p3_resolution.json", payload)
    print(f"P3 {payload['status']} image_tokens={unique}")
    if payload["stop"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
