"""Count scoring-pool candidates already on disk under the locked cell rules."""

from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from pathlib import Path

from common import DATA, RESULTS, now_iso, write_json
from download_label_samples import load_parquet
from download_whatsup import load_controlled

LOC = re.compile(
    r"\b(left|right|behind|above|below|closer|closest|farthest|nearest|"
    r"in front|on top|to the left|to the right|next to|near the|"
    r"in the water|on the bench|on the counter|on the stove|"
    r"on the train|on the ground)\b",
    re.I,
)
CLOCK = re.compile(r"what time|clock show", re.I)
SIZE_CMP = re.compile(r"\b(larger|smaller|largest|smallest|which .+ larger|which .+ smaller)\b", re.I)
COUNT = re.compile(
    r"\b(how many|number of|fewer|more|greater than|less than|least|most|"
    r"same number|at least|enough to buy|surplus|shortage)\b",
    re.I,
)
SEM_STATE = re.compile(
    r"cut in half|split in half|half eaten|half full|headquartered|"
    r"^is there ",
    re.I,
)
CHARTISH = re.compile(r"\b(chart|plot|graph|table|bar chart|line plot)\b", re.I)
GEOMETRY = re.compile(r"\b(geometry|triangle|angle|hypotenuse|parallelogram)\b", re.I)


def cell_of(spatial: bool, numeric: bool) -> str:
    if spatial and not numeric:
        return "SR"
    if spatial and numeric:
        return "SN"
    if (not spatial) and numeric:
        return "NN"
    return "SEM"


def classify_question(question: str) -> tuple[str, str]:
    q = question or ""
    if SEM_STATE.search(q) and not COUNT.search(q) and not LOC.search(q) and not CLOCK.search(q):
        return "SEM", "presence_or_state"
    if CLOCK.search(q):
        return "SN", "analog_clock"
    spatial = bool(LOC.search(q))
    numeric = bool(COUNT.search(q) or SIZE_CMP.search(q))
    if GEOMETRY.search(q) and spatial:
        return "SR", "geometry_spatial"
    if CHARTISH.search(q) and numeric:
        return "SN", "chart_numeric"
    return cell_of(spatial, numeric), "words"


def first(path: Path, pattern: str) -> Path | None:
    hits = list(path.rglob(pattern))
    return hits[0] if hits else None


def main() -> None:
    by_cell: Counter[str] = Counter()
    by_source: dict[str, Counter] = defaultdict(Counter)
    notes = []

    whatsup = load_controlled()
    by_cell["SR"] += len(whatsup)
    by_source["whatsup_controlled"]["SR"] += len(whatsup)
    notes.append(f"What'sUp controlled on disk: {len(whatsup)} SR (all relation captions).")

    depth = first(DATA / "blink", "val-*.parquet")
    # Relative_Depth vs Counting: pick by parent name
    for parquet in (DATA / "blink").rglob("val-*.parquet"):
        task = "Relative_Depth" if "Relative_Depth" in str(parquet) else "Counting"
        ds = load_parquet(parquet)
        n = 0
        for i in range(len(ds)):
            row = ds[i]
            q = str(row.get("question") or row.get("prompt") or "")
            if task == "Relative_Depth":
                cell, why = "SR", "closer_is_sr"
            else:
                cell, why = classify_question(q)
                if cell == "SEM":
                    cell, why = "NN", "count_default"
            by_cell[cell] += 1
            by_source[f"blink_{task}_val"][cell] += 1
            n += 1
        notes.append(f"BLINK {task} val on disk: {n} items.")

    cv_dir = DATA / "cvbench"
    for parquet in sorted(cv_dir.glob("test_*.parquet")):
        ds = load_parquet(parquet)
        skipped = Counter()
        for i in range(len(ds)):
            row = ds[i]
            choices = row.get("choices")
            if not choices or len(list(choices)) < 2:
                skipped["no_choices"] += 1
                continue
            answer = str(row.get("answer") or "").strip()
            if not answer:
                skipped["no_answer"] += 1
                continue
            q = str(row.get("question") or row.get("prompt") or "")
            task = str(row.get("task") or "").lower()
            if "count" in task:
                cell, why = classify_question(q)
                if cell == "SEM":
                    cell, why = "NN", "count_default"
            elif "depth" in task or "distance" in task:
                cell, why = classify_question(q)
                if cell == "SEM":
                    cell, why = "SR", "depth_or_distance_default"
            elif "spatial" in task or "relation" in task:
                cell, why = "SR", "cvbench_spatial"
            else:
                cell, why = classify_question(q)
            by_cell[cell] += 1
            by_source[f"cvbench_{parquet.stem}"][cell] += 1
        notes.append(f"CV-Bench {parquet.name}: {len(ds)} rows, skipped {dict(skipped)}.")

    seen_pids: set[str] = set()
    math_files = sorted((DATA / "mathvista").rglob("*.parquet"))
    for math_pq in math_files:
        name = math_pq.name
        if name.startswith("testmini"):
            src_key = "mathvista_testmini_mc"
        elif name.startswith("test-"):
            src_key = "mathvista_test_mc"
        else:
            continue
        ds = load_parquet(math_pq)
        skipped = Counter()
        kept = 0
        for i in range(len(ds)):
            row = ds[i]
            pid = str(row.get("pid") or f"{name}:{i}")
            if pid in seen_pids:
                skipped["duplicate_pid"] += 1
                continue
            if str(row.get("question_type") or "").lower() != "multi_choice":
                skipped["not_mc"] += 1
                continue
            choices = row.get("choices")
            if not choices or len(list(choices)) < 2:
                skipped["no_choices"] += 1
                continue
            answer = str(row.get("answer") or "").strip()
            if answer not in [str(c) for c in list(choices)]:
                skipped["answer_mismatch"] += 1
                continue
            q = str(row.get("question") or row.get("query") or "")
            meta = row.get("metadata") or {}
            context = str(meta.get("context") or "").lower()
            task = str(meta.get("task") or "").lower()
            if "geometry" in task or "geometry" in context:
                skipped["geometry"] += 1
                continue
            seen_pids.add(pid)
            cell, why = classify_question(q)
            if any(part in context for part in ("chart", "plot")) and cell == "NN":
                cell, why = "SN", "chart_forced_sn"
            by_cell[cell] += 1
            by_source[src_key][cell] += 1
            kept += 1
        notes.append(f"MathVista {name}: {len(ds)} rows, kept {kept}, skipped {dict(skipped)}.")

    pope_pq = first(DATA / "pope", "random-*.parquet")
    if pope_pq:
        ds = load_parquet(pope_pq)
        by_cell["SEM"] += len(ds)
        by_source["pope_random"]["SEM"] += len(ds)
        notes.append(f"POPE Full/random on disk: {len(ds)} SEM presence items.")

    target = 500
    minimum = 300
    outlook = {}
    for cell in ("SR", "SN", "NN", "SEM"):
        n = by_cell[cell]
        outlook[cell] = {
            "on_disk": n,
            "reaches_300": n >= minimum,
            "reaches_500": n >= target,
            "short_of_300": max(0, minimum - n),
            "short_of_500": max(0, target - n),
        }

    downloads = [
        {
            "what": "MathVista images.zip",
            "why": "Not needed. Images are already inside the parquets.",
            "ask": True,
            "avoid": "About 27 GB. Do not download.",
        },
        {
            "what": "POPE Full/popular and Full/adversarial",
            "why": "SEM already has 3000. Not needed unless we want more diversity.",
            "ask": False,
        },
        {
            "what": "BLINK Spatial_Relation val",
            "why": "More SR. SR already has What'sUp 820 so this is optional.",
            "ask": False,
        },
        {
            "what": "CV-Bench extra img/ tree",
            "why": "Not needed. Images are inside test_2d/test_3d parquets.",
            "ask": True,
        },
        {
            "what": "EmbSpatial-Bench close/far and left/right",
            "why": "Possible SN/SR, but images are not in the Hub JSON and scene licenses need a check.",
            "ask": True,
        },
        {
            "what": "VSR + COCO images",
            "why": "More SR. Not needed if What'sUp 820 is enough. COCO license check required.",
            "ask": True,
        },
    ]

    payload = {
        "recorded_at": now_iso(),
        "status": "disk_count_only",
        "rules": "Locked hand-label rules from results/e1/benchmark_taxonomy.json. Automatic word tags, not a second hand-label pass.",
        "minimum_per_cell": minimum,
        "target_per_cell": target,
        "on_disk_by_cell": dict(by_cell),
        "on_disk_by_source": {k: dict(v) for k, v in by_source.items()},
        "outlook": outlook,
        "notes": notes,
        "possible_downloads": downloads,
        "stop_risk": [cell for cell, row in outlook.items() if not row["reaches_300"]],
    }
    path = RESULTS / "disk_pool_count.json"
    write_json(path, payload)
    print(json.dumps(payload["on_disk_by_cell"], indent=2))
    print("short of 300:", payload["stop_risk"])
    print(path)


if __name__ == "__main__":
    main()
