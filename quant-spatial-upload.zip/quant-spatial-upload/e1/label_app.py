"""Local hand-labeler for the E1 2x2 cells. Serves http://127.0.0.1:8765"""

from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from common import DATA, RESULTS, ROOT, now_iso, read_json, write_json

HOST = "127.0.0.1"
PORT = 8765
QUEUE = RESULTS / "label_queue.json"
LABELS = RESULTS / "hand_labels.json"
TARGET = 50


def cell_of(spatial: bool, numeric: bool) -> str:
    if spatial and not numeric:
        return "SR"
    if spatial and numeric:
        return "SN"
    if (not spatial) and numeric:
        return "NN"
    return "SEM"


def load_queue() -> dict:
    if not QUEUE.is_file():
        raise FileNotFoundError("missing results/e1/label_queue.json; run python e1/build_label_queue.py")
    return read_json(QUEUE)


def load_labels() -> dict:
    if LABELS.is_file():
        return read_json(LABELS)
    return {
        "recorded_at": now_iso(),
        "target_per_cell": TARGET,
        "labels": {},
    }


def save_labels(payload: dict) -> None:
    payload["updated_at"] = now_iso()
    write_json(LABELS, payload)


def status_payload() -> dict:
    queue = load_queue()
    labels = load_labels()["labels"]
    counts = {"SR": 0, "SN": 0, "NN": 0, "SEM": 0, "excluded": 0}
    agree = 0
    compared = 0
    for item in queue["items"]:
        row = labels.get(item["item_id"])
        if not row:
            continue
        if row.get("exclude"):
            counts["excluded"] += 1
            continue
        counts[row["cell"]] = counts.get(row["cell"], 0) + 1
        compared += 1
        if row["cell"] == item.get("proposed_cell"):
            agree += 1
    unlabeled = [
        item["item_id"]
        for item in queue["items"]
        if item["item_id"] not in labels
    ]
    return {
        "n_queue": len(queue["items"]),
        "n_labeled": len(labels),
        "n_unlabeled": len(unlabeled),
        "counts": counts,
        "target": TARGET,
        "agreement": None if compared == 0 else round(agree / compared, 4),
        "n_compared": compared,
        "next_id": unlabeled[0] if unlabeled else None,
    }


def item_view(item_id: str | None) -> dict | None:
    queue = load_queue()
    labels = load_labels()["labels"]
    items = queue["items"]
    if not items:
        return None
    if item_id is None:
        item_id = status_payload()["next_id"] or items[0]["item_id"]
    index = next((i for i, row in enumerate(items) if row["item_id"] == item_id), 0)
    item = items[index]
    return {
        "index": index,
        "n": len(items),
        "item": item,
        "label": labels.get(item["item_id"]),
        "prev_id": items[index - 1]["item_id"] if index > 0 else None,
        "next_id": items[index + 1]["item_id"] if index + 1 < len(items) else None,
        "status": status_payload(),
    }


def queue_index() -> dict:
    queue = load_queue()
    labels = load_labels()["labels"]
    rows = []
    for i, item in enumerate(queue["items"]):
        lab = labels.get(item["item_id"])
        rows.append(
            {
                "index": i,
                "item_id": item["item_id"],
                "image": item["image"],
                "question": item.get("question") or "",
                "proposed_cell": item.get("proposed_cell"),
                "labeled": lab is not None,
                "exclude": bool(lab.get("exclude")) if lab else False,
                "cell": None if not lab else lab.get("cell"),
            }
        )
    return {"n": len(rows), "items": rows, "status": status_payload()}


def safe_image(path_str: str) -> Path:
    path = Path(path_str).resolve()
    allowed = (DATA.resolve(), (ROOT / "data").resolve())
    if not any(path == root or root in path.parents for root in allowed):
        raise PermissionError("image is outside data/")
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>E1 hand labels</title>
<style>
  :root { --bg:#141414; --card:#1e1e1e; --ink:#f2f2f2; --muted:#a3a3a3; --line:#333; --yes:#3d8b5c; --no:#a35b5b; --accent:#c4a35a; }
  * { box-sizing: border-box; }
  body { margin:0; font: 16px/1.4 -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif; background:var(--bg); color:var(--ink); }
  header { padding:16px 24px; border-bottom:1px solid var(--line); display:flex; justify-content:space-between; gap:24px; align-items:baseline; }
  h1 { margin:0; font-size:18px; font-weight:600; }
  .muted { color:var(--muted); font-size:13px; }
  main { display:grid; grid-template-columns: 168px 1.2fr 0.8fr; min-height: calc(100vh - 58px); }
  .strip { border-right:1px solid var(--line); display:flex; flex-direction:column; height: calc(100vh - 58px); min-height:0; }
  .strip-head { padding:10px 10px 8px; border-bottom:1px solid var(--line); }
  .strip-head .row { margin:8px 0 0; }
  .strip-list { overflow:auto; flex:1; padding:8px; }
  .thumb { display:block; width:100%; margin:0 0 8px; padding:0; border:2px solid var(--line); background:#000; cursor:pointer; text-align:left; position:relative; }
  .thumb img { display:block; width:100%; height:88px; object-fit:cover; }
  .thumb .tag { position:absolute; left:4px; bottom:4px; font-size:10px; padding:1px 4px; background:#000c; color:var(--ink); }
  .thumb.done { border-color:var(--yes); }
  .thumb.excluded { border-color:var(--no); }
  .thumb.current { border-color:var(--accent); }
  .pic { padding:20px; border-right:1px solid var(--line); }
  .pic img { width:100%; max-height:78vh; object-fit:contain; background:#000; }
  .side { padding:20px 24px 40px; }
  .opts { margin:12px 0 20px; padding:0; list-style:none; }
  .opts li { padding:8px 10px; border:1px solid var(--line); margin-bottom:6px; }
  .opts li.correct { border-color:var(--accent); }
  .row { display:flex; gap:8px; flex-wrap:wrap; margin:10px 0 16px; }
  button { font: inherit; padding:8px 12px; border:1px solid var(--line); background:var(--card); color:var(--ink); cursor:pointer; }
  button.on-yes { background:var(--yes); border-color:var(--yes); color:#fff; }
  button.on-no { background:var(--no); border-color:var(--no); color:#fff; }
  button.primary { background:var(--accent); border-color:var(--accent); color:#111; font-weight:600; }
  .cell { display:inline-block; padding:4px 8px; border:1px solid var(--accent); color:var(--accent); font-weight:600; }
  .bar { display:grid; grid-template-columns:repeat(4,1fr); gap:8px; margin:16px 0; }
  .bar div { background:var(--card); border:1px solid var(--line); padding:8px; }
  .bar b { display:block; font-size:20px; }
  kbd { border:1px solid var(--line); padding:0 5px; font-size:12px; color:var(--muted); }
</style>
</head>
<body>
<header>
  <div>
    <h1>E1 hand labels</h1>
    <div class="muted">Mark whether the item is spatial and whether it is numeric. The cell follows from that. Do not score accuracy here.</div>
  </div>
  <div class="muted" id="meta"></div>
</header>
<main>
  <aside class="strip">
    <div class="strip-head">
      <div class="muted" id="strip-count"></div>
      <div class="row">
        <button id="filter-all" type="button">All</button>
        <button id="filter-todo" type="button">To label</button>
        <button id="filter-done" type="button">Done</button>
      </div>
    </div>
    <div class="strip-list" id="strip"></div>
  </aside>
  <section class="pic"><img id="img" alt="item image"></section>
  <section class="side">
    <div class="bar" id="bars"></div>
    <p class="muted" id="source"></p>
    <p id="question"></p>
    <ul class="opts" id="opts"></ul>
    <p>Proposed cell: <span id="proposed"></span></p>
    <p>Your cell: <span class="cell" id="cell">—</span></p>
    <div>Spatial</div>
    <div class="row">
      <button id="s-yes" type="button">Yes <kbd>1</kbd></button>
      <button id="s-no" type="button">No <kbd>2</kbd></button>
    </div>
    <div>Numeric</div>
    <div class="row">
      <button id="n-yes" type="button">Yes <kbd>3</kbd></button>
      <button id="n-no" type="button">No <kbd>4</kbd></button>
    </div>
    <div class="row">
      <button class="primary" id="save" type="button">Save and next <kbd>Enter</kbd></button>
      <button id="exclude" type="button">Exclude <kbd>X</kbd></button>
      <button id="prev" type="button">Back <kbd>[</kbd></button>
      <button id="next" type="button">Next <kbd>]</kbd></button>
    </div>
    <p class="muted">Spatial = the answer depends on where things are, not just what they are. Numeric = the answer depends on a number, count, distance, size, or comparison of amounts. Exclude only if the item is unusable (no image, not closed-set, or you cannot tell).</p>
    <p class="muted" id="agree"></p>
  </section>
</main>
<script>
let state = { spatial: null, numeric: null, item: null, view: null, queue: [], filter: "todo" };

function cellOf(s, n) {
  if (s === true && n === false) return "SR";
  if (s === true && n === true) return "SN";
  if (s === false && n === true) return "NN";
  if (s === false && n === false) return "SEM";
  return "—";
}

function paintButtons() {
  sYes.classList.toggle("on-yes", state.spatial === true);
  sNo.classList.toggle("on-no", state.spatial === false);
  nYes.classList.toggle("on-yes", state.numeric === true);
  nNo.classList.toggle("on-no", state.numeric === false);
  cellEl.textContent = cellOf(state.spatial, state.numeric);
}

function paintFilter() {
  filterAll.classList.toggle("primary", state.filter === "all");
  filterTodo.classList.toggle("primary", state.filter === "todo");
  filterDone.classList.toggle("primary", state.filter === "done");
}

function visibleQueue() {
  return state.queue.filter((row) => {
    if (state.filter === "todo") return !row.labeled;
    if (state.filter === "done") return row.labeled;
    return true;
  });
}

function renderStrip() {
  const rows = visibleQueue();
  const current = state.item ? state.item.item_id : null;
  stripCount.textContent = rows.length + " shown · " + state.queue.length + " in queue";
  strip.innerHTML = "";
  rows.forEach((row) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "thumb";
    if (row.item_id === current) btn.classList.add("current");
    if (row.exclude) btn.classList.add("excluded");
    else if (row.labeled) btn.classList.add("done");
    const im = document.createElement("img");
    im.loading = "lazy";
    im.alt = row.item_id;
    im.src = "/image?path=" + encodeURIComponent(row.image);
    const tag = document.createElement("span");
    tag.className = "tag";
    tag.textContent = (row.index + 1) + " " + (row.cell || row.proposed_cell || "");
    btn.appendChild(im);
    btn.appendChild(tag);
    btn.onclick = () => load(row.item_id);
    strip.appendChild(btn);
  });
  const active = strip.querySelector(".thumb.current");
  if (active) active.scrollIntoView({ block: "nearest" });
  paintFilter();
}

async function refreshQueue() {
  const payload = await (await fetch("/api/queue")).json();
  state.queue = payload.items || [];
  renderStrip();
}

async function load(id) {
  const url = id ? "/api/item?id=" + encodeURIComponent(id) : "/api/item";
  const view = await (await fetch(url)).json();
  state.view = view;
  state.item = view.item;
  const lab = view.label;
  state.spatial = lab ? lab.spatial : view.item.proposed_spatial;
  state.numeric = lab ? lab.numeric : view.item.proposed_numeric;
  img.src = "/image?path=" + encodeURIComponent(view.item.image);
  meta.textContent = (view.index + 1) + " / " + view.n + "   " + view.item.item_id;
  source.textContent = view.item.source + " · " + (view.item.label_note || "");
  question.textContent = view.item.question || "";
  proposed.textContent = view.item.proposed_cell;
  opts.innerHTML = "";
  (view.item.options || []).forEach((opt, i) => {
    const li = document.createElement("li");
    li.textContent = (i === view.item.correct_index ? "Correct: " : "") + opt;
    if (i === view.item.correct_index) li.className = "correct";
    opts.appendChild(li);
  });
  const st = view.status;
  bars.innerHTML = ["SR","SN","NN","SEM"].map(c => {
    return "<div><b>" + st.counts[c] + "/" + st.target + "</b>" + c + "</div>";
  }).join("");
  agree.textContent = st.agreement == null ? "No agreement yet." :
    "Agreement with auto cell: " + Math.round(st.agreement * 100) + "% on " + st.n_compared + " items (need 90%). Excluded: " + st.counts.excluded;
  paintButtons();
  renderStrip();
}

async function save(exclude) {
  if (!state.item) return;
  if (!exclude && (state.spatial === null || state.numeric === null)) return;
  await fetch("/api/label", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      item_id: state.item.item_id,
      spatial: state.spatial,
      numeric: state.numeric,
      cell: cellOf(state.spatial, state.numeric),
      exclude: !!exclude,
      proposed_cell: state.item.proposed_cell
    })
  });
  await refreshQueue();
  if (state.view.next_id) load(state.view.next_id);
  else load(state.item.item_id);
}

const img = document.getElementById("img");
const meta = document.getElementById("meta");
const source = document.getElementById("source");
const question = document.getElementById("question");
const opts = document.getElementById("opts");
const proposed = document.getElementById("proposed");
const cellEl = document.getElementById("cell");
const bars = document.getElementById("bars");
const agree = document.getElementById("agree");
const strip = document.getElementById("strip");
const stripCount = document.getElementById("strip-count");
const filterAll = document.getElementById("filter-all");
const filterTodo = document.getElementById("filter-todo");
const filterDone = document.getElementById("filter-done");
const sYes = document.getElementById("s-yes");
const sNo = document.getElementById("s-no");
const nYes = document.getElementById("n-yes");
const nNo = document.getElementById("n-no");
sYes.onclick = () => { state.spatial = true; paintButtons(); };
sNo.onclick = () => { state.spatial = false; paintButtons(); };
nYes.onclick = () => { state.numeric = true; paintButtons(); };
nNo.onclick = () => { state.numeric = false; paintButtons(); };
document.getElementById("save").onclick = () => save(false);
document.getElementById("exclude").onclick = () => save(true);
document.getElementById("prev").onclick = () => { if (state.view.prev_id) load(state.view.prev_id); };
document.getElementById("next").onclick = () => { if (state.view.next_id) load(state.view.next_id); };
filterAll.onclick = () => { state.filter = "all"; renderStrip(); };
filterTodo.onclick = () => { state.filter = "todo"; renderStrip(); };
filterDone.onclick = () => { state.filter = "done"; renderStrip(); };
document.addEventListener("keydown", (ev) => {
  if (ev.key === "1") { state.spatial = true; paintButtons(); };
  if (ev.key === "2") { state.spatial = false; paintButtons(); };
  if (ev.key === "3") { state.numeric = true; paintButtons(); };
  if (ev.key === "4") { state.numeric = false; paintButtons(); };
  if (ev.key === "Enter") { ev.preventDefault(); save(false); }
  if (ev.key === "x" || ev.key === "X") save(true);
  if (ev.key === "[") { if (state.view.prev_id) load(state.view.prev_id); }
  if (ev.key === "]") { if (state.view.next_id) load(state.view.next_id); }
});
refreshQueue().then(() => load());
</script>
</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args) -> None:
        print(f"{self.address_string()} {fmt % args}")

    def _json(self, payload: dict, code: int = 200) -> None:
        raw = json.dumps(payload, default=str).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _html(self, text: str) -> None:
        raw = text.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self._html(PAGE)
            return
        if parsed.path == "/api/status":
            self._json(status_payload())
            return
        if parsed.path == "/api/queue":
            self._json(queue_index())
            return
        if parsed.path == "/api/item":
            item_id = parse_qs(parsed.query).get("id", [None])[0]
            view = item_view(item_id)
            if view is None:
                self._json({"error": "empty queue"}, 404)
                return
            self._json(view)
            return
        if parsed.path == "/image":
            path_str = parse_qs(parsed.query).get("path", [""])[0]
            try:
                path = safe_image(path_str)
            except Exception as exc:
                self._json({"error": str(exc)}, 400)
                return
            data = path.read_bytes()
            mime = "image/jpeg" if path.suffix.lower() in {".jpg", ".jpeg"} else "image/png"
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        self._json({"error": "not found"}, 404)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/api/label":
            self._json({"error": "not found"}, 404)
            return
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length) or b"{}")
        item_id = body.get("item_id")
        if not item_id:
            self._json({"error": "missing item_id"}, 400)
            return
        labels = load_labels()
        exclude = bool(body.get("exclude"))
        spatial = bool(body.get("spatial")) if body.get("spatial") is not None else None
        numeric = bool(body.get("numeric")) if body.get("numeric") is not None else None
        labels["labels"][item_id] = {
            "spatial": spatial,
            "numeric": numeric,
            "cell": None if exclude else cell_of(bool(spatial), bool(numeric)),
            "exclude": exclude,
            "proposed_cell": body.get("proposed_cell"),
            "labeled_at": now_iso(),
        }
        save_labels(labels)
        self._json({"ok": True, "status": status_payload()})


def main() -> None:
    load_queue()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"Hand labeler: http://{HOST}:{PORT}")
    print(f"Queue: {QUEUE}")
    print(f"Labels: {LABELS}")
    print("Leave this running. Open the URL in your browser.")
    server.serve_forever()


if __name__ == "__main__":
    main()
