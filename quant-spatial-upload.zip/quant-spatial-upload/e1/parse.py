"""Extract a caption JSON object. No guessing fallback."""

from __future__ import annotations

import json
import re

JSON_RE = re.compile(r"\{.*?\}", re.DOTALL)


def classify_caption_json(text: str) -> dict:
    matches = list(JSON_RE.finditer(text or ""))
    if not matches:
        return {"class": "malformed", "reason": "no_json_object", "extracted": None}
    parsed = []
    decode_failures = 0
    for match in matches:
        try:
            value = json.loads(match.group(0))
        except json.JSONDecodeError:
            decode_failures += 1
            continue
        if isinstance(value, dict):
            parsed.append(value)
    if not parsed:
        return {"class": "malformed", "reason": "json_decode_failed", "extracted": None}
    captions = []
    for value in parsed:
        caption = value.get("caption")
        if isinstance(caption, str) and caption.strip():
            captions.append(caption.strip())
    if len(captions) == 1:
        return {"class": "extracted", "reason": None, "extracted": captions[0]}
    if len(captions) > 1:
        unique = set(captions)
        if len(unique) == 1:
            return {
                "class": "extracted",
                "reason": "duplicate_same_caption",
                "extracted": captions[0],
            }
        return {"class": "ambiguous", "reason": "multiple_captions", "extracted": None}
    return {"class": "ambiguous", "reason": "json_without_caption", "extracted": None}
