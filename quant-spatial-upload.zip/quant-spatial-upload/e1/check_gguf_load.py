"""Load one GGUF and generate 20 tokens. Run in a subprocess (Metal atexit abort)."""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "e1"))

from common import exception_record, now_iso, write_json  # noqa: E402

PROMPT = "Reply with the word ready and nothing else."
MAX_NEW_TOKENS = 20


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gguf", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    path = Path(args.gguf)
    record: dict = {
        "status": "FAIL",
        "gguf": str(path),
        "started_at": now_iso(),
        "n_gpu_layers": -1,
        "requested_tokens": MAX_NEW_TOKENS,
        "prompt": PROMPT,
    }
    llm = None
    try:
        from llama_cpp import Llama

        if not path.is_file():
            raise FileNotFoundError(f"missing {path}")
        t0 = time.perf_counter()
        llm = Llama(
            model_path=str(path),
            n_ctx=2048,
            n_gpu_layers=-1,
            verbose=False,
        )
        record["load_s"] = round(time.perf_counter() - t0, 4)
        t1 = time.perf_counter()
        out = llm.create_chat_completion(
            messages=[{"role": "user", "content": PROMPT}],
            max_tokens=MAX_NEW_TOKENS,
            temperature=0,
        )
        choice = out["choices"][0]
        text = choice["message"]["content"]
        usage = out.get("usage", {})
        record["output"] = text
        record["completion_tokens"] = usage.get("completion_tokens")
        record["generate_s"] = round(time.perf_counter() - t1, 4)
        n_tokens = usage.get("completion_tokens") or (1 if text else 0)
        if n_tokens > 0:
            record["status"] = "PASS"
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        if llm is not None:
            del llm
        record["finished_at"] = now_iso()
        write_json(Path(args.out), record)
    return 0 if record["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
