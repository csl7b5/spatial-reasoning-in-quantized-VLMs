"""Download MathVista test parquets only. Never download images.zip."""

from __future__ import annotations

from huggingface_hub import list_repo_files

from common import RESULTS, now_iso, write_json
from download_label_samples import MATH_DIR, MATHVISTA_REPO, fetch_file
from inventory import main as write_inventory

FORBIDDEN = ("images.zip", "images/")


def main() -> None:
    names = list_repo_files(MATHVISTA_REPO, repo_type="dataset")
    wanted = sorted(
        n for n in names if n.startswith("data/test-") and n.endswith(".parquet")
    )
    if not wanted:
        raise SystemExit("no data/test-*.parquet files on AI4Math/MathVista")
    rows = []
    for name in wanted:
        if any(bad in name for bad in FORBIDDEN):
            raise SystemExit(f"refusing {name}")
        path = fetch_file(MATHVISTA_REPO, name, MATH_DIR)
        rows.append({"filename": name, "path": str(path), "bytes": path.stat().st_size})
        print(f"{name} -> {path} ({path.stat().st_size} bytes)")
    write_json(
        RESULTS / "mathvista_test_download.json",
        {
            "recorded_at": now_iso(),
            "repo": MATHVISTA_REPO,
            "license": "cc-by-sa-4.0",
            "files": rows,
            "total_bytes": sum(r["bytes"] for r in rows),
            "note": "Test parquets only. images.zip was not downloaded.",
        },
    )
    write_inventory()
    print("did not download images.zip")


if __name__ == "__main__":
    main()
