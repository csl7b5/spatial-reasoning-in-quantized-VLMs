"""Generate A-F16 answers for P4. Isolated process."""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "e1"))

from common import MODEL_SPECS, exception_record, gguf_path, now_iso, read_json, write_json  # noqa: E402
from parse import classify_caption_json  # noqa: E402
from vision_score import (  # noqa: E402
    GENERATE_PROMPT,
    N_CTX,
    eval_vision_prompt,
    greedy_continue,
    make_handler,
    resolution_pin,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="A")
    parser.add_argument("--level", default="F16")
    parser.add_argument("--items", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    spec = MODEL_SPECS[args.model]
    gguf = gguf_path(args.model, args.level)
    items = read_json(Path(args.items))["items"]
    record: dict = {
        "status": "FAIL",
        "model": args.model,
        "level": args.level,
        "gguf": str(gguf),
        "prompt": GENERATE_PROMPT,
        "prompt_tuned": False,
        "pin": resolution_pin(),
        "started_at": now_iso(),
        "items": [],
    }
    llm = None
    handler = None
    try:
        from llama_cpp import Llama

        handler = make_handler(spec["mmproj"])
        llm = Llama(
            model_path=str(gguf),
            chat_handler=handler,
            n_ctx=N_CTX,
            n_gpu_layers=-1,
            logits_all=True,
            verbose=False,
        )
        for item in items:
            t0 = time.perf_counter()
            eval_vision_prompt(llm, handler, Path(item["image"]), GENERATE_PROMPT)
            gen = greedy_continue(llm, max_tokens=64)
            parsed = classify_caption_json(gen["text"])
            record["items"].append(
                {
                    "item_id": item["item_id"],
                    "image": item["image"],
                    "output": gen["text"],
                    "n_new_tokens": gen["n_tokens"],
                    "parse": parsed,
                    "elapsed_s": round(time.perf_counter() - t0, 4),
                }
            )
        record["status"] = "PASS"
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        if llm is not None:
            del llm
        if handler is not None:
            del handler
        record["finished_at"] = now_iso()
        write_json(Path(args.out), record)
    return 0 if record["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
