"""P4: parser failure rate on 100 real Model A F16 outputs. Stop if > 2%."""

from __future__ import annotations

import random
import subprocess
import sys
from pathlib import Path

from common import E1, RESULTS, now_iso, read_json, write_json
from download_whatsup import load_controlled
from vision_score import GENERATE_PROMPT

PYTHON = Path(sys.executable)
WORKER = E1 / "p4_generate_run.py"
SEED = 20260815
N_ITEMS = 100
FAIL_RATE_MAX = 0.02


def main() -> None:
    pool = load_controlled()
    rng = random.Random(SEED)
    chosen = list(pool)
    rng.shuffle(chosen)
    chosen = chosen[:N_ITEMS]
    chosen.sort(key=lambda row: row["item_id"])
    items_path = RESULTS / "p4_items.json"
    write_json(
        items_path,
        {
            "recorded_at": now_iso(),
            "seed": SEED,
            "n_items": len(chosen),
            "prompt": GENERATE_PROMPT,
            "prompt_tuned": False,
            "items": chosen,
        },
    )
    out = RESULTS / "p4" / "A_F16.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    print(f"P4 generating {len(chosen)} A-F16 outputs...")
    proc = subprocess.run(
        [
            str(PYTHON),
            str(WORKER),
            "--model",
            "A",
            "--level",
            "F16",
            "--items",
            str(items_path),
            "--out",
            str(out),
        ],
        capture_output=True,
        text=True,
    )
    payload = {
        "phase": "P4",
        "recorded_at": now_iso(),
        "status": "FAIL",
        "stop": True,
        "n_items": N_ITEMS,
        "fail_rate_max": FAIL_RATE_MAX,
        "prompt": GENERATE_PROMPT,
        "prompt_tuned": False,
        "guessing_fallback": False,
        "worker_returncode": proc.returncode,
        "metal_atexit_abort": proc.returncode in {-6, 134},
    }
    if not out.exists():
        payload["error"] = "worker wrote no JSON"
        payload["stderr_tail"] = (proc.stderr or "")[-2000:]
        write_json(RESULTS / "p4_parser.json", payload)
        raise SystemExit(2)
    body = read_json(out)
    if body.get("status") != "PASS":
        payload["error"] = body.get("error")
        write_json(RESULTS / "p4_parser.json", payload)
        print("P4 FAIL worker")
        raise SystemExit(2)
    counts = {"extracted": 0, "ambiguous": 0, "malformed": 0}
    failures = []
    for row in body["items"]:
        klass = row["parse"]["class"]
        counts[klass] = counts.get(klass, 0) + 1
        if klass != "extracted":
            failures.append(
                {
                    "item_id": row["item_id"],
                    "class": klass,
                    "reason": row["parse"]["reason"],
                    "output": row["output"],
                }
            )
    n = len(body["items"])
    n_fail = len(failures)
    fail_rate = n_fail / n if n else 1.0
    stop = fail_rate > FAIL_RATE_MAX
    payload.update(
        {
            "status": "FAIL" if stop else "PASS",
            "stop": stop,
            "stop_reason": (
                f"parser failure rate {fail_rate:.4f} > {FAIL_RATE_MAX}" if stop else None
            ),
            "n_scored": n,
            "counts": counts,
            "n_fail": n_fail,
            "fail_rate": round(fail_rate, 4),
            "failures": failures,
            "note": "Failures listed in full for hand review. No guessing fallback.",
        }
    )
    write_json(RESULTS / "p4_parser.json", payload)
    print(f"P4 {payload['status']} fail_rate={fail_rate:.4f} n_fail={n_fail}/{n}")
    if stop:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
