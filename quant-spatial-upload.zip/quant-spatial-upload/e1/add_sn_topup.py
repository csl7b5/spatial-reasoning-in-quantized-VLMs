"""Add ~20 SN labeling candidates from files already on disk. Does not wipe labels."""

from __future__ import annotations

import random
import re
from pathlib import Path

from common import DATA, RESULTS, now_iso, read_json, write_json
from download_label_samples import (
    BLINK_DIR,
    MATH_DIR,
    as_pil,
    item_base,
    load_parquet,
    save_pil,
)

SEED = 20260816
N_WANT = 20

LOC = re.compile(
    r"\b(left|right|behind|above|below|closer|closest|in front|on top|"
    r"to the left|to the right|next to|near the|in the water|on the bench|"
    r"on the counter|on the stove|on the train|on the ground)\b",
    re.I,
)
CLOCK = re.compile(r"what time|clock show", re.I)
SIZE_AND_LOC = re.compile(r"\b(smaller|larger|smallest|largest)\b", re.I)
COUNT = re.compile(
    r"\b(how many|number of|fewer|more|greater than|less than|at least)\b",
    re.I,
)


def used_ids() -> set[str]:
    ids = set()
    queue = RESULTS / "label_queue.json"
    if queue.is_file():
        ids.update(row["item_id"] for row in read_json(queue)["items"])
    labels = RESULTS / "hand_labels.json"
    if labels.is_file():
        ids.update(read_json(labels)["labels"].keys())
    return ids


def looks_sn(question: str) -> str | None:
    q = question or ""
    if CLOCK.search(q):
        return "analog_clock"
    if SIZE_AND_LOC.search(q) and LOC.search(q):
        return "size_plus_location"
    if COUNT.search(q) and LOC.search(q):
        return "count_plus_location"
    return None


def mathvista_parquet() -> Path:
    matches = list((MATH_DIR / "data").glob("testmini-*.parquet"))
    if not matches:
        matches = list(MATH_DIR.rglob("testmini-*.parquet"))
    if not matches:
        raise FileNotFoundError("MathVista testmini parquet is not on disk")
    return matches[0]


def blink_counting_parquet() -> Path | None:
    matches = list((BLINK_DIR / "Counting").rglob("val-*.parquet"))
    return matches[0] if matches else None


def collect_mathvista(used: set[str], rng: random.Random) -> list[dict]:
    ds = load_parquet(mathvista_parquet())
    pool = []
    for i in range(len(ds)):
        row = ds[i]
        pid = str(row.get("pid") or i)
        item_id = f"mathvista_{pid}"
        if item_id in used:
            continue
        if str(row.get("question_type") or "").lower() != "multi_choice":
            continue
        choices = row.get("choices")
        if not choices or len(list(choices)) < 2:
            continue
        choices = [str(c) for c in list(choices)]
        answer = str(row.get("answer") or "").strip()
        if answer not in choices:
            continue
        question = str(row.get("question") or row.get("query") or "").strip()
        why = looks_sn(question)
        if not why:
            continue
        img = as_pil(row.get("decoded_image") or row.get("image"))
        if img is None:
            continue
        pool.append((why, i, row, img, choices, choices.index(answer), question))
    rng.shuffle(pool)
    # Prefer count+location, then clocks, then size+location
    order = {"count_plus_location": 0, "analog_clock": 1, "size_plus_location": 2}
    pool.sort(key=lambda x: order[x[0]])
    images = MATH_DIR / "images"
    out = []
    for why, i, row, img, choices, correct, question in pool:
        if len(out) >= N_WANT:
            break
        pid = str(row.get("pid") or i)
        dest = save_pil(img, images / f"mathvista_{pid}")
        out.append(
            item_base(
                item_id=f"mathvista_{pid}",
                image=dest,
                source="AI4Math/MathVista:testmini",
                question=question,
                options=choices,
                correct_index=correct,
                spatial=True,
                numeric=True,
                note=f"SN top-up. Reason: {why}. Confirm or correct.",
            )
        )
    return out


def collect_blink_count(used: set[str], rng: random.Random, need: int) -> list[dict]:
    path = blink_counting_parquet()
    if path is None or need <= 0:
        return []
    ds = load_parquet(path)
    pool = []
    for i in range(len(ds)):
        item_id = f"blink_counting_{i}"
        if item_id in used:
            continue
        row = ds[i]
        question = str(row.get("question") or row.get("prompt") or "").strip()
        if not looks_sn(question):
            continue
        img = as_pil(row.get("image_1") or row.get("image"))
        if img is None:
            continue
        choices = [str(c) for c in list(row.get("choices") or [])]
        if len(choices) < 2:
            continue
        answer = str(row.get("answer") or "").strip()
        if answer in choices:
            correct = choices.index(answer)
        elif len(answer) == 1 and answer.upper() in "ABCD":
            correct = ord(answer.upper()) - ord("A")
            if correct >= len(choices):
                continue
        else:
            continue
        pool.append((i, row, img, choices, correct, question))
    rng.shuffle(pool)
    images = BLINK_DIR / "images"
    out = []
    for i, row, img, choices, correct, question in pool[:need]:
        dest = save_pil(img, images / f"blink_counting_{i}")
        out.append(
            item_base(
                item_id=f"blink_counting_{i}",
                image=dest,
                source="BLINK-Benchmark/BLINK:Counting/val",
                question=question,
                options=choices,
                correct_index=correct,
                spatial=True,
                numeric=True,
                note="SN top-up from unused BLINK Counting. Confirm or correct.",
            )
        )
    return out


def main() -> None:
    used = used_ids()
    rng = random.Random(SEED)
    new_items = collect_mathvista(used, rng)
    if len(new_items) < N_WANT:
        new_items.extend(collect_blink_count(used, rng, N_WANT - len(new_items)))
    queue = read_json(RESULTS / "label_queue.json")
    have = {row["item_id"] for row in queue["items"]}
    added = [row for row in new_items if row["item_id"] not in have]
    queue["items"].extend(added)
    counts: dict[str, int] = {"SR": 0, "SN": 0, "NN": 0, "SEM": 0}
    for row in queue["items"]:
        counts[row.get("proposed_cell", "SEM")] = counts.get(row.get("proposed_cell", "SEM"), 0) + 1
    queue["recorded_at"] = now_iso()
    queue["n_items"] = len(queue["items"])
    queue["by_proposed_cell"] = counts
    queue["note"] = (
        "Hand-label queue. Proposed cells for the first 290 follow hand labels. "
        f"Added {len(added)} SN top-up items. Existing hand_labels.json is not modified."
    )
    write_json(RESULTS / "label_queue.json", queue)
    write_json(
        RESULTS / "sn_topup.json",
        {
            "recorded_at": now_iso(),
            "n_added": len(added),
            "item_ids": [row["item_id"] for row in added],
            "reasons": [row["label_note"] for row in added],
        },
    )
    print(f"added {len(added)} SN candidates")
    print("queue", queue["n_items"], "proposed", counts)
    print("Refresh http://127.0.0.1:8765 and use To label")


if __name__ == "__main__":
    main()
