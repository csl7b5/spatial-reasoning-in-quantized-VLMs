# E1 protocol (locked)

This is the human-written E1 spec, stored in-repo so later scripts can cite it.

See `results/e1/analysis_prereg.md` for the analysis lock.

Runtime: llama-cpp-python / Metal only. Reference: F16 GGUF. Vision tower: F16 mmproj, constant. Models: C and A. B and Glimmer out.

Pre-flight order: P1 determinism, P2 ladder, P3 resolution, P4 parser. All four before any full benchmark scoring.

P2 F16 download was approved (user said continue). C and A F16 are on disk; k-quant ladders were generated with e1/bin/llama-quantize. See results/e1/p2_ladder.json.

P1 PASS: 30 items × 3 runs, C and A, F16 and Q4_K_M, max |Δ| = 0.0 nats. See results/e1/p1.json.

P3 pin: resize to 1280×960 and set MTMD image_min/max_tokens = 1200. See results/e1/p3_resolution.json.

P4: 100 A-F16 generations parsed as JSON {"caption": "..."}. Failure > 2% stops. No guessing fallback. See results/e1/p4_parser.json.
