"""Download labeling samples for SN, NN, and SEM. Does not wipe SR labels."""

from __future__ import annotations

import random
import re
from pathlib import Path

from datasets import load_dataset
from huggingface_hub import hf_hub_download, list_repo_files
from PIL import Image

from common import DATA, RESULTS, hf_token, now_iso, read_json, write_json
from inventory import main as write_inventory

SEED = 20260815
N_SAMPLE = 80

POPE_REPO = "lmms-lab/POPE"
BLINK_REPO = "BLINK-Benchmark/BLINK"
MATHVISTA_REPO = "AI4Math/MathVista"

POPE_DIR = DATA / "pope"
BLINK_DIR = DATA / "blink"
MATH_DIR = DATA / "mathvista"

# MathVista contexts/tasks that are spatial or chart-like. Conservative.
NN_EXCLUDE_CONTEXT = {
    "geometry diagram",
    "bar chart",
    "line plot",
    "function plot",
    "pie chart",
    "scatter plot",
    "scientific figure",
    "puzzle test",
}
NN_EXCLUDE_TASK = {"geometry problem solving"}
NN_EXCLUDE_SKILL = {"geometry reasoning"}
NN_EXCLUDE_CONTEXT_SUBSTR = ("chart", "plot", "geometry")


def proposed_cell(spatial: bool, numeric: bool) -> str:
    if spatial and not numeric:
        return "SR"
    if spatial and numeric:
        return "SN"
    if (not spatial) and numeric:
        return "NN"
    return "SEM"


def token() -> str | None:
    return hf_token()


def fetch_file(repo: str, filename: str, dest_dir: Path) -> Path:
    dest_dir.mkdir(parents=True, exist_ok=True)
    existing = dest_dir / Path(filename).name
    if existing.is_file() and existing.stat().st_size > 0:
        return existing
    path = hf_hub_download(
        repo_id=repo,
        repo_type="dataset",
        filename=filename,
        local_dir=dest_dir,
        token=token(),
    )
    return Path(path)


def save_pil(img: Image.Image, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if img.mode in {"RGBA", "P", "LA"}:
        dest = dest.with_suffix(".png")
        img.save(dest)
    else:
        dest = dest.with_suffix(".jpg")
        img.convert("RGB").save(dest, quality=95)
    return dest


def as_pil(value) -> Image.Image | None:
    if value is None:
        return None
    if isinstance(value, Image.Image):
        return value
    if isinstance(value, dict) and value.get("bytes"):
        from io import BytesIO

        return Image.open(BytesIO(value["bytes"]))
    return None


def first_repo_file(repo: str, prefix: str) -> str:
    names = list_repo_files(repo, repo_type="dataset", token=token())
    matches = [n for n in names if n.startswith(prefix) and n.endswith(".parquet")]
    if not matches:
        raise FileNotFoundError(f"{repo} has no parquet starting with {prefix}")
    return sorted(matches)[0]


def load_parquet(path: Path):
    return load_dataset("parquet", data_files=str(path), split="train")


def item_base(
    item_id: str,
    image: Path,
    source: str,
    question: str,
    options: list[str],
    correct_index: int,
    spatial: bool,
    numeric: bool,
    note: str,
) -> dict:
    cell = proposed_cell(spatial, numeric)
    return {
        "item_id": item_id,
        "image": str(image),
        "source": source,
        "cell": cell,
        "spatial": spatial,
        "numeric": numeric,
        "options": options,
        "correct_index": correct_index,
        "correct_option": options[correct_index],
        "question": question,
        "proposed_spatial": spatial,
        "proposed_numeric": numeric,
        "proposed_cell": cell,
        "label_note": note,
    }


def download_pope() -> dict:
    filename = first_repo_file(POPE_REPO, "Full/random")
    parquet = fetch_file(POPE_REPO, filename, POPE_DIR)
    ds = load_parquet(parquet)
    by_answer: dict[str, list[int]] = {"yes": [], "no": []}
    for i, row in enumerate(ds):
        ans = str(row.get("answer", "")).strip().lower()
        if ans in by_answer:
            by_answer[ans].append(i)
    rng = random.Random(SEED)
    chosen = []
    for ans in ("yes", "no"):
        idxs = list(by_answer[ans])
        rng.shuffle(idxs)
        chosen.extend(idxs[: N_SAMPLE // 2])
    chosen.sort()
    images = POPE_DIR / "images"
    items = []
    for i in chosen:
        row = ds[i]
        img = as_pil(row["image"])
        if img is None:
            continue
        qid = str(row.get("question_id") or row.get("id") or i)
        dest = save_pil(img, images / f"pope_{qid}")
        answer = str(row["answer"]).strip().lower()
        options = ["yes", "no"]
        items.append(
            item_base(
                item_id=f"pope_{qid}",
                image=dest,
                source="lmms-lab/POPE:Full/random",
                question=str(row["question"]).strip(),
                options=options,
                correct_index=options.index(answer) if answer in options else 0,
                spatial=False,
                numeric=False,
                note="POPE presence yes/no. Auto-proposed SEM. Confirm the question does not also ask where.",
            )
        )
    return {
        "repo": POPE_REPO,
        "license": "not stated on Hub card; images are COCO-derived; research-eval sample only",
        "file": str(parquet),
        "bytes": parquet.stat().st_size,
        "split": "Full/random",
        "n_available": len(ds),
        "n_sampled": len(items),
        "items_path": str(POPE_DIR / "items.json"),
        "items": items,
    }


def blink_correct_index(choices: list[str], answer: str) -> int | None:
    ans = str(answer).strip()
    if ans in choices:
        return choices.index(ans)
    letter = ans.strip("() ").upper()
    if len(letter) == 1 and "A" <= letter <= "Z":
        idx = ord(letter) - ord("A")
        if 0 <= idx < len(choices):
            return idx
    for i, choice in enumerate(choices):
        if choice.strip().upper() == ans.upper():
            return i
        if choice.strip().upper().startswith(f"({letter})") or choice.strip().upper().startswith(f"{letter})"):
            return i
    return None


def has_second_image(row: dict) -> bool:
    for key in ("image_2", "image_3", "image_4"):
        if as_pil(row.get(key)) is not None:
            return True
    return False


def download_blink_task(task: str, n: int, rng: random.Random) -> tuple[dict, list[dict]]:
    filename = first_repo_file(BLINK_REPO, f"{task}/val")
    parquet = fetch_file(BLINK_REPO, filename, BLINK_DIR / task)
    ds = load_parquet(parquet)
    usable = []
    skipped_two_image = 0
    for i in range(len(ds)):
        row = ds[i]
        if has_second_image(row):
            skipped_two_image += 1
            continue
        img = as_pil(row.get("image_1") or row.get("image"))
        if img is None:
            continue
        choices = row.get("choices")
        if choices is None:
            continue
        if isinstance(choices, str):
            choices = [c.strip() for c in re.split(r"\s*\n\s*", choices) if c.strip()]
        else:
            choices = [str(c) for c in list(choices)]
        if len(choices) < 2:
            continue
        correct = blink_correct_index(choices, str(row.get("answer", "")))
        if correct is None:
            continue
        usable.append((i, row, img, choices, correct))
    rng.shuffle(usable)
    picked = usable[:n]
    picked.sort(key=lambda x: x[0])
    images = BLINK_DIR / "images"
    items = []
    for i, row, img, choices, correct in picked:
        dest = save_pil(img, images / f"blink_{task.lower()}_{i}")
        question = str(row.get("question") or row.get("prompt") or "").strip()
        items.append(
            item_base(
                item_id=f"blink_{task.lower()}_{i}",
                image=dest,
                source=f"BLINK-Benchmark/BLINK:{task}/val",
                question=question,
                options=choices,
                correct_index=correct,
                spatial=True,
                numeric=True,
                note=f"BLINK {task} val, single-image only. Auto-proposed SN. Confirm or correct.",
            )
        )
    meta = {
        "task": task,
        "file": str(parquet),
        "bytes": parquet.stat().st_size,
        "n_available": len(ds),
        "n_single_image_usable": len(usable),
        "n_skipped_two_image": skipped_two_image,
        "n_sampled": len(items),
    }
    return meta, items


def download_blink() -> dict:
    rng = random.Random(SEED)
    depth_meta, depth_items = download_blink_task("Relative_Depth", N_SAMPLE // 2, rng)
    count_meta, count_items = download_blink_task("Counting", N_SAMPLE - len(depth_items), rng)
    items = depth_items + count_items
    return {
        "repo": BLINK_REPO,
        "license": "check recorded README; val splits only (test answers are hidden)",
        "tasks": [depth_meta, count_meta],
        "n_sampled": len(items),
        "items_path": str(BLINK_DIR / "items.json"),
        "items": items,
        "note": "Two-image items were skipped. Protocol has not decided how to score those.",
    }


def mathvista_is_nn(row: dict) -> tuple[bool, str]:
    meta = row.get("metadata") or {}
    context = str(meta.get("context") or "").strip().lower()
    task = str(meta.get("task") or "").strip().lower()
    skills = [str(s).strip().lower() for s in (meta.get("skills") or [])]
    qtype = str(row.get("question_type") or "").strip().lower()
    if qtype != "multi_choice":
        return False, "not_multi_choice"
    if task in NN_EXCLUDE_TASK:
        return False, "geometry_task"
    if context in NN_EXCLUDE_CONTEXT:
        return False, f"excluded_context:{context}"
    if any(part in context for part in NN_EXCLUDE_CONTEXT_SUBSTR):
        return False, f"context_substr:{context}"
    if any(s in NN_EXCLUDE_SKILL for s in skills):
        return False, "geometry_skill"
    numeric_skills = {"arithmetic reasoning", "numeric commonsense", "algebraic reasoning", "statistical reasoning"}
    if not any(s in numeric_skills for s in skills):
        return False, f"no_numeric_skill:{skills}"
    choices = row.get("choices")
    if not choices or len(list(choices)) < 2:
        return False, "no_choices"
    return True, "ok"


def download_mathvista() -> dict:
    filename = first_repo_file(MATHVISTA_REPO, "data/testmini")
    parquet = fetch_file(MATHVISTA_REPO, filename, MATH_DIR)
    ds = load_parquet(parquet)
    reasons: dict[str, int] = {}
    usable = []
    for i in range(len(ds)):
        row = ds[i]
        ok, reason = mathvista_is_nn(row)
        reasons[reason] = reasons.get(reason, 0) + 1
        if not ok:
            continue
        img = as_pil(row.get("decoded_image") or row.get("image"))
        if img is None:
            reasons["no_image"] = reasons.get("no_image", 0) + 1
            continue
        choices = [str(c) for c in list(row["choices"])]
        answer = str(row.get("answer") or "").strip()
        if answer not in choices:
            reasons["answer_not_in_choices"] = reasons.get("answer_not_in_choices", 0) + 1
            continue
        usable.append((i, row, img, choices, choices.index(answer)))
    rng = random.Random(SEED)
    rng.shuffle(usable)
    picked = usable[:N_SAMPLE]
    picked.sort(key=lambda x: x[0])
    images = MATH_DIR / "images"
    items = []
    for i, row, img, choices, correct in picked:
        pid = str(row.get("pid") or i)
        dest = save_pil(img, images / f"mathvista_{pid}")
        meta = row.get("metadata") or {}
        items.append(
            item_base(
                item_id=f"mathvista_{pid}",
                image=dest,
                source="AI4Math/MathVista:testmini",
                question=str(row.get("question") or row.get("query") or "").strip(),
                options=choices,
                correct_index=correct,
                spatial=False,
                numeric=True,
                note=(
                    "MathVista testmini, multi-choice, geometry/charts dropped. "
                    f"task={meta.get('task')}; context={meta.get('context')}. Auto-proposed NN."
                ),
            )
        )
    return {
        "repo": MATHVISTA_REPO,
        "license": "cc-by-sa-4.0",
        "file": str(parquet),
        "bytes": parquet.stat().st_size,
        "split": "testmini only; did not download test or images.zip",
        "n_available": len(ds),
        "n_usable_nn": len(usable),
        "filter_reasons": reasons,
        "n_sampled": len(items),
        "items_path": str(MATH_DIR / "items.json"),
        "items": items,
    }


def blink_license_note() -> str:
    try:
        path = hf_hub_download(
            repo_id=BLINK_REPO,
            repo_type="dataset",
            filename="README.md",
            local_dir=BLINK_DIR,
            token=token(),
        )
        text = Path(path).read_text(errors="replace")
        for line in text.splitlines()[:40]:
            if "license" in line.lower():
                return line.strip()
        return "README downloaded; no license line in the first 40 lines"
    except Exception as exc:
        return f"could not read README: {exc}"


def main() -> None:
    pope = download_pope()
    blink = download_blink()
    blink["license"] = blink_license_note()
    mathvista = download_mathvista()

    for bundle, path in (
        (pope, POPE_DIR / "items.json"),
        (blink, BLINK_DIR / "items.json"),
        (mathvista, MATH_DIR / "items.json"),
    ):
        write_json(
            path,
            {
                "recorded_at": now_iso(),
                "n_items": len(bundle["items"]),
                "items": bundle["items"],
            },
        )

    payload = {
        "recorded_at": now_iso(),
        "status": "labeling_samples_only",
        "note": "These are 80-item labeling samples, not the full 300–500 scoring pools. EmbSpatial was not downloaded (scene licenses + images not in the Hub JSON).",
        "seed": SEED,
        "n_per_cell_target": N_SAMPLE,
        "sources": {
            "SEM": {k: v for k, v in pope.items() if k != "items"},
            "SN": {k: v for k, v in blink.items() if k != "items"},
            "NN": {k: v for k, v in mathvista.items() if k != "items"},
        },
        "n_sampled": {
            "SN": len(blink["items"]),
            "NN": len(mathvista["items"]),
            "SEM": len(pope["items"]),
        },
    }
    write_json(RESULTS / "label_sample_sources.json", payload)
    write_inventory()
    print("SEM", payload["n_sampled"]["SEM"], "from POPE random")
    print("SN", payload["n_sampled"]["SN"], "from BLINK Relative_Depth + Counting val")
    print("NN", payload["n_sampled"]["NN"], "from MathVista testmini after geometry/chart filter")
    print("NN filter:", mathvista["filter_reasons"])
    print(RESULTS / "label_sample_sources.json")


if __name__ == "__main__":
    main()
