"""Gate D: extract hidden states from Model C on transformers/MPS."""

from __future__ import annotations

import time

from common import (
    IMAGE_PROMPT,
    LOGPROB_PROMPT,
    ensure_spatial_image,
    exception_record,
    memory_snapshot,
    model_results_dir,
    model_spec,
    now_iso,
    parse_model_arg,
    previous_gate_allows_continue,
    release_torch,
    require_mps,
    write_json,
)


def _tensor_info(tensor) -> dict:
    nbytes = int(tensor.numel() * tensor.element_size())
    return {
        "shape": list(tensor.shape),
        "dtype": str(tensor.dtype),
        "device": str(tensor.device),
        "numel": int(tensor.numel()),
        "nbytes": nbytes,
        "mib": round(nbytes / (1024**2), 4),
    }


def run_transformers(spec: dict) -> dict:
    record: dict = {
        "backend": "transformers_mps",
        "status": "FAIL",
        "started_at": now_iso(),
        "memory_before": memory_snapshot(),
    }
    try:
        import torch
        from PIL import Image
        from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

        require_mps()
        processor = AutoProcessor.from_pretrained(spec["transformers"])
        model = Qwen3VLForConditionalGeneration.from_pretrained(
            spec["transformers"],
            dtype=torch.bfloat16,
            attn_implementation="sdpa",
        )
        model.to("mps")
        model.eval()
        record["config"] = {
            "hidden_size": getattr(model.config, "hidden_size", None)
            or getattr(getattr(model.config, "text_config", None), "hidden_size", None),
            "num_hidden_layers": getattr(model.config, "num_hidden_layers", None)
            or getattr(getattr(model.config, "text_config", None), "num_hidden_layers", None),
            "vision_hidden_size": getattr(
                getattr(model.config, "vision_config", None), "hidden_size", None
            ),
        }

        messages = [{"role": "user", "content": [{"type": "text", "text": LOGPROB_PROMPT}]}]
        inputs = processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        ).to(model.device)
        t0 = time.perf_counter()
        with torch.inference_mode():
            text_out = model(**inputs, output_hidden_states=True)
        record["text_forward_s"] = round(time.perf_counter() - t0, 4)
        hidden = text_out.hidden_states
        if hidden is None:
            raise RuntimeError("text forward returned hidden_states=None")
        record["text"] = {
            "n_layers_plus_embed": len(hidden),
            "last": _tensor_info(hidden[-1]),
            "first": _tensor_info(hidden[0]),
            "prompt": LOGPROB_PROMPT,
        }

        image = Image.open(ensure_spatial_image())
        vision_messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": IMAGE_PROMPT},
                ],
            }
        ]
        vision_inputs = processor.apply_chat_template(
            vision_messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        ).to(model.device)
        t1 = time.perf_counter()
        with torch.inference_mode():
            vision_out = model(**vision_inputs, output_hidden_states=True)
        record["vision_forward_s"] = round(time.perf_counter() - t1, 4)
        vision_hidden = vision_out.hidden_states
        if vision_hidden is None:
            raise RuntimeError("vision forward returned hidden_states=None")
        record["vision"] = {
            "n_layers_plus_embed": len(vision_hidden),
            "last": _tensor_info(vision_hidden[-1]),
            "first": _tensor_info(vision_hidden[0]),
            "prompt": IMAGE_PROMPT,
            "has_pixel_values": "pixel_values" in vision_inputs,
        }
        if "pixel_values" in vision_inputs:
            record["vision"]["pixel_values"] = _tensor_info(vision_inputs["pixel_values"])
        record["memory_after"] = memory_snapshot()
        record["status"] = "PASS"
        del model
        del processor
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        release_torch()
        record["memory_after_release"] = memory_snapshot()
        record["finished_at"] = now_iso()
    return record


def main() -> None:
    letter = parse_model_arg()
    spec = model_spec(letter)
    out_dir = model_results_dir(letter)
    ok, reason = previous_gate_allows_continue("gate_c", letter)
    if not ok:
        payload = {
            "gate": "D",
            "name": "hidden",
            "model": letter,
            "recorded_at": now_iso(),
            "overall_status": "FAIL",
            "stop": True,
            "stop_reason": f"Gate C did not allow continue: {reason}",
        }
        write_json(out_dir / "gate_d.json", payload)
        raise SystemExit(2)

    transformers_result = run_transformers(spec)
    llama_note = {
        "backend": "llama_cpp_gguf",
        "status": "UNSUPPORTED",
        "note": (
            "llama-cpp-python 0.3.34 does not expose layer hidden states. "
            "This is recorded, not worked around."
        ),
    }
    if transformers_result["status"] == "PASS":
        overall = "PASS"
        stop = False
        stop_reason = None
    else:
        overall = "FAIL"
        stop = True
        stop_reason = "Hidden-state extraction failed on transformers/MPS. Stop."

    payload = {
        "gate": "D",
        "name": "hidden",
        "model": letter,
        "recorded_at": now_iso(),
        "overall_status": overall,
        "stop": stop,
        "stop_reason": stop_reason,
        "backends": {
            "transformers_mps": transformers_result,
            "llama_cpp_gguf": llama_note,
        },
    }
    write_json(out_dir / "gate_d.json", payload)
    print(f"Gate D model={letter} {overall} stop={stop}")
    if stop:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
