"""Gate B: extract token log-probabilities from Model C. Do not tune prompts."""

from __future__ import annotations

import math
import time

from common import (
    LOGPROB_PROMPT,
    exception_record,
    memory_snapshot,
    model_results_dir,
    model_spec,
    now_iso,
    parse_model_arg,
    previous_gate_allows_continue,
    read_json,
    release_torch,
    require_mps,
    write_json,
)


def _top_logprobs_from_logits(logits, tokenizer, k: int = 5) -> list[dict]:
    import torch

    logprobs = torch.nn.functional.log_softmax(logits.float(), dim=-1)
    values, indices = torch.topk(logprobs, k)
    rows = []
    for value, index in zip(values.tolist(), indices.tolist()):
        token = tokenizer.convert_ids_to_tokens(index)
        rows.append(
            {
                "token_id": int(index),
                "token": token,
                "logprob": float(value),
                "prob": float(math.exp(value)),
            }
        )
    return rows


def run_transformers(spec: dict) -> dict:
    record: dict = {
        "backend": "transformers_mps",
        "status": "FAIL",
        "started_at": now_iso(),
        "prompt": LOGPROB_PROMPT,
        "memory_before": memory_snapshot(),
    }
    try:
        import torch
        from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

        require_mps()
        t0 = time.perf_counter()
        processor = AutoProcessor.from_pretrained(spec["transformers"])
        model = Qwen3VLForConditionalGeneration.from_pretrained(
            spec["transformers"],
            dtype=torch.bfloat16,
            attn_implementation="sdpa",
        )
        model.to("mps")
        model.eval()
        record["load_s"] = round(time.perf_counter() - t0, 4)

        messages = [{"role": "user", "content": [{"type": "text", "text": LOGPROB_PROMPT}]}]
        inputs = processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        ).to(model.device)
        t1 = time.perf_counter()
        generated = model.generate(
            **inputs,
            max_new_tokens=8,
            do_sample=False,
            output_scores=True,
            return_dict_in_generate=True,
        )
        scores = generated.scores
        if not scores:
            raise RuntimeError("generate returned empty scores")
        first = scores[0][0]
        tokenizer = processor.tokenizer
        record["first_step_top5"] = _top_logprobs_from_logits(first, tokenizer, k=5)
        record["n_score_steps"] = len(scores)
        record["score_shape"] = list(scores[0].shape)
        record["score_dtype"] = str(scores[0].dtype)
        new_ids = generated.sequences[0][inputs["input_ids"].shape[-1] :]
        record["greedy_tokens"] = [
            {
                "token_id": int(tid),
                "token": tokenizer.convert_ids_to_tokens(int(tid)),
            }
            for tid in new_ids.tolist()
        ]
        record["greedy_text"] = processor.batch_decode(
            [new_ids], skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0]
        record["generate_s"] = round(time.perf_counter() - t1, 4)
        record["logprobs_numeric"] = True
        record["status"] = "PASS"
        del model
        del processor
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        release_torch()
        record["memory_after"] = memory_snapshot()
        record["finished_at"] = now_iso()
    return record


def run_llamacpp(spec: dict) -> dict:
    record: dict = {
        "backend": "llama_cpp_gguf_text",
        "status": "FAIL",
        "started_at": now_iso(),
        "prompt": LOGPROB_PROMPT,
        "memory_before": memory_snapshot(),
    }
    llm = None
    try:
        from llama_cpp import Llama

        t0 = time.perf_counter()
        llm = Llama(
            model_path=str(spec["gguf"]),
            n_ctx=2048,
            n_gpu_layers=-1,
            logits_all=True,
            verbose=False,
        )
        record["load_s"] = round(time.perf_counter() - t0, 4)
        t1 = time.perf_counter()
        out = llm.create_completion(
            prompt=LOGPROB_PROMPT,
            max_tokens=8,
            temperature=0,
            logprobs=5,
        )
        choice = out["choices"][0]
        logprobs = choice.get("logprobs")
        record["generate_s"] = round(time.perf_counter() - t1, 4)
        record["text"] = choice.get("text")
        if logprobs:
            def _f(value):
                return float(value) if value is not None else None

            logprobs = {
                **logprobs,
                "token_logprobs": [_f(v) for v in logprobs.get("token_logprobs") or []],
                "top_logprobs": [
                    {token: _f(score) for token, score in row.items()}
                    for row in (logprobs.get("top_logprobs") or [])
                ],
            }
        record["logprobs"] = logprobs
        record["logprobs_numeric"] = bool(logprobs and logprobs.get("token_logprobs"))
        if record["logprobs_numeric"]:
            record["status"] = "PASS"
        else:
            raise RuntimeError("llama-cpp completion did not return numeric logprobs")
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        if llm is not None:
            del llm
        record["memory_after"] = memory_snapshot()
        record["finished_at"] = now_iso()
    return record


def main() -> None:
    letter = parse_model_arg()
    spec = model_spec(letter)
    out_dir = model_results_dir(letter)
    ok, reason = previous_gate_allows_continue("gate_a", letter)
    if not ok:
        payload = {
            "gate": "B",
            "name": "logprob",
            "model": letter,
            "recorded_at": now_iso(),
            "overall_status": "FAIL",
            "stop": True,
            "stop_reason": f"Gate A did not allow continue: {reason}",
        }
        write_json(out_dir / "gate_b.json", payload)
        raise SystemExit(2)

    gate_a_payload = read_json(out_dir / "gate_a.json")
    transformers_result = run_transformers(spec)
    gguf_result = None
    if gate_a_payload["backends"]["llama_cpp_gguf_text"]["status"] == "PASS":
        gguf_result = run_llamacpp(spec)
    else:
        gguf_result = {
            "backend": "llama_cpp_gguf_text",
            "status": "SKIP",
            "reason": "Gate A GGUF text backend failed; not retried.",
        }

    tf_ok = transformers_result["status"] == "PASS"
    if tf_ok:
        overall = "PASS" if gguf_result["status"] in {"PASS", "SKIP"} else "PARTIAL"
        stop = False
        stop_reason = None
        if gguf_result["status"] == "FAIL":
            stop_reason = "GGUF logprobs failed. Transformers logprobs passed; continue."
    else:
        overall = "FAIL"
        stop = True
        stop_reason = "Transformers logprobs failed. Stop later gates."

    payload = {
        "gate": "B",
        "name": "logprob",
        "model": letter,
        "recorded_at": now_iso(),
        "overall_status": overall,
        "stop": stop,
        "stop_reason": stop_reason,
        "prompt_fixed": True,
        "prompt_tuned": False,
        "backends": {
            "transformers_mps": transformers_result,
            "llama_cpp_gguf_text": gguf_result,
        },
    }
    write_json(out_dir / "gate_b.json", payload)
    print(f"Gate B model={letter} {overall} stop={stop}")
    if stop:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
