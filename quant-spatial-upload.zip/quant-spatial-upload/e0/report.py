"""Compile E0 JSON measurements into results/e0/report.json."""

from __future__ import annotations

from common import RESULTS, now_iso, read_json, write_json, write_versions

C_FILES = [
    "disk_audit.json",
    "versions.json",
    "models.json",
    "download_c.json",
    "gate_a.json",
    "gate_b.json",
    "gate_c.json",
    "gate_d.json",
    "gate_e.json",
]
A_FILES = [
    "download_a.json",
    "download_a_preflight.json",
]


def _load(path) -> dict | None:
    if not path.exists():
        return None
    return read_json(path)


def _gate_block(out_dir, prefix: str) -> dict:
    gates = {}
    for key in ("gate_a", "gate_b", "gate_c", "gate_d", "gate_e"):
        payload = _load(out_dir / f"{key}.json")
        gates[key] = None if payload is None else payload.get("overall_status")
    stopped = []
    for key in ("gate_a", "gate_b", "gate_c", "gate_d", "gate_e"):
        payload = _load(out_dir / f"{key}.json")
        if payload and payload.get("stop"):
            stopped.append({"gate": key, "reason": payload.get("stop_reason")})
    return {"statuses": gates, "stopped": stopped}


def _measured_from(out_dir, download: dict | None) -> dict:
    gate_a = _load(out_dir / "gate_a.json") or {}
    gate_b = _load(out_dir / "gate_b.json") or {}
    gate_c = _load(out_dir / "gate_c.json") or {}
    gate_d = _load(out_dir / "gate_d.json") or {}
    gate_e = _load(out_dir / "gate_e.json") or {}
    tf_a = (gate_a.get("backends") or {}).get("transformers_mps") or {}
    gguf_a = (gate_a.get("backends") or {}).get("llama_cpp_gguf_text") or {}
    vis_a = (gate_a.get("backends") or {}).get("llama_cpp_gguf_vision") or {}
    tf_e = (gate_e.get("backends") or {}).get("transformers_mps") or {}
    gguf_e = (gate_e.get("backends") or {}).get("llama_cpp_gguf_text") or {}
    tf_d = (gate_d.get("backends") or {}).get("transformers_mps") or {}
    model_run = gate_c.get("model_run") or gate_c.get("model_c") or {}
    download = download or {}
    return {
        "download_total_gb": download.get("total_gb"),
        "transformers_gb": (download.get("downloads") or {}).get("transformers", {}).get("gb"),
        "gguf_q8_0_gb": (download.get("downloads") or {}).get("gguf_q8_0", {}).get("gb"),
        "mmproj_f16_gb": (download.get("downloads") or {}).get("mmproj_f16", {}).get("gb"),
        "gate_a_transformers": tf_a.get("status"),
        "gate_a_transformers_load_s": tf_a.get("load_s"),
        "gate_a_transformers_text_tokens": (tf_a.get("text") or {}).get("n_new_tokens"),
        "gate_a_transformers_vision_tokens": (tf_a.get("vision") or {}).get("n_new_tokens"),
        "gate_a_gguf_text": gguf_a.get("status"),
        "gate_a_gguf_text_load_s": gguf_a.get("load_s"),
        "gate_a_gguf_text_tokens": (gguf_a.get("text") or {}).get("completion_tokens"),
        "gate_a_gguf_vision": vis_a.get("status"),
        "gate_a_gguf_vision_tokens": (vis_a.get("vision") or {}).get("completion_tokens"),
        "gate_a_metal_atexit_abort": bool(gate_a.get("process_exit_after_json")),
        "gate_b_transformers_first_logprob": (
            ((gate_b.get("backends") or {}).get("transformers_mps") or {}).get("first_step_top5")
            or [{}]
        )[0].get("logprob"),
        "gate_c_gold_n_pass": (gate_c.get("gold") or {}).get("n_pass"),
        "gate_c_model_json_parseable": model_run.get("model_output_parseable_json"),
        "gate_d_hidden_size": (tf_d.get("config") or {}).get("hidden_size"),
        "gate_d_num_hidden_layers": (tf_d.get("config") or {}).get("num_hidden_layers"),
        "gate_d_text_last_shape": ((tf_d.get("text") or {}).get("last") or {}).get("shape"),
        "gate_d_vision_last_shape": ((tf_d.get("vision") or {}).get("last") or {}).get("shape"),
        "gate_e_transformers_peak_rss_gib": tf_e.get("rss_peak_gib"),
        "gate_e_transformers_mps_peak_gib": tf_e.get("mps_peak_gib"),
        "gate_e_transformers_observed_peak_gib": tf_e.get("observed_peak_gib"),
        "gate_e_transformers_mps_allocated_after_load_gib": (tf_e.get("memory_after_load") or {}).get(
            "mps_allocated_gib"
        ),
        "gate_e_transformers_headroom_vs_22gib": tf_e.get("headroom_vs_practical_high_gib"),
        "gate_e_gguf_peak_rss_gib": gguf_e.get("rss_peak_gib"),
        "gate_e_gguf_observed_peak_gib": gguf_e.get("observed_peak_gib"),
        "gate_e_gguf_headroom_vs_22gib": gguf_e.get("headroom_vs_practical_high_gib"),
    }


def main() -> None:
    write_versions()
    c_dir = RESULTS
    a_dir = RESULTS / "a"
    c_gates = _gate_block(c_dir, "C")
    a_gates = _gate_block(a_dir, "A")
    download_c = _load(RESULTS / "download_c.json")
    download_a = _load(RESULTS / "download_a.json")
    missing = [name for name in C_FILES if _load(RESULTS / name) is None]
    if download_a is None:
        missing.append("download_a.json")
    a_gate_missing = [
        f"a/{key}.json"
        for key in ("gate_a", "gate_b", "gate_c", "gate_d", "gate_e")
        if _load(a_dir / f"{key}.json") is None
    ]

    c_fail = any(status == "FAIL" for status in c_gates["statuses"].values() if status)
    a_fail = any(status == "FAIL" for status in a_gates["statuses"].values() if status)
    a_started = download_a is not None or any(a_gates["statuses"].values())
    if c_fail or a_fail:
        overall = "FAIL"
        recommendation = "Stop. A required E0 gate failed. Do not download Model B."
    elif a_started and a_gate_missing:
        overall = "INCOMPLETE"
        recommendation = "Model A E0 is in progress or incomplete. Do not download Model B."
    elif any(status == "PARTIAL" for status in list(c_gates["statuses"].values()) + list(a_gates["statuses"].values()) if status):
        overall = "PARTIAL"
        recommendation = (
            "A backend is partial. Do not download Model B until that is resolved without workarounds."
        )
    elif a_started:
        overall = "PASS"
        recommendation = "Model C and Model A E0 gates passed. Model B remains deferred."
    else:
        overall = "PASS"
        recommendation = "Model C E0 gates passed. Model A/B download is still deferred."

    report = {
        "phase": "E0",
        "recorded_at": now_iso(),
        "overall_status": overall,
        "recommendation": recommendation,
        "stopped_gates": {"C": c_gates["stopped"], "A": a_gates["stopped"]},
        "gate_statuses": {"C": c_gates["statuses"], "A": a_gates["statuses"]},
        "missing_artifacts": missing + a_gate_missing,
        "model_c_only": not a_started,
        "model_b_downloaded": False,
        "measured": {
            "disk_free_gb": (_load(RESULTS / "disk_audit.json") or {}).get("free_gb"),
            "C": _measured_from(c_dir, download_c),
            "A": _measured_from(a_dir, download_a) if a_started else None,
        },
        "artifacts": {
            "C": {name: str(RESULTS / name) for name in C_FILES if (RESULTS / name).exists()},
            "A": {
                **{name: str(RESULTS / name) for name in A_FILES if (RESULTS / name).exists()},
                **{
                    f"a/{key}.json": str(a_dir / f"{key}.json")
                    for key in ("gate_a", "gate_b", "gate_c", "gate_d", "gate_e")
                    if (a_dir / f"{key}.json").exists()
                },
            },
        },
    }
    write_json(RESULTS / "report.json", report)
    if a_started:
        write_json(a_dir / "report.json", {"model": "A", **{k: report[k] for k in ("overall_status", "recommendation", "gate_statuses", "measured")}})
    print(f"E0 report {overall}")
    print(recommendation)
    if overall != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
