"""Download Model A only: transformers BF16 + official Q8_0 GGUF + F16 mmproj."""

from __future__ import annotations

from huggingface_hub import hf_hub_download, snapshot_download

from common import (
    MODEL_A_GGUF,
    MODEL_A_MMPROJ,
    MODEL_A_TRANSFORMERS,
    MODELS,
    RESULTS,
    dir_size_bytes,
    file_size_gb,
    hf_token,
    now_iso,
    read_json,
    write_json,
    write_versions,
)

TRANSFORMERS_REPO = "Qwen/Qwen3-VL-8B-Instruct"
GGUF_REPO = "Qwen/Qwen3-VL-8B-Instruct-GGUF"
GGUF_NAME = "Qwen3VL-8B-Instruct-Q8_0.gguf"
MMPROJ_NAME = "mmproj-Qwen3VL-8B-Instruct-F16.gguf"
EXPECTED_BYTES = {
    "transformers_shards": [
        ("model-00001-of-00004.safetensors", 4_902_275_944),
        ("model-00002-of-00004.safetensors", 4_915_962_496),
        ("model-00003-of-00004.safetensors", 4_999_831_048),
        ("model-00004-of-00004.safetensors", 2_716_270_024),
    ],
    "gguf_q8_0": 8_709_519_456,
    "mmproj_f16": 1_159_029_824,
}
EXPECTED_TRANSFORMERS_WEIGHT_BYTES = sum(size for _, size in EXPECTED_BYTES["transformers_shards"])
EXPECTED_TOTAL_BYTES = (
    EXPECTED_TRANSFORMERS_WEIGHT_BYTES
    + EXPECTED_BYTES["gguf_q8_0"]
    + EXPECTED_BYTES["mmproj_f16"]
)
ASK_LIMIT_GB = 30.0


def main() -> None:
    versions = write_versions()
    token = hf_token()
    expected_gb = EXPECTED_TOTAL_BYTES / 1e9
    preflight = {
        "recorded_at": now_iso(),
        "model": "A",
        "expected_weight_bytes": EXPECTED_TRANSFORMERS_WEIGHT_BYTES,
        "expected_gguf_bytes": EXPECTED_BYTES["gguf_q8_0"],
        "expected_mmproj_bytes": EXPECTED_BYTES["mmproj_f16"],
        "expected_total_gb": round(expected_gb, 4),
        "ask_limit_gb": ASK_LIMIT_GB,
        "requires_ask": expected_gb > ASK_LIMIT_GB,
        "model_b_included": False,
    }
    write_json(RESULTS / "download_a_preflight.json", preflight)
    if expected_gb > ASK_LIMIT_GB:
        raise SystemExit(
            f"Model A expected {expected_gb:.2f} GB > {ASK_LIMIT_GB:.0f} GB. "
            "Ask before downloading. Stop."
        )

    MODEL_A_TRANSFORMERS.mkdir(parents=True, exist_ok=True)
    MODEL_A_GGUF.parent.mkdir(parents=True, exist_ok=True)
    started = now_iso()
    snapshot_download(
        repo_id=TRANSFORMERS_REPO,
        local_dir=MODEL_A_TRANSFORMERS,
        token=token,
    )
    hf_hub_download(
        repo_id=GGUF_REPO,
        filename=GGUF_NAME,
        local_dir=MODEL_A_GGUF.parent,
        token=token,
    )
    hf_hub_download(
        repo_id=GGUF_REPO,
        filename=MMPROJ_NAME,
        local_dir=MODEL_A_MMPROJ.parent,
        token=token,
    )

    transformers_bytes = dir_size_bytes(MODEL_A_TRANSFORMERS)
    shard_records = []
    for name, expected in EXPECTED_BYTES["transformers_shards"]:
        path = MODEL_A_TRANSFORMERS / name
        size = path.stat().st_size if path.exists() else None
        shard_records.append(
            {
                "filename": name,
                "bytes": size,
                "expected_bytes": expected,
                "match": size == expected,
            }
        )
    payload = {
        "recorded_at": now_iso(),
        "started_at": started,
        "model": "A",
        "token_source": "HF_TOKEN env" if token else "none (public repo)",
        "token_written_to_source": False,
        "downloads": {
            "transformers": {
                "repo_id": TRANSFORMERS_REPO,
                "local_dir": str(MODEL_A_TRANSFORMERS),
                "bytes": transformers_bytes,
                "gb": round(transformers_bytes / 1e9, 4),
                "shards": shard_records,
                "weight_bytes": sum(row["bytes"] or 0 for row in shard_records),
                "weight_expected_bytes": EXPECTED_TRANSFORMERS_WEIGHT_BYTES,
                "weight_match": all(row["match"] for row in shard_records),
            },
            "gguf_q8_0": {
                "repo_id": GGUF_REPO,
                "filename": GGUF_NAME,
                "path": str(MODEL_A_GGUF),
                "bytes": MODEL_A_GGUF.stat().st_size,
                "gb": round(file_size_gb(MODEL_A_GGUF), 4),
                "expected_bytes": EXPECTED_BYTES["gguf_q8_0"],
                "match": MODEL_A_GGUF.stat().st_size == EXPECTED_BYTES["gguf_q8_0"],
            },
            "mmproj_f16": {
                "repo_id": GGUF_REPO,
                "filename": MMPROJ_NAME,
                "path": str(MODEL_A_MMPROJ),
                "bytes": MODEL_A_MMPROJ.stat().st_size,
                "gb": round(file_size_gb(MODEL_A_MMPROJ), 4),
                "expected_bytes": EXPECTED_BYTES["mmproj_f16"],
                "match": MODEL_A_MMPROJ.stat().st_size == EXPECTED_BYTES["mmproj_f16"],
            },
        },
        "total_gb": round(
            (transformers_bytes + MODEL_A_GGUF.stat().st_size + MODEL_A_MMPROJ.stat().st_size) / 1e9,
            4,
        ),
        "asked_before_30gb": False,
        "model_b_downloaded": False,
        "versions_recorded": bool(versions),
    }
    write_json(RESULTS / "download_a.json", payload)

    models_path = RESULTS / "models.json"
    models = read_json(models_path)
    models["selection_status"] = "model_c_and_a_downloaded"
    models["models"]["A"]["download_status"] = "complete"
    models["models"]["A"]["repository_id"] = TRANSFORMERS_REPO
    models["models"]["A"]["gguf_repository_id"] = GGUF_REPO
    models["models"]["A"]["local"] = {
        "transformers_dir": str(MODEL_A_TRANSFORMERS),
        "gguf_path": str(MODEL_A_GGUF),
        "mmproj_path": str(MODEL_A_MMPROJ),
        "transformers_gb": payload["downloads"]["transformers"]["gb"],
        "gguf_q8_0_gb": payload["downloads"]["gguf_q8_0"]["gb"],
        "mmproj_f16_gb": payload["downloads"]["mmproj_f16"]["gb"],
        "total_gb": payload["total_gb"],
    }
    write_json(models_path, models)
    print(f"Model A downloaded: {payload['total_gb']} GB under {MODELS / 'a'}")


if __name__ == "__main__":
    main()
