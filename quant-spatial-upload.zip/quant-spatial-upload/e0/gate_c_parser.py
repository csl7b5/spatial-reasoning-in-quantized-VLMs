"""Gate C: structured spatial-answer parsers. Do not tune prompts for accuracy."""

from __future__ import annotations

import json
import re
import time

from common import (
    SPATIAL_PROMPT,
    ensure_spatial_image,
    exception_record,
    memory_snapshot,
    model_results_dir,
    model_spec,
    now_iso,
    parse_model_arg,
    previous_gate_allows_continue,
    release_torch,
    require_mps,
    write_json,
)

JSON_RE = re.compile(r"\{.*?\}", re.DOTALL)
CHOICE_RE = re.compile(r"\b([ABCD])\b")
BBOX_RE = re.compile(
    r"\[\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\]"
)
SIDE_RE = re.compile(r"\b(left|right|above|below|top|bottom)\b", re.IGNORECASE)


def parse_json_object(text: str) -> dict | None:
    match = JSON_RE.search(text)
    if not match:
        return None
    try:
        value = json.loads(match.group(0))
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, dict) else None


def parse_choice_letter(text: str) -> str | None:
    match = CHOICE_RE.search(text.strip())
    return match.group(1) if match else None


def parse_bbox(text: str) -> list[float] | None:
    match = BBOX_RE.search(text)
    if not match:
        return None
    return [float(x) for x in match.groups()]


def parse_spatial_side(text: str) -> str | None:
    match = SIDE_RE.search(text)
    return match.group(1).lower() if match else None


GOLD_CASES = [
    {
        "name": "json_spatial",
        "text": 'The answer is {"shape": "circle", "side": "left"}.',
        "fn": "parse_json_object",
        "expected": {"shape": "circle", "side": "left"},
    },
    {
        "name": "choice_letter",
        "text": "Final answer: B",
        "fn": "parse_choice_letter",
        "expected": "B",
    },
    {
        "name": "bbox",
        "text": "box = [0.10, 0.20, 0.40, 0.80]",
        "fn": "parse_bbox",
        "expected": [0.10, 0.20, 0.40, 0.80],
    },
    {
        "name": "spatial_side",
        "text": "The object is on the left of the plate.",
        "fn": "parse_spatial_side",
        "expected": "left",
    },
]

PARSERS = {
    "parse_json_object": parse_json_object,
    "parse_choice_letter": parse_choice_letter,
    "parse_bbox": parse_bbox,
    "parse_spatial_side": parse_spatial_side,
}


def run_gold_cases() -> dict:
    results = []
    for case in GOLD_CASES:
        got = PARSERS[case["fn"]](case["text"])
        results.append(
            {
                "name": case["name"],
                "text": case["text"],
                "expected": case["expected"],
                "got": got,
                "pass": got == case["expected"],
            }
        )
    n_pass = sum(1 for row in results if row["pass"])
    return {
        "n_cases": len(results),
        "n_pass": n_pass,
        "status": "PASS" if n_pass == len(results) else "FAIL",
        "cases": results,
    }


def run_model_once(spec: dict) -> dict:
    record: dict = {
        "backend": "transformers_mps",
        "status": "FAIL",
        "started_at": now_iso(),
        "prompt": SPATIAL_PROMPT,
        "prompt_tuned": False,
        "memory_before": memory_snapshot(),
    }
    try:
        import torch
        from PIL import Image
        from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

        require_mps()
        processor = AutoProcessor.from_pretrained(spec["transformers"])
        model = Qwen3VLForConditionalGeneration.from_pretrained(
            spec["transformers"],
            dtype=torch.bfloat16,
            attn_implementation="sdpa",
        )
        model.to("mps")
        model.eval()
        image = Image.open(ensure_spatial_image())
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": SPATIAL_PROMPT},
                ],
            }
        ]
        inputs = processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        ).to(model.device)
        t0 = time.perf_counter()
        generated = model.generate(**inputs, max_new_tokens=64, do_sample=False)
        new_ids = generated[0][inputs["input_ids"].shape[-1] :]
        text = processor.batch_decode(
            [new_ids], skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0]
        record["generate_s"] = round(time.perf_counter() - t0, 4)
        record["output"] = text
        parsed_json = parse_json_object(text)
        record["parsed"] = {
            "json": parsed_json,
            "side": parse_spatial_side(text),
            "choice": parse_choice_letter(text),
            "bbox": parse_bbox(text),
        }
        record["model_output_parseable_json"] = bool(parsed_json)
        record["status"] = "PASS"
        record["note"] = (
            "Model parse success is recorded, not required. Prompts were not tuned."
        )
        del model
        del processor
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        release_torch()
        record["memory_after"] = memory_snapshot()
        record["finished_at"] = now_iso()
    return record


def main() -> None:
    letter = parse_model_arg()
    spec = model_spec(letter)
    out_dir = model_results_dir(letter)
    ok, reason = previous_gate_allows_continue("gate_b", letter)
    if not ok:
        payload = {
            "gate": "C",
            "name": "parser",
            "model": letter,
            "recorded_at": now_iso(),
            "overall_status": "FAIL",
            "stop": True,
            "stop_reason": f"Gate B did not allow continue: {reason}",
        }
        write_json(out_dir / "gate_c.json", payload)
        raise SystemExit(2)

    gold = run_gold_cases()
    model_run = run_model_once(spec)
    if gold["status"] != "PASS":
        overall = "FAIL"
        stop = True
        stop_reason = "Parser failed on well-formed gold strings. Stop."
    elif model_run["status"] != "PASS":
        overall = "FAIL"
        stop = True
        stop_reason = f"Model {letter} generation for parser probe failed. Stop."
    else:
        overall = "PASS"
        stop = False
        stop_reason = None

    payload = {
        "gate": "C",
        "name": "parser",
        "model": letter,
        "recorded_at": now_iso(),
        "overall_status": overall,
        "stop": stop,
        "stop_reason": stop_reason,
        "prompt_tuned": False,
        "gold": gold,
        "model_run": model_run,
    }
    write_json(out_dir / "gate_c.json", payload)
    print(f"Gate C model={letter} {overall} stop={stop}")
    if stop:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
