"""Download Model C only: transformers BF16 + official Q8_0 GGUF + F16 mmproj."""

from __future__ import annotations

from huggingface_hub import hf_hub_download, snapshot_download

from common import (
    MODEL_C_GGUF,
    MODEL_C_MMPROJ,
    MODEL_C_TRANSFORMERS,
    MODELS,
    RESULTS,
    dir_size_bytes,
    file_size_gb,
    hf_token,
    now_iso,
    read_json,
    write_json,
    write_versions,
)

TRANSFORMERS_REPO = "Qwen/Qwen3-VL-2B-Instruct"
GGUF_REPO = "Qwen/Qwen3-VL-2B-Instruct-GGUF"
GGUF_NAME = "Qwen3VL-2B-Instruct-Q8_0.gguf"
MMPROJ_NAME = "mmproj-Qwen3VL-2B-Instruct-F16.gguf"
EXPECTED_BYTES = {
    "transformers_model_safetensors": 4_255_140_312,
    "gguf_q8_0": 1_834_427_424,
    "mmproj_f16": 819_394_848,
}


def main() -> None:
    versions = write_versions()
    token = hf_token()
    MODEL_C_TRANSFORMERS.mkdir(parents=True, exist_ok=True)
    MODEL_C_GGUF.parent.mkdir(parents=True, exist_ok=True)

    started = now_iso()
    snapshot_download(
        repo_id=TRANSFORMERS_REPO,
        local_dir=MODEL_C_TRANSFORMERS,
        token=token,
    )
    hf_hub_download(
        repo_id=GGUF_REPO,
        filename=GGUF_NAME,
        local_dir=MODEL_C_GGUF.parent,
        token=token,
    )
    hf_hub_download(
        repo_id=GGUF_REPO,
        filename=MMPROJ_NAME,
        local_dir=MODEL_C_MMPROJ.parent,
        token=token,
    )

    transformers_bytes = dir_size_bytes(MODEL_C_TRANSFORMERS)
    safetensors = MODEL_C_TRANSFORMERS / "model.safetensors"
    payload = {
        "recorded_at": now_iso(),
        "started_at": started,
        "model": "C",
        "token_source": "HF_TOKEN env" if token else "none (public repo)",
        "token_written_to_source": False,
        "downloads": {
            "transformers": {
                "repo_id": TRANSFORMERS_REPO,
                "local_dir": str(MODEL_C_TRANSFORMERS),
                "bytes": transformers_bytes,
                "gb": round(transformers_bytes / 1e9, 4),
                "safetensors_bytes": safetensors.stat().st_size if safetensors.exists() else None,
                "safetensors_expected_bytes": EXPECTED_BYTES["transformers_model_safetensors"],
                "safetensors_match": (
                    safetensors.exists()
                    and safetensors.stat().st_size == EXPECTED_BYTES["transformers_model_safetensors"]
                ),
            },
            "gguf_q8_0": {
                "repo_id": GGUF_REPO,
                "filename": GGUF_NAME,
                "path": str(MODEL_C_GGUF),
                "bytes": MODEL_C_GGUF.stat().st_size,
                "gb": round(file_size_gb(MODEL_C_GGUF), 4),
                "expected_bytes": EXPECTED_BYTES["gguf_q8_0"],
                "match": MODEL_C_GGUF.stat().st_size == EXPECTED_BYTES["gguf_q8_0"],
            },
            "mmproj_f16": {
                "repo_id": GGUF_REPO,
                "filename": MMPROJ_NAME,
                "path": str(MODEL_C_MMPROJ),
                "bytes": MODEL_C_MMPROJ.stat().st_size,
                "gb": round(file_size_gb(MODEL_C_MMPROJ), 4),
                "expected_bytes": EXPECTED_BYTES["mmproj_f16"],
                "match": MODEL_C_MMPROJ.stat().st_size == EXPECTED_BYTES["mmproj_f16"],
            },
        },
        "total_gb": round(
            (transformers_bytes + MODEL_C_GGUF.stat().st_size + MODEL_C_MMPROJ.stat().st_size) / 1e9,
            4,
        ),
        "asked_before_30gb": False,
        "models_a_or_b_downloaded": False,
        "versions_recorded": bool(versions),
    }
    write_json(RESULTS / "download_c.json", payload)

    models_path = RESULTS / "models.json"
    models = read_json(models_path)
    models["selection_status"] = "model_c_downloaded"
    models["models"]["C"]["download_status"] = "complete"
    models["models"]["C"]["local"] = {
        "transformers_dir": str(MODEL_C_TRANSFORMERS),
        "gguf_path": str(MODEL_C_GGUF),
        "mmproj_path": str(MODEL_C_MMPROJ),
        "transformers_gb": payload["downloads"]["transformers"]["gb"],
        "gguf_q8_0_gb": payload["downloads"]["gguf_q8_0"]["gb"],
        "mmproj_f16_gb": payload["downloads"]["mmproj_f16"]["gb"],
        "total_gb": payload["total_gb"],
    }
    write_json(models_path, models)
    print(f"Model C downloaded: {payload['total_gb']} GB under {MODELS / 'c'}")


if __name__ == "__main__":
    main()
