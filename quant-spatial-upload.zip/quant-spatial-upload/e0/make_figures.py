"""Build simple E0 figures from recorded measurements. Not a gate.

Charts go to results/e0/figures/. Later phases use results/e1/figures/, etc.
"""

from __future__ import annotations

import shutil

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

from common import E0_IMAGE, FIGURES, figure_path

plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.size": 11,
        "axes.titlesize": 14,
        "axes.titleweight": "semibold",
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "axes.spines.top": False,
        "axes.spines.right": False,
    }
)


def save(fig, name: str) -> None:
    path = figure_path(name)
    fig.savefig(path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    print(path)


def fig_memory() -> None:
    labels = ["Small model (C)\n2 billion params", "Main model (A)\n8 billion params"]
    used = [3.9628, 16.33]
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    bars = ax.bar(labels, used, color=["#4C78A8", "#F58518"], width=0.55)
    ax.axhline(18, color="#54A24B", linestyle="--", linewidth=1.4, label="Comfortable limit (18 GiB)")
    ax.axhline(22, color="#E45756", linestyle="--", linewidth=1.4, label="Practical limit (22 GiB)")
    ax.axhline(28.08, color="#B279A2", linestyle=":", linewidth=1.4, label="Metal ceiling (28.08 GiB)")
    ax.set_ylabel("Memory used (GiB)")
    ax.set_title("How much memory each model used")
    ax.set_ylim(0, 32)
    for bar, value in zip(bars, used):
        ax.text(bar.get_x() + bar.get_width() / 2, value + 0.4, f"{value:.2f} GiB", ha="center")
    ax.legend(loc="upper left", frameon=False)
    ax.text(
        0.99,
        0.02,
        "Source: results/e0/gate_e.json and results/e0/a/gate_e.json\n"
        "Number shown is Metal/MPS memory after loading, not process RSS.",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=8,
        color="#555555",
    )
    save(fig, "memory-used.png")


def fig_disk() -> None:
    cats = ["Small model (C)", "Main model (A)"]
    bf16 = [4.2667, 17.5459]
    gguf = [1.8344, 8.7095]
    mmproj = [0.8194, 1.159]
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    ax.bar(cats, bf16, color="#4C78A8", label="Full-quality copy (BF16)")
    ax.bar(cats, gguf, bottom=bf16, color="#F58518", label="Compressed copy (Q8_0)")
    ax.bar(
        cats,
        mmproj,
        bottom=[b + g for b, g in zip(bf16, gguf)],
        color="#54A24B",
        label="Vision helper (mmproj F16)",
    )
    ax.set_ylabel("Disk space (GB)")
    ax.set_title("What we downloaded and saved on disk")
    ax.legend(loc="upper left", frameon=False)
    ax.set_ylim(0, 32)
    for i, total in enumerate([6.9205, 27.4145]):
        ax.text(i, total + 0.5, f"{total:.2f} GB total", ha="center")
    ax.text(
        0.99,
        0.02,
        "Source: results/e0/download_c.json and results/e0/download_a.json",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=8,
        color="#555555",
    )
    save(fig, "disk-downloads.png")


def fig_pipeline() -> None:
    fig, ax = plt.subplots(figsize=(10.4, 3.4))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 3)
    ax.axis("off")
    ax.set_title("The five checks we ran, in order")
    steps = [
        (0.3, "A\nCan it load\nand talk?"),
        (2.3, "B\nCan we see\nits confidence?"),
        (4.3, "C\nCan we read\nits answers?"),
        (6.3, "D\nCan we see\nits internals?"),
        (8.3, "E\nDoes it fit\nin memory?"),
    ]
    for x, text in steps:
        box = FancyBboxPatch(
            (x, 0.85),
            1.6,
            1.35,
            boxstyle="round,pad=0.04,rounding_size=0.12",
            facecolor="#E8EEF6",
            edgecolor="#4C78A8",
            linewidth=1.4,
        )
        ax.add_patch(box)
        ax.text(x + 0.8, 1.52, text, ha="center", va="center", fontsize=10)
    for x in (1.95, 3.95, 5.95, 7.95):
        ax.annotate("", xy=(x + 0.3, 1.52), xytext=(x, 1.52), arrowprops={"arrowstyle": "->", "color": "#333333"})
    ax.text(5, 0.35, "Both models passed every check. We stopped if any check failed.", ha="center", fontsize=10)
    save(fig, "five-checks.png")


def fig_internals() -> None:
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    x = [0, 1]
    layers = [28, 36]
    width = [2048, 4096]
    ax.bar([i - 0.18 for i in x], layers, width=0.36, color="#4C78A8", label="Number of layers")
    ax.bar([i + 0.18 for i in x], [w / 100 for w in width], width=0.36, color="#F58518", label="Hidden size / 100")
    ax.set_xticks(x)
    ax.set_xticklabels(["Small model (C)", "Main model (A)"])
    ax.set_ylabel("Count")
    ax.set_title("How big the models are on the inside")
    ax.legend(frameon=False)
    ax.text(-0.18, 28 + 0.6, "28 layers", ha="center", fontsize=9)
    ax.text(0.18, 20.48 + 0.6, "2048 wide", ha="center", fontsize=9)
    ax.text(0.82, 36 + 0.6, "36 layers", ha="center", fontsize=9)
    ax.text(1.18, 40.96 + 0.6, "4096 wide", ha="center", fontsize=9)
    ax.set_ylim(0, 50)
    ax.text(
        0.99,
        0.02,
        "Source: results/e0/gate_d.json and results/e0/a/gate_d.json\n"
        "Orange bars are hidden size divided by 100 so both fit on one chart.",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=8,
        color="#555555",
    )
    save(fig, "model-insides.png")


def copy_test_image() -> None:
    dest = figure_path("test-picture.png")
    if E0_IMAGE.exists():
        shutil.copy2(E0_IMAGE, dest)
        print(dest)


if __name__ == "__main__":
    FIGURES.mkdir(parents=True, exist_ok=True)
    fig_memory()
    fig_disk()
    fig_pipeline()
    fig_internals()
    copy_test_image()
