"""Shared paths, versions, and JSON helpers for E0 gates."""

from __future__ import annotations

import gc
import json
import os
import subprocess
import traceback
from datetime import datetime, timezone
from pathlib import Path

import psutil
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
E0 = ROOT / "e0"
MODELS = ROOT / "models"
DATA = ROOT / "data"
RESULTS = ROOT / "results" / "e0"
FIGURES = RESULTS / "figures"
LOGS = ROOT / "logs"

MODEL_C_TRANSFORMERS = MODELS / "c" / "transformers"
MODEL_C_GGUF = MODELS / "c" / "gguf" / "Qwen3VL-2B-Instruct-Q8_0.gguf"
MODEL_C_MMPROJ = MODELS / "c" / "gguf" / "mmproj-Qwen3VL-2B-Instruct-F16.gguf"
MODEL_A_TRANSFORMERS = MODELS / "a" / "transformers"
MODEL_A_GGUF = MODELS / "a" / "gguf" / "Qwen3VL-8B-Instruct-Q8_0.gguf"
MODEL_A_MMPROJ = MODELS / "a" / "gguf" / "mmproj-Qwen3VL-8B-Instruct-F16.gguf"
E0_IMAGE = DATA / "e0" / "spatial_shapes.png"

MODEL_SPECS = {
    "C": {
        "letter": "C",
        "transformers": MODEL_C_TRANSFORMERS,
        "gguf": MODEL_C_GGUF,
        "mmproj": MODEL_C_MMPROJ,
        "results_subdir": None,
    },
    "A": {
        "letter": "A",
        "transformers": MODEL_A_TRANSFORMERS,
        "gguf": MODEL_A_GGUF,
        "mmproj": MODEL_A_MMPROJ,
        "results_subdir": "a",
    },
}

# Hardware already measured. Do not re-litigate these numbers.
HARDWARE = {
    "machine": "Mac16,6",
    "chip": "Apple M4 Max",
    "unified_memory_gib": 36,
    "backend": "Metal/MPS",
    "cuda": False,
    "metal_recommended_max_working_set_gib": 28.08,
    "metal_max_buffer_length_gib": 21.06,
    "practical_budget_gib": {"low": 18, "high": 22},
}

MAX_NEW_TOKENS = 20
TEXT_PROMPT = "Reply with the word ready and nothing else."
IMAGE_PROMPT = "Name the two colors in this image."
LOGPROB_PROMPT = "The capital of France is"
SPATIAL_PROMPT = (
    "The red circle is on the left. The blue square is on the right. "
    'Which shape is on the left? Answer as JSON: {"shape": "...", "side": "..."}'
)

load_dotenv(ROOT / ".env")


def hf_token() -> str | None:
    token = os.environ.get("HF_TOKEN", "").strip()
    return token or None


def stack_versions() -> dict:
    versions: dict = {
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "python": None,
        "torch": None,
        "transformers": None,
        "llama_cpp_python": None,
        "llama_cpp_build": None,
        "mps_available": None,
    }
    try:
        import sys

        versions["python"] = sys.version.split()[0]
    except Exception as exc:
        versions["python"] = f"error: {exc}"
    try:
        import torch

        versions["torch"] = torch.__version__
        versions["mps_available"] = bool(torch.backends.mps.is_available())
    except Exception as exc:
        versions["torch"] = f"error: {exc}"
    try:
        import transformers

        versions["transformers"] = transformers.__version__
    except Exception as exc:
        versions["transformers"] = f"error: {exc}"
    try:
        import llama_cpp

        versions["llama_cpp_python"] = getattr(llama_cpp, "__version__", "unknown")
        build = None
        for attr in ("llama_cpp", "_internals"):
            mod = getattr(llama_cpp, attr, None)
            if mod is None:
                continue
            for name in ("llama_print_system_info",):
                fn = getattr(mod, name, None)
                if callable(fn):
                    try:
                        build = fn()
                        if isinstance(build, bytes):
                            build = build.decode("utf-8", errors="replace")
                    except Exception:
                        build = None
        versions["llama_cpp_build"] = build
    except Exception as exc:
        versions["llama_cpp_python"] = f"error: {exc}"
    return versions


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=str) + "\n")


def figure_path(name: str) -> Path:
    FIGURES.mkdir(parents=True, exist_ok=True)
    return FIGURES / name


def read_json(path: Path) -> dict:
    return json.loads(path.read_text())


def run_cmd(args: list[str]) -> str:
    proc = subprocess.run(args, capture_output=True, text=True, check=False)
    return (proc.stdout or "") + (proc.stderr or "")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def exception_record(exc: BaseException) -> dict:
    return {
        "type": type(exc).__name__,
        "message": str(exc),
        "traceback": traceback.format_exc(),
    }


def rss_gib() -> float:
    return psutil.Process(os.getpid()).memory_info().rss / (1024**3)


def mps_allocated_gib() -> float | None:
    try:
        import torch

        if not torch.backends.mps.is_available():
            return None
        return torch.mps.current_allocated_memory() / (1024**3)
    except Exception:
        return None


def memory_snapshot() -> dict:
    vm = psutil.virtual_memory()
    return {
        "rss_gib": round(rss_gib(), 4),
        "mps_allocated_gib": None if mps_allocated_gib() is None else round(mps_allocated_gib(), 4),
        "system_used_gib": round(vm.used / (1024**3), 4),
        "system_available_gib": round(vm.available / (1024**3), 4),
        "system_percent": vm.percent,
    }


def release_torch() -> None:
    gc.collect()
    try:
        import torch

        if torch.backends.mps.is_available():
            torch.mps.empty_cache()
    except Exception:
        pass
    gc.collect()


def require_mps() -> None:
    import torch

    if not torch.backends.mps.is_available():
        raise RuntimeError(
            "MPS is not available in this process. E0 must run with Metal/MPS; "
            "CPU fallback is not a valid gate path."
        )


def write_versions() -> dict:
    versions = stack_versions()
    extras = {
        "torchvision": None,
        "accelerate": None,
        "python_dotenv": None,
        "psutil": None,
        "pillow": None,
        "datasets": None,
        "huggingface_hub": None,
        "qwen_vl_utils": None,
        "numpy": None,
        "cmake": None,
    }
    mapping = {
        "torchvision": "torchvision",
        "accelerate": "accelerate",
        "python_dotenv": "dotenv",
        "psutil": "psutil",
        "pillow": "PIL",
        "datasets": "datasets",
        "huggingface_hub": "huggingface_hub",
        "qwen_vl_utils": "qwen_vl_utils",
        "numpy": "numpy",
        "cmake": "cmake",
    }
    dist_names = {
        "python_dotenv": "python-dotenv",
        "qwen_vl_utils": "qwen-vl-utils",
        "pillow": "pillow",
    }
    for key, mod_name in mapping.items():
        try:
            mod = __import__(mod_name)
            extras[key] = getattr(mod, "__version__", None)
            if extras[key] in (None, "unknown"):
                from importlib.metadata import PackageNotFoundError, version

                extras[key] = version(dist_names.get(key, key.replace("_", "-")))
        except Exception as exc:
            extras[key] = f"error: {exc}"
    versions.update(extras)
    versions["hardware_given"] = HARDWARE
    write_json(RESULTS / "versions.json", versions)
    return versions


def ensure_spatial_image() -> Path:
    from PIL import Image, ImageDraw

    E0_IMAGE.parent.mkdir(parents=True, exist_ok=True)
    if E0_IMAGE.exists():
        return E0_IMAGE
    image = Image.new("RGB", (256, 256), (240, 240, 240))
    draw = ImageDraw.Draw(image)
    draw.ellipse((20, 78, 116, 174), fill=(220, 30, 30))
    draw.rectangle((140, 78, 236, 174), fill=(30, 80, 220))
    image.save(E0_IMAGE)
    return E0_IMAGE


def model_spec(letter: str) -> dict:
    key = letter.upper()
    if key not in MODEL_SPECS:
        raise ValueError(f"unsupported model {letter!r}; E0 currently allows C or A")
    return MODEL_SPECS[key]


def model_results_dir(letter: str) -> Path:
    spec = model_spec(letter)
    if spec["results_subdir"]:
        return RESULTS / spec["results_subdir"]
    return RESULTS


def parse_model_arg(default: str = "C") -> str:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=sorted(MODEL_SPECS), default=default)
    return parser.parse_args().model.upper()


def read_gate(name: str, letter: str = "C") -> dict | None:
    path = model_results_dir(letter) / f"{name}.json"
    if not path.exists():
        return None
    return read_json(path)


def previous_gate_allows_continue(gate_name: str, letter: str = "C") -> tuple[bool, str]:
    payload = read_gate(gate_name, letter)
    if payload is None:
        return False, f"{model_results_dir(letter) / (gate_name + '.json')} is missing"
    status = payload.get("overall_status")
    if status in {"PASS", "PARTIAL"}:
        return True, status
    return False, f"{gate_name} overall_status={status}"


def file_size_gb(path: Path) -> float:
    return path.stat().st_size / 1e9


def dir_size_bytes(path: Path) -> int:
    total = 0
    for child in path.rglob("*"):
        if child.is_file():
            total += child.stat().st_size
    return total
