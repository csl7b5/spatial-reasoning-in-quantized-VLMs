"""Gate A: load Model C and generate 20 tokens on transformers/MPS and llama-cpp GGUF."""

from __future__ import annotations

import time
from pathlib import Path

from common import (
    IMAGE_PROMPT,
    MAX_NEW_TOKENS,
    TEXT_PROMPT,
    ensure_spatial_image,
    exception_record,
    memory_snapshot,
    model_results_dir,
    model_spec,
    now_iso,
    parse_model_arg,
    release_torch,
    require_mps,
    write_json,
)


def _decode_new_text(processor, input_ids, generated_ids) -> tuple[str, int]:
    new_ids = generated_ids[0][input_ids.shape[-1] :]
    text = processor.batch_decode(
        [new_ids], skip_special_tokens=True, clean_up_tokenization_spaces=False
    )[0]
    return text, int(new_ids.shape[-1])


def run_transformers(spec: dict) -> dict:
    record: dict = {
        "backend": "transformers_mps",
        "status": "FAIL",
        "started_at": now_iso(),
        "memory_before": memory_snapshot(),
    }
    try:
        import torch
        from PIL import Image
        from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

        require_mps()
        transformers_dir = spec["transformers"]
        if not transformers_dir.exists():
            raise FileNotFoundError(f"missing {transformers_dir}")

        t0 = time.perf_counter()
        processor = AutoProcessor.from_pretrained(transformers_dir)
        model = Qwen3VLForConditionalGeneration.from_pretrained(
            transformers_dir,
            dtype=torch.bfloat16,
            attn_implementation="sdpa",
        )
        model.to("mps")
        model.eval()
        record["load_s"] = round(time.perf_counter() - t0, 4)
        record["device"] = str(model.device)
        record["dtype"] = str(next(model.parameters()).dtype)
        record["memory_after_load"] = memory_snapshot()

        messages = [{"role": "user", "content": [{"type": "text", "text": TEXT_PROMPT}]}]
        inputs = processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        ).to(model.device)
        t1 = time.perf_counter()
        generated = model.generate(**inputs, max_new_tokens=MAX_NEW_TOKENS, do_sample=False)
        text, n_tokens = _decode_new_text(processor, inputs["input_ids"], generated)
        record["text"] = {
            "prompt": TEXT_PROMPT,
            "max_new_tokens": MAX_NEW_TOKENS,
            "n_new_tokens": n_tokens,
            "generate_s": round(time.perf_counter() - t1, 4),
            "output": text,
        }

        image_path = ensure_spatial_image()
        image = Image.open(image_path)
        vision_messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": IMAGE_PROMPT},
                ],
            }
        ]
        vision_inputs = processor.apply_chat_template(
            vision_messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        ).to(model.device)
        t2 = time.perf_counter()
        vision_generated = model.generate(
            **vision_inputs, max_new_tokens=MAX_NEW_TOKENS, do_sample=False
        )
        vision_text, vision_n = _decode_new_text(
            processor, vision_inputs["input_ids"], vision_generated
        )
        record["vision"] = {
            "prompt": IMAGE_PROMPT,
            "image": str(image_path),
            "max_new_tokens": MAX_NEW_TOKENS,
            "n_new_tokens": vision_n,
            "generate_s": round(time.perf_counter() - t2, 4),
            "output": vision_text,
        }
        record["memory_after_generate"] = memory_snapshot()
        if n_tokens > 0 and vision_n > 0:
            record["status"] = "PASS"
        del model
        del processor
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        release_torch()
        record["memory_after_release"] = memory_snapshot()
        record["finished_at"] = now_iso()
    return record


def run_llamacpp_text(spec: dict) -> dict:
    record: dict = {
        "backend": "llama_cpp_gguf_text",
        "status": "FAIL",
        "started_at": now_iso(),
        "memory_before": memory_snapshot(),
        "n_gpu_layers": -1,
        "requested_tokens": MAX_NEW_TOKENS,
    }
    llm = None
    try:
        from llama_cpp import Llama

        if not spec["gguf"].exists():
            raise FileNotFoundError(f"missing {spec['gguf']}")
        t0 = time.perf_counter()
        llm = Llama(
            model_path=str(spec["gguf"]),
            n_ctx=2048,
            n_gpu_layers=-1,
            logits_all=True,
            verbose=False,
        )
        record["load_s"] = round(time.perf_counter() - t0, 4)
        record["memory_after_load"] = memory_snapshot()
        t1 = time.perf_counter()
        out = llm.create_chat_completion(
            messages=[{"role": "user", "content": TEXT_PROMPT}],
            max_tokens=MAX_NEW_TOKENS,
            temperature=0,
        )
        choice = out["choices"][0]
        text = choice["message"]["content"]
        usage = out.get("usage", {})
        record["text"] = {
            "prompt": TEXT_PROMPT,
            "max_new_tokens": MAX_NEW_TOKENS,
            "completion_tokens": usage.get("completion_tokens"),
            "generate_s": round(time.perf_counter() - t1, 4),
            "output": text,
            "finish_reason": choice.get("finish_reason"),
        }
        record["memory_after_generate"] = memory_snapshot()
        n_tokens = usage.get("completion_tokens") or (1 if text else 0)
        if n_tokens > 0:
            record["status"] = "PASS"
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        if llm is not None:
            del llm
        record["memory_after_release"] = memory_snapshot()
        record["finished_at"] = now_iso()
    return record


def run_llamacpp_vision(spec: dict) -> dict:
    record: dict = {
        "backend": "llama_cpp_gguf_vision",
        "status": "FAIL",
        "started_at": now_iso(),
        "memory_before": memory_snapshot(),
        "handler": "MTMDChatHandler",
        "note": "Official llama-cpp-python 0.3.34 has MTMDChatHandler, not Qwen3VLChatHandler.",
    }
    llm = None
    try:
        import base64

        from llama_cpp import Llama
        from llama_cpp.llama_chat_format import MTMDChatHandler

        if not spec["mmproj"].exists():
            raise FileNotFoundError(f"missing {spec['mmproj']}")
        image_path = ensure_spatial_image()
        image_b64 = base64.b64encode(Path(image_path).read_bytes()).decode("ascii")
        t0 = time.perf_counter()
        handler = MTMDChatHandler(clip_model_path=str(spec["mmproj"]), verbose=False)
        llm = Llama(
            model_path=str(spec["gguf"]),
            chat_handler=handler,
            n_ctx=4096,
            n_gpu_layers=-1,
            verbose=False,
        )
        record["load_s"] = round(time.perf_counter() - t0, 4)
        record["memory_after_load"] = memory_snapshot()
        t1 = time.perf_counter()
        out = llm.create_chat_completion(
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{image_b64}"},
                        },
                        {"type": "text", "text": IMAGE_PROMPT},
                    ],
                }
            ],
            max_tokens=MAX_NEW_TOKENS,
            temperature=0,
        )
        choice = out["choices"][0]
        text = choice["message"]["content"]
        usage = out.get("usage", {})
        record["vision"] = {
            "prompt": IMAGE_PROMPT,
            "image": str(image_path),
            "max_new_tokens": MAX_NEW_TOKENS,
            "completion_tokens": usage.get("completion_tokens"),
            "generate_s": round(time.perf_counter() - t1, 4),
            "output": text,
            "finish_reason": choice.get("finish_reason"),
        }
        n_tokens = usage.get("completion_tokens") or (1 if text else 0)
        if n_tokens > 0:
            record["status"] = "PASS"
    except Exception as exc:
        record["status"] = "FAIL"
        record["error"] = exception_record(exc)
    finally:
        if llm is not None:
            del llm
        record["memory_after_release"] = memory_snapshot()
        record["finished_at"] = now_iso()
    return record


def main() -> None:
    letter = parse_model_arg()
    spec = model_spec(letter)
    out_dir = model_results_dir(letter)
    transformers_result = run_transformers(spec)
    gguf_text = run_llamacpp_text(spec)
    gguf_vision = run_llamacpp_vision(spec)

    tf_ok = transformers_result["status"] == "PASS"
    gguf_ok = gguf_text["status"] == "PASS"
    if tf_ok and gguf_ok:
        overall = "PASS"
        stop = False
        stop_reason = None
    elif tf_ok and not gguf_ok:
        overall = "PARTIAL"
        stop = False
        stop_reason = (
            "GGUF backend failed. Later gates may continue on transformers/MPS only. "
            "No fork or CPU workaround will be applied."
        )
    else:
        overall = "FAIL"
        stop = True
        stop_reason = "Transformers/MPS load-or-generate failed. Stop later gates."

    payload = {
        "gate": "A",
        "name": "load",
        "model": letter,
        "recorded_at": now_iso(),
        "overall_status": overall,
        "stop": stop,
        "stop_reason": stop_reason,
        "max_new_tokens": MAX_NEW_TOKENS,
        "backends": {
            "transformers_mps": transformers_result,
            "llama_cpp_gguf_text": gguf_text,
            "llama_cpp_gguf_vision": gguf_vision,
        },
    }
    write_json(out_dir / "gate_a.json", payload)
    print(f"Gate A model={letter} {overall} stop={stop}")
    if stop:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
