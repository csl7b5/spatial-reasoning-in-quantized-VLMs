"""Gate E: measure Model C load+generate memory against the given Metal budget."""

from __future__ import annotations

import time

from common import (
    HARDWARE,
    MAX_NEW_TOKENS,
    TEXT_PROMPT,
    exception_record,
    memory_snapshot,
    model_results_dir,
    model_spec,
    mps_allocated_gib,
    now_iso,
    parse_model_arg,
    previous_gate_allows_continue,
    read_json,
    release_torch,
    require_mps,
    rss_gib,
    write_json,
)


def _peaks() -> tuple[float, float]:
    rss = rss_gib()
    mps = mps_allocated_gib()
    return rss, 0.0 if mps is None else mps


def run_transformers(spec: dict) -> dict:
    record: dict = {
        "backend": "transformers_mps",
        "status": "FAIL",
        "started_at": now_iso(),
        "memory_before": memory_snapshot(),
        "rss_peak_gib": None,
        "mps_peak_gib": None,
        "observed_peak_gib": None,
    }
    peak_rss, peak_mps = _peaks()
    try:
        import torch
        from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

        require_mps()
        t0 = time.perf_counter()
        processor = AutoProcessor.from_pretrained(spec["transformers"])
        model = Qwen3VLForConditionalGeneration.from_pretrained(
            spec["transformers"],
            dtype=torch.bfloat16,
            attn_implementation="sdpa",
        )
        model.to("mps")
        model.eval()
        rss, mps = _peaks()
        peak_rss, peak_mps = max(peak_rss, rss), max(peak_mps, mps)
        record["load_s"] = round(time.perf_counter() - t0, 4)
        record["memory_after_load"] = memory_snapshot()
        messages = [{"role": "user", "content": [{"type": "text", "text": TEXT_PROMPT}]}]
        inputs = processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        ).to(model.device)
        t1 = time.perf_counter()
        generated = model.generate(**inputs, max_new_tokens=MAX_NEW_TOKENS, do_sample=False)
        rss, mps = _peaks()
        peak_rss, peak_mps = max(peak_rss, rss), max(peak_mps, mps)
        observed = max(peak_rss, peak_mps)
        record["generate_s"] = round(time.perf_counter() - t1, 4)
        record["n_new_tokens"] = int(generated.shape[-1] - inputs["input_ids"].shape[-1])
        record["memory_after_generate"] = memory_snapshot()
        record["rss_peak_gib"] = round(peak_rss, 4)
        record["mps_peak_gib"] = round(peak_mps, 4)
        record["observed_peak_gib"] = round(observed, 4)
        record["under_practical_high_22gib"] = observed < HARDWARE["practical_budget_gib"]["high"]
        record["under_metal_working_set_28_08gib"] = (
            observed < HARDWARE["metal_recommended_max_working_set_gib"]
        )
        record["headroom_vs_practical_high_gib"] = round(
            HARDWARE["practical_budget_gib"]["high"] - observed, 4
        )
        if record["under_practical_high_22gib"]:
            record["status"] = "PASS"
        else:
            record["status"] = "FAIL"
            record["error"] = {
                "type": "MemoryBudgetExceeded",
                "message": (
                    f"observed peak {observed:.4f} GiB (rss={peak_rss:.4f}, "
                    f"mps={peak_mps:.4f}) exceeds practical high budget 22 GiB"
                ),
            }
        del model
        del processor
    except Exception as exc:
        record["status"] = "FAIL"
        rss, mps = _peaks()
        record["rss_peak_gib"] = round(max(peak_rss, rss), 4)
        record["mps_peak_gib"] = round(max(peak_mps, mps), 4)
        record["observed_peak_gib"] = round(max(record["rss_peak_gib"], record["mps_peak_gib"]), 4)
        record["error"] = exception_record(exc)
    finally:
        release_torch()
        record["memory_after_release"] = memory_snapshot()
        record["finished_at"] = now_iso()
    return record


def run_llamacpp(spec: dict) -> dict:
    record: dict = {
        "backend": "llama_cpp_gguf_text",
        "status": "FAIL",
        "started_at": now_iso(),
        "memory_before": memory_snapshot(),
        "rss_peak_gib": None,
        "mps_peak_gib": None,
        "observed_peak_gib": None,
    }
    peak_rss, peak_mps = _peaks()
    llm = None
    try:
        from llama_cpp import Llama

        t0 = time.perf_counter()
        llm = Llama(
            model_path=str(spec["gguf"]),
            n_ctx=2048,
            n_gpu_layers=-1,
            verbose=False,
        )
        rss, mps = _peaks()
        peak_rss, peak_mps = max(peak_rss, rss), max(peak_mps, mps)
        record["load_s"] = round(time.perf_counter() - t0, 4)
        record["memory_after_load"] = memory_snapshot()
        t1 = time.perf_counter()
        out = llm.create_chat_completion(
            messages=[{"role": "user", "content": TEXT_PROMPT}],
            max_tokens=MAX_NEW_TOKENS,
            temperature=0,
        )
        rss, mps = _peaks()
        peak_rss, peak_mps = max(peak_rss, rss), max(peak_mps, mps)
        observed = max(peak_rss, peak_mps)
        record["generate_s"] = round(time.perf_counter() - t1, 4)
        record["completion_tokens"] = out.get("usage", {}).get("completion_tokens")
        record["memory_after_generate"] = memory_snapshot()
        record["rss_peak_gib"] = round(peak_rss, 4)
        record["mps_peak_gib"] = round(peak_mps, 4)
        record["observed_peak_gib"] = round(observed, 4)
        record["under_practical_high_22gib"] = observed < HARDWARE["practical_budget_gib"]["high"]
        record["headroom_vs_practical_high_gib"] = round(
            HARDWARE["practical_budget_gib"]["high"] - observed, 4
        )
        if record["under_practical_high_22gib"]:
            record["status"] = "PASS"
        else:
            record["status"] = "FAIL"
            record["error"] = {
                "type": "MemoryBudgetExceeded",
                "message": (
                    f"observed peak {observed:.4f} GiB (rss={peak_rss:.4f}, "
                    f"mps={peak_mps:.4f}) exceeds practical high budget 22 GiB"
                ),
            }
    except Exception as exc:
        record["status"] = "FAIL"
        rss, mps = _peaks()
        record["rss_peak_gib"] = round(max(peak_rss, rss), 4)
        record["mps_peak_gib"] = round(max(peak_mps, mps), 4)
        record["observed_peak_gib"] = round(max(record["rss_peak_gib"], record["mps_peak_gib"]), 4)
        record["error"] = exception_record(exc)
    finally:
        if llm is not None:
            del llm
        record["memory_after_release"] = memory_snapshot()
        record["finished_at"] = now_iso()
    return record


def main() -> None:
    letter = parse_model_arg()
    spec = model_spec(letter)
    out_dir = model_results_dir(letter)
    ok, reason = previous_gate_allows_continue("gate_d", letter)
    if not ok:
        payload = {
            "gate": "E",
            "name": "memory",
            "model": letter,
            "recorded_at": now_iso(),
            "overall_status": "FAIL",
            "stop": True,
            "stop_reason": f"Gate D did not allow continue: {reason}",
        }
        write_json(out_dir / "gate_e.json", payload)
        raise SystemExit(2)

    gate_a = read_json(out_dir / "gate_a.json")
    transformers_result = run_transformers(spec)
    if gate_a["backends"]["llama_cpp_gguf_text"]["status"] == "PASS":
        gguf_result = run_llamacpp(spec)
    else:
        gguf_result = {
            "backend": "llama_cpp_gguf_text",
            "status": "SKIP",
            "reason": "Gate A GGUF text backend failed; not retried.",
        }

    tf_ok = transformers_result["status"] == "PASS"
    if tf_ok:
        overall = "PASS" if gguf_result["status"] in {"PASS", "SKIP"} else "PARTIAL"
        stop = False
        stop_reason = None
        if gguf_result["status"] == "FAIL":
            stop_reason = "GGUF memory probe failed. Transformers memory passed."
    else:
        overall = "FAIL"
        stop = True
        stop_reason = "Transformers memory probe failed or exceeded budget. Stop."

    payload = {
        "gate": "E",
        "name": "memory",
        "model": letter,
        "recorded_at": now_iso(),
        "overall_status": overall,
        "stop": stop,
        "stop_reason": stop_reason,
        "hardware_given": HARDWARE,
        "backends": {
            "transformers_mps": transformers_result,
            "llama_cpp_gguf_text": gguf_result,
        },
    }
    write_json(out_dir / "gate_e.json", payload)
    print(f"Gate E model={letter} {overall} stop={stop}")
    if stop:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
