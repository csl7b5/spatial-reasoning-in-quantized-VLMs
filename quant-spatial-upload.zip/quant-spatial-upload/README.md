# quant-spatial

Quantization and spatial reasoning in vision-language models.

E0 is a feasibility gate, not an experiment. Later phases: E1 → E4.

**Git does not contain model weights or benchmark images.** `models/` and `data/` are gitignored. How to rebuild them: [`e1/DATA.md`](e1/DATA.md).

## Layout

```
e0/           gate scripts
e1/           E1 scripts and data docs
models/       GGUF and safetensors (gitignored)
data/         benchmark items (gitignored)
results/e0/   JSON and writeup from the gate
results/e1/   E1 notes, preflight, scores
logs/         gitignored
```

Figures stay inside the phase that made them: `results/e0/figures/`, `results/e1/figures/` (gitignored).

## Downloads and cleanup

See [`e1/DATA.md`](e1/DATA.md) for sources, licenses, and scripts.  
On a machine that already has the files: `python e1/inventory.py` writes a local list (`results/DOWNLOAD_INVENTORY.json`, gitignored).

## Hand labels

```bash
source .venv/bin/activate
python e1/build_label_queue.py
python e1/label_app.py
```

Open http://127.0.0.1:8765. Keys: `1`/`2` spatial, `3`/`4` numeric, Enter save, `X` exclude.

## Start (Model C only)

```bash
source .venv/bin/activate
python e0/gate_a_load.py
```

Muse Glimmer 30B NVFP4 is already on this machine via Ollama (`muse-glimmer:30b-mlx`, 21 GB). It is not Model A for E0. Do not re-download it.
